# Reddit Post Lifecycle Management System

## Overview

This system automatically discovers new Reddit posts, tracks them over time, and manages their lifecycle through active, dormant, and retired phases. It uses Bayesian adaptive sampling to prioritize which posts to scrape based on activity levels.

## Key Features

### 1. **Priority System Enhancement**
- **Measurement Count Bias**: Posts with fewer scrapes get a priority boost (25 points per missing scrape, up to 5 scrapes)
- **Selective Phase 1B**: Only scrapes posts that meet criteria:
  - Posts ≤24 hours old (likely still growing)
  - Posts with <3 scrapes (need minimum sample)
  - Posts in 'active' state
- **Smart Filtering**: Skips well-sampled dormant posts to avoid wasted API calls

### 2. **Automatic Discovery**
- **Auto-discovery**: Fetches new posts from `/r/{subreddit}/new` every ~5 minutes
- **Manual URLs**: User can add URLs to `manual_urls.txt` for custom tracking
- **Deduplication**: Automatically handles duplicate URLs
- **Source Tracking**: Distinguishes between auto-discovered and manually-added posts

### 3. **Lifecycle Management**
Three states with intelligent transitions:

#### **Active State**
- High activity, frequent scraping by adaptive sampler
- Monitored for dormancy threshold
- Threshold: <5 new comments per scrape over last 3 scrapes

#### **Dormant State**
- Low/no activity, exponential backoff checking
- Levels: 0→1→2→3→4 (1w → 2w → 4w → 8w → 16w)
- Can reactivate if activity spike detected

#### **Retired State**
- No activity after 16 weeks in dormancy
- Removed from active tracking
- Kept in metadata for historical record
- Archived to `archived_urls.txt`

## File Structure

### Core Scripts
- `test_temporal_scraping.py` - Main scraping script with adaptive sampling
- `manage_tracked_posts.py` - Discovery and lifecycle management
- `priority.py` - Bayesian adaptive sampling algorithm

### Data Files
- `tracked_urls.txt` - Active URLs being tracked (auto-updated)
- `manual_urls.txt` - User-specified URLs (user edits this)
- `post_metadata.json` - Lifecycle state and history for each post
- `archived_urls.txt` - Retired posts (optional archive)

### Utilities
- `view_post_lifecycle.py` - View current lifecycle status of all posts
- `test_lifecycle_transitions.py` - Test lifecycle logic with mock data

## Usage

### Running the Scraper

```bash
# Run adaptive scraping for 60 minutes on r/news
python3 test_temporal_scraping.py news 60

# The scraper will:
# - Load tracked URLs from tracked_urls.txt
# - Scrape virgin posts first (Phase 1A)
# - Selectively scrape session-new posts (Phase 1B)
# - Use Bayesian adaptive sampling (Phase 2)
# - Check for new posts every 5 minutes
# - Auto-discover from /new and manual_urls.txt
```

### Managing Posts Manually

#### Add a URL for tracking:
```bash
# Edit manual_urls.txt and add the URL
echo "https://www.reddit.com/r/news/comments/abc123/post_title/" >> manual_urls.txt

# The URL will be picked up on next discovery check (~5 min)
# Or run discovery manually:
python3 manage_tracked_posts.py news --quick
```

#### View lifecycle status:
```bash
python3 view_post_lifecycle.py
```

#### Run full maintenance:
```bash
# Discovery + lifecycle maintenance
python3 manage_tracked_posts.py news

# Quick discovery only (no maintenance)
python3 manage_tracked_posts.py news --quick
```

### Testing

```bash
# Test lifecycle transitions with mock data
python3 test_lifecycle_transitions.py

# Tests:
# 1. Active → Dormant (low activity)
# 2. Dormant level escalation (0→1)
# 3. Dormant → Active (activity spike)
```

## Configuration

### Dormancy Thresholds (in `manage_tracked_posts.py`)

```python
DISCOVERY_INTERVAL = 300              # 5 minutes
DORMANCY_THRESHOLD_COMMENTS = 5       # < 5 new comments/scrape
DORMANCY_THRESHOLD_SCRAPES = 3        # Over last 3 scrapes
DORMANCY_BACKOFF_BASE = 7 * 24 * 3600 # 1 week
MAX_DORMANCY_LEVEL = 4                # 16 weeks max
```

### Priority System (in `test_temporal_scraping.py`)

```python
monitor = TreeMonitor(
    tree_ids=post_ids,
    phi=0.95,              # Discount factor (history weight)
    kappa=0.3,             # Uncertainty/exploration weight
    eta=0.2,               # Burst detection weight
    rho=1.5,               # Staleness penalty weight
    measurement_bonus=25.0, # Points per missing scrape
    measurement_threshold=5 # Target minimum scrapes
)
```

### Phase 1B Criteria

Posts are scraped in Phase 1B if **ANY** of these are true:
- Age ≤24 hours
- Total scrapes <3
- State = 'active'

## How It Works

### Discovery Flow
1. Every 5 minutes (during Phase 2):
   - Fetch posts from `/r/{subreddit}/new`
   - Load URLs from `manual_urls.txt`
   - Combine and deduplicate
   - Compare against `tracked_urls.txt`
   - Add new posts to metadata (state='active')
   - Update `tracked_urls.txt`

### Lifecycle Flow
1. **Sync with scraper data**:
   - Read recent scrapes from `temporal_test/{post_id}/raw_scrapes/`
   - Extract comment counts
   - Update `activity_history` in metadata

2. **Active → Dormant transition**:
   - Calculate avg new comments over last 3 scrapes
   - If avg <5 → set state='dormant', level=0
   - Schedule next check in 1 week

3. **Dormant level escalation**:
   - If next_check_due has passed
   - If still low activity → increment level
   - Schedule next check: 2^level weeks
   - If level >4 → retire

4. **Dormant → Active transition**:
   - If activity spike detected (avg ≥5)
   - Set state='active', level=0
   - Resume normal adaptive sampling

5. **Retirement**:
   - Remove from `tracked_urls.txt`
   - Add to `archived_urls.txt`
   - Keep in metadata (state='retired')

### Priority Scoring

Posts are scored based on:
- **Expected yield** (w_abs=0.6): Predicted new comments
- **Relative gain** (w_rel=0.4): Value with diminishing returns
- **Uncertainty** (kappa=0.3): Exploration bonus
- **Burstiness** (eta=0.2): Sudden activity detection
- **Staleness** (rho=1.5): Time since last scrape
- **Measurement bias**: Bonus for under-sampled posts

Higher score = scraped next.

## Integration with Existing System

### Phase System
- **Phase 1A**: Virgin posts (never scraped) - score=1000
- **Phase 1B**: Selective baseline - filtered by criteria
- **Phase 2**: Adaptive sampling - Bayesian prioritization

### Metadata Schema

```json
{
  "post_id": {
    "url": "https://reddit.com/...",
    "added_date": "2025-10-15T12:00:00",
    "source": "auto|manual",
    "state": "active|dormant|retired",
    "last_check": "2025-10-15T12:30:00",
    "last_activity": "2025-10-15T12:25:00",
    "dormancy_level": 0,
    "next_check_due": "2025-10-22T12:30:00",
    "activity_history": [
      {"timestamp": "...", "comment_count": 50}
    ]
  }
}
```

## Monitoring

### View Current Status
```bash
python3 view_post_lifecycle.py
```

Output:
- Total posts by state (Active/Dormant/Retired)
- Active posts: URL, source, last activity, comment counts
- Dormant posts: Level, next check time
- Retired posts: When retired

### Check Tracked URLs
```bash
wc -l tracked_urls.txt  # Count active URLs
tail tracked_urls.txt   # See recent additions
```

### Inspect Metadata
```bash
# Pretty-print specific post
python3 -c "import json; m=json.load(open('post_metadata.json')); print(json.dumps(m.get('POST_ID'), indent=2))"
```

## Tuning Recommendations

After 24 hours of monitoring:

1. **Dormancy threshold too aggressive?**
   - Increase `DORMANCY_THRESHOLD_COMMENTS` (5 → 10)
   - Increase `DORMANCY_THRESHOLD_SCRAPES` (3 → 5)

2. **Too many dormant posts?**
   - Decrease `DORMANCY_BACKOFF_BASE` (1w → 3d)
   - More frequent dormancy checks

3. **Phase 1B filtering too strict?**
   - Increase age threshold (24h → 48h)
   - Increase min scrapes (3 → 5)

4. **Measurement bias too weak?**
   - Increase `measurement_bonus` (25 → 50)
   - Increase `measurement_threshold` (5 → 10)

## Future Enhancements

- [ ] Multi-subreddit support
- [ ] Web dashboard for lifecycle visualization
- [ ] Alert system for unusual activity patterns
- [ ] ML-based dormancy prediction
- [ ] Configurable thresholds via config file
- [ ] Post deletion detection
- [ ] Locked post handling

## Testing Results

All lifecycle transitions tested and verified:

✅ **Test 1**: Active → Dormant (low activity)
- Created 5 scrapes with 1 comment/scrape growth
- Successfully transitioned to dormant state

✅ **Test 2**: Dormant level escalation
- Created scrapes with no growth
- Successfully escalated from level 0 → 1
- Next check scheduled in 2 weeks

✅ **Test 3**: Dormant → Active reactivation
- Created scrapes with activity spike
- Successfully reactivated to active state
- Resumed adaptive sampling

## Troubleshooting

### Discovery not finding new posts
- Check OAuth authentication: `python3 reddit_auth.py`
- Verify rate limits aren't blocking: check for 429 errors
- Ensure `manual_urls.txt` format is correct (one URL per line)

### Posts not transitioning states
- Run full maintenance: `python3 manage_tracked_posts.py news`
- Check if `activity_history` is updating (view with lifecycle viewer)
- Verify scrape files exist in `temporal_test/{post_id}/raw_scrapes/`

### Phase 1B skipping expected posts
- Check post metadata: age, scrape count, state
- Verify criteria in Phase 1B logic
- Run with debug prints to see filtering reasons

### Measurement bias not working
- Verify `scrape_count` is incrementing in `priority.py`
- Check that `measure_tree()` is called after each scrape
- Ensure monitor initialized with `measurement_bonus` and `measurement_threshold`

