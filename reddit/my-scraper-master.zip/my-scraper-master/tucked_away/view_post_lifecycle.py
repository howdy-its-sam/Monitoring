#!/usr/bin/env python3
"""
View Post Lifecycle Status

Simple utility to inspect post_metadata.json and show current state of all tracked posts
"""

import json
import os
from datetime import datetime


def load_metadata():
    """Load post_metadata.json"""
    if os.path.exists('post_metadata.json'):
        try:
            with open('post_metadata.json', 'r') as f:
                return json.load(f)
        except Exception as e:
            print(f"❌ Error loading metadata: {e}")
            return {}
    else:
        print("❌ post_metadata.json not found")
        return {}


def format_time_ago(iso_timestamp):
    """Convert ISO timestamp to human-readable 'X ago' format"""
    try:
        then = datetime.fromisoformat(iso_timestamp)
        now = datetime.now()
        delta = now - then
        
        if delta.days > 365:
            return f"{delta.days // 365}y ago"
        elif delta.days > 30:
            return f"{delta.days // 30}mo ago"
        elif delta.days > 0:
            return f"{delta.days}d ago"
        elif delta.seconds > 3600:
            return f"{delta.seconds // 3600}h ago"
        elif delta.seconds > 60:
            return f"{delta.seconds // 60}m ago"
        else:
            return f"{delta.seconds}s ago"
    except:
        return "unknown"


def format_time_until(iso_timestamp):
    """Convert ISO timestamp to human-readable 'in X' format"""
    try:
        then = datetime.fromisoformat(iso_timestamp)
        now = datetime.now()
        delta = then - now
        
        if delta.total_seconds() < 0:
            return "overdue"
        
        days = delta.days
        seconds = delta.seconds
        
        if days > 365:
            return f"in {days // 365}y"
        elif days > 30:
            return f"in {days // 30}mo"
        elif days > 0:
            return f"in {days}d"
        elif seconds > 3600:
            return f"in {seconds // 3600}h"
        elif seconds > 60:
            return f"in {seconds // 60}m"
        else:
            return f"in {seconds}s"
    except:
        return "unknown"


def view_lifecycle_status():
    """Main function to display lifecycle status"""
    metadata = load_metadata()
    
    if not metadata:
        return
    
    # Remove schema info if present
    if '_schema_info' in metadata:
        del metadata['_schema_info']
    
    # Group by state
    active = []
    dormant = []
    retired = []
    
    for post_id, data in metadata.items():
        state = data.get('state', 'unknown')
        if state == 'active':
            active.append((post_id, data))
        elif state == 'dormant':
            dormant.append((post_id, data))
        elif state == 'retired':
            retired.append((post_id, data))
    
    # Display summary
    print("\n" + "="*80)
    print("📊 POST LIFECYCLE STATUS")
    print("="*80 + "\n")
    
    print(f"Total tracked posts: {len(metadata)}")
    print(f"  🟢 Active: {len(active)}")
    print(f"  🟡 Dormant: {len(dormant)}")
    print(f"  ⚫ Retired: {len(retired)}")
    print()
    
    # Display active posts
    if active:
        print("="*80)
        print("🟢 ACTIVE POSTS")
        print("="*80 + "\n")
        
        for post_id, data in sorted(active, key=lambda x: x[1].get('added_date', ''), reverse=True):
            url = data.get('url', 'unknown')
            added = format_time_ago(data.get('added_date', ''))
            last_activity = format_time_ago(data.get('last_activity', ''))
            source = data.get('source', 'unknown')
            
            activity_history = data.get('activity_history', [])
            if len(activity_history) >= 2:
                recent_count = activity_history[-1].get('comment_count', 0)
                prev_count = activity_history[-2].get('comment_count', 0)
                change = recent_count - prev_count
                activity_str = f"{recent_count} comments (+{change})"
            elif len(activity_history) == 1:
                recent_count = activity_history[-1].get('comment_count', 0)
                activity_str = f"{recent_count} comments"
            else:
                activity_str = "no data"
            
            print(f"📌 {post_id}")
            print(f"   URL: {url}")
            print(f"   Source: {source} | Added: {added}")
            print(f"   Last activity: {last_activity} | {activity_str}")
            print()
    
    # Display dormant posts
    if dormant:
        print("="*80)
        print("🟡 DORMANT POSTS")
        print("="*80 + "\n")
        
        for post_id, data in sorted(dormant, key=lambda x: x[1].get('dormancy_level', 0)):
            url = data.get('url', 'unknown')
            added = format_time_ago(data.get('added_date', ''))
            last_check = format_time_ago(data.get('last_check', ''))
            next_check = format_time_until(data.get('next_check_due', ''))
            dormancy_level = data.get('dormancy_level', 0)
            
            # Calculate dormancy period
            periods = {0: "1 week", 1: "2 weeks", 2: "4 weeks", 3: "8 weeks", 4: "16 weeks"}
            period = periods.get(dormancy_level, "unknown")
            
            print(f"💤 {post_id} (Level {dormancy_level} - {period})")
            print(f"   URL: {url}")
            print(f"   Added: {added}")
            print(f"   Last check: {last_check} | Next check: {next_check}")
            print()
    
    # Display retired posts
    if retired:
        print("="*80)
        print("⚫ RETIRED POSTS")
        print("="*80 + "\n")
        
        for post_id, data in sorted(retired, key=lambda x: x[1].get('last_check', ''), reverse=True):
            url = data.get('url', 'unknown')
            added = format_time_ago(data.get('added_date', ''))
            retired_date = format_time_ago(data.get('last_check', ''))
            
            print(f"⚰️  {post_id}")
            print(f"   URL: {url}")
            print(f"   Added: {added} | Retired: {retired_date}")
            print()
    
    print("="*80 + "\n")


if __name__ == '__main__':
    view_lifecycle_status()

