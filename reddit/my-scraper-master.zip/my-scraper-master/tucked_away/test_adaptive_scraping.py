#!/usr/bin/env python3
"""
Adaptive Information-Weighted Scraping
Uses continuous temperature-based scheduling with rate-limit feedback.
Replaces the old 3-phase discrete priority system.
"""

import time
import os
import re
import json
from datetime import datetime, timezone, timedelta
from typing import Dict, Optional

from reddit_scraper_api import scrape_reddit_post_api, get_request_count
from reddit_auth import get_authenticated_session
from adaptive_scheduler import AdaptiveScheduler
from temperature_scheduler import ScrapeDelta
from info_gain_analytics import compute_delta_info, collect_nodes
from bootstrap_scheduler_from_merged import bootstrap_from_merged_data


def extract_post_id(url: str) -> Optional[str]:
    """Extract Reddit post ID from URL"""
    match = re.search(r'/comments/([^/]+)/', url)
    return match.group(1) if match else None


def extract_subreddit(url: str) -> str:
    """Extract subreddit from URL"""
    match = re.search(r'/r/([^/]+)/', url)
    return match.group(1) if match else "news"


def load_tracked_urls(filename: str = 'tracked_urls.txt') -> Dict[str, str]:
    """
    Load tracked URLs from file.
    
    Returns:
        Dict mapping post_id → url
    """
    urls = {}
    try:
        with open(filename, 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#'):
                    post_id = extract_post_id(line)
                    if post_id:
                        urls[post_id] = line
        print(f"✅ Loaded {len(urls)} posts from {filename}")
    except FileNotFoundError:
        print(f"❌ Error: {filename} not found")
    except Exception as e:
        print(f"❌ Error reading {filename}: {e}")
    
    return urls


def compute_scrape_delta(post_id: str, current_data: dict, 
                        previous_data: Optional[dict] = None) -> ScrapeDelta:
    """
    Compute ΔInfo from a scrape by comparing with previous scrape.
    
    Args:
        post_id: Reddit post ID
        current_data: Current scrape result
        previous_data: Previous scrape result (or None if first scrape)
    
    Returns:
        ScrapeDelta with information gain metrics
    """
    now = datetime.now(timezone.utc)
    
    if previous_data is None:
        # First scrape - count all as new
        nodes = collect_nodes(current_data)
        comment_count = len([n for (kind, n) in nodes if kind == "comment"])
        
        return ScrapeDelta(
            ts=now,
            new_comments=comment_count,
            edited_comments=0,
            score_changed=0,
            deleted_comments=0
        )
    
    # Compute detailed ΔInfo between scrapes
    # Use info_gain_analytics logic but for single interval
    
    prev_nodes = {n.get('id'): n for (_, n) in collect_nodes(previous_data) if n.get('id')}
    curr_nodes = {n.get('id'): n for (_, n) in collect_nodes(current_data) if n.get('id')}
    
    new_comments = 0
    edited_comments = 0
    score_changed = 0
    deleted_comments = 0
    
    # New comments
    new_comments = len(set(curr_nodes.keys()) - set(prev_nodes.keys()))
    
    # Score changes and edits
    for node_id in set(curr_nodes.keys()) & set(prev_nodes.keys()):
        curr = curr_nodes[node_id]
        prev = prev_nodes[node_id]
        
        # Check score change
        curr_score = curr.get('score', 0)
        prev_score = prev.get('score', 0)
        if curr_score != prev_score:
            score_changed += 1
        
        # Check text edit
        curr_text = curr.get('body', '')
        prev_text = prev.get('body', '')
        if curr_text != prev_text:
            edited_comments += 1
    
    # Deleted comments
    deleted_comments = len(set(prev_nodes.keys()) - set(curr_nodes.keys()))
    
    return ScrapeDelta(
        ts=now,
        new_comments=new_comments,
        edited_comments=edited_comments,
        score_changed=score_changed,
        deleted_comments=deleted_comments
    )


def run_adaptive_scraping(duration_minutes: int = 60, target_rps: float = 10.0):
    """
    Main adaptive scraping loop using continuous temperature scheduler.
    
    Args:
        duration_minutes: How long to run (default 60)
        target_rps: Target requests per second (default 10.0 = 600/min)
    """
    print("="*80)
    print("🌡️  ADAPTIVE INFORMATION-WEIGHTED SCRAPER")
    print("="*80)
    print()
    
    # Initialize OAuth session
    print("🔐 Initializing OAuth authentication...")
    try:
        session = get_authenticated_session()
        if session:
            print("✅ OAuth authenticated")
            # Create simple token pool structure for compatibility
            token_pool = [{
                'session': session,
                'backoff': 2.0,
                'name': 'default'
            }]
        else:
            print("⚠️  Running without authentication")
            token_pool = None
    except:
        print("⚠️  Failed to authenticate, running without authentication")
        token_pool = None
    print()
    
    # Load tracked URLs
    print("📋 Loading tracked posts...")
    tracked_urls = load_tracked_urls()
    
    if not tracked_urls:
        print("❌ No posts to track. Exiting.")
        return
    print()
    
    # Initialize adaptive scheduler
    print("🧠 Initializing adaptive scheduler...")
    scheduler = AdaptiveScheduler(
        target_rps=target_rps,
        lateness_setpoint=0.15,  # 15% target lateness
        state_dir="temporal_test"
    )
    
    # Add all posts to scheduler
    for post_id, url in tracked_urls.items():
        subreddit = extract_subreddit(url)
        scheduler.add_post(post_id, url, subreddit)
    
    print(f"✅ Tracking {len(scheduler.posts)} posts")
    print()
    
    # Bootstrap from existing merged data
    print("🔄 Bootstrapping from historical data...")
    bootstrap_from_merged_data(scheduler)
    print()
    
    # Calculate end time
    start_time = time.time()
    end_time = start_time + (duration_minutes * 60)
    
    print("="*80)
    print("📊 CONFIGURATION")
    print("="*80)
    print(f"  ├─ Target RPS: {target_rps} ({target_rps*60:.0f}/min)")
    print(f"  ├─ Duration: {duration_minutes} minutes")
    print(f"  ├─ Lateness setpoint: 15%")
    print(f"  ├─ Temperature weights: α=0.6, β=0.3, γ=0.1")
    print(f"  ├─ Interval bounds: [0.5h, 24h]")
    print(f"  └─ Rate control: EMA-based with gain ∈ [0.5, 3.0]")
    print()
    
    print(f"🚀 Starting at {datetime.now().strftime('%H:%M:%S')}")
    print(f"🏁 Will stop at {datetime.fromtimestamp(end_time).strftime('%H:%M:%S')}")
    print("="*80)
    print()
    
    # Track previous scrape data for delta computation
    previous_data: Dict[str, Optional[dict]] = {pid: None for pid in tracked_urls.keys()}
    
    # Metrics
    total_scrapes = 0
    total_delta_info = 0.0
    errors = 0
    
    # API request tracking for rate controller
    prev_request_count = get_request_count()
    tick_start_time = time.time()
    
    # Discovery timer (check for new posts every 5 minutes)
    last_discovery = time.time()
    discovery_interval = 300  # 5 minutes
    
    # Main loop
    while time.time() < end_time:
        now = datetime.now(timezone.utc)
        
        # Measure actual API request rate
        current_request_count = get_request_count()
        tick_duration = time.time() - tick_start_time
        
        if tick_duration > 0:
            requests_this_tick = current_request_count - prev_request_count
            instantaneous_rps = requests_this_tick / tick_duration
        else:
            instantaneous_rps = 0.0
        
        # Reset tick timer
        prev_request_count = current_request_count
        tick_start_time = time.time()
        
        # Run control tick with actual measured RPS
        queue = scheduler.control_tick(now, instantaneous_rps=instantaneous_rps)
        
        # Get next post to scrape
        ready_posts = scheduler.get_next_posts(limit=1)
        
        if not ready_posts:
            # Nothing ready yet, wait a bit
            wait_time = min(1.0, (end_time - time.time()))
            if wait_time > 0:
                time.sleep(wait_time)
            continue
        
        post_id = ready_posts[0]
        post = scheduler.posts[post_id]
        url = post.url
        
        # Display status
        elapsed_mins = (time.time() - start_time) / 60
        remaining_mins = (end_time - time.time()) / 60
        
        print(f"[{elapsed_mins:.0f}:{remaining_mins:.0f}] 🎯 {post_id} (T={post.temperature:.2f}, λ={post.lambda_hat:.2f}, Δt={post.interval_hours:.1f}h)...")
        
        # Prepare output directory
        post_dir = f'temporal_test/{post_id}/raw_scrapes'
        os.makedirs(post_dir, exist_ok=True)
        
        # Count existing scrapes
        existing_scrapes = [f for f in os.listdir(post_dir) if f.startswith('scrape_') and f.endswith('.json')]
        scrape_num = len(existing_scrapes) + 1
        
        # Generate output filename
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        output_file = f'{post_dir}/scrape_{scrape_num:03d}_{timestamp}.json'
        
        # Scrape the post
        try:
            if token_pool:
                result = scrape_reddit_post_api(url, output_file, session=token_pool[0]['session'])
            else:
                result = scrape_reddit_post_api(url, output_file)
            
            if result and 'error' not in result:
                # Compute delta from previous scrape
                delta = compute_scrape_delta(post_id, result, previous_data[post_id])
                
                # Record in scheduler
                scheduler.record_scrape(post_id, delta)
                
                # Update previous data
                previous_data[post_id] = result
                
                # Update metrics
                total_scrapes += 1
                delta_info = delta.weighted()
                total_delta_info += delta_info
                
                # Display result
                meta = result.get('metadata', {})
                comment_count = meta.get('total_comments', 0)
                coverage = meta.get('coverage_percent', 0)
                
                print(f"  ✅ {comment_count} comments ({coverage:.1f}% coverage), ΔInfo={delta_info:.1f}")
                
                # Show controller status periodically
                if total_scrapes % 5 == 0:
                    status = scheduler.controller.get_status()
                    print(f"  📊 g={status['global_gain']:.2f}, ema={status['rate_ema']:.1f} rps, util={status['utilization_pct']:.0f}%, API reqs={current_request_count}")
            else:
                print(f"  ❌ Scrape failed")
                errors += 1
        
        except KeyboardInterrupt:
            print("\n⚠️  Interrupted by user")
            break
        except Exception as e:
            print(f"  ❌ Error: {e}")
            errors += 1
        
        print()
        
        # Opportunistic discovery (check for new posts)
        if time.time() - last_discovery > discovery_interval:
            print("🔍 Checking for new posts...")
            # Note: You can add discovery logic here if needed
            # For now, just reset timer
            last_discovery = time.time()
        
        # Retire dormant posts periodically
        if total_scrapes % 20 == 0:
            scheduler.retire_dormant_posts()
        
        # Save state periodically
        if total_scrapes % 10 == 0:
            scheduler._save_state()
    
    # Final summary
    elapsed_total = (time.time() - start_time) / 60
    
    print("="*80)
    print("📊 FINAL SUMMARY")
    print("="*80)
    print(f"  ├─ Duration: {elapsed_total:.1f} minutes")
    print(f"  ├─ Total scrapes: {total_scrapes}")
    print(f"  ├─ Errors: {errors}")
    print(f"  ├─ Total ΔInfo: {total_delta_info:.1f}")
    print(f"  ├─ Avg ΔInfo/scrape: {total_delta_info/total_scrapes if total_scrapes > 0 else 0:.2f}")
    print(f"  └─ Throughput: {total_scrapes/elapsed_total:.2f} scrapes/min")
    print()
    
    # Controller status
    status = scheduler.get_status()
    print("Controller final state:")
    ctrl = status['controller']
    print(f"  ├─ Global gain: {ctrl['global_gain']:.3f}")
    print(f"  ├─ Rate EMA: {ctrl['rate_ema']:.2f} rps")
    print(f"  └─ Utilization: {ctrl['utilization_pct']:.1f}%")
    print()
    
    # Save final state
    scheduler._save_state()
    print("💾 Scheduler state saved")
    print()
    
    print("="*80)
    print("✅ SCRAPING COMPLETE")
    print("="*80)


if __name__ == '__main__':
    import sys
    
    # Parse arguments
    duration = int(sys.argv[1]) if len(sys.argv) > 1 else 60
    target_rps = float(sys.argv[2]) if len(sys.argv) > 2 else 10.0
    
    run_adaptive_scraping(duration_minutes=duration, target_rps=target_rps)

