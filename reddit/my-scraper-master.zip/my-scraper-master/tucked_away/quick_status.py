#!/usr/bin/env python3
"""
Quick Status Display

Shows a compact summary of the tracking system status
"""

import json
import os
from datetime import datetime


def quick_status():
    """Display quick status summary"""
    
    # Load data
    tracked_urls = []
    if os.path.exists('tracked_urls.txt'):
        with open('tracked_urls.txt', 'r') as f:
            tracked_urls = [line.strip() for line in f if line.strip() and not line.startswith('#')]
    
    metadata = {}
    if os.path.exists('post_metadata.json'):
        with open('post_metadata.json', 'r') as f:
            metadata = json.load(f)
            if '_schema_info' in metadata:
                del metadata['_schema_info']
    
    # Count states
    active = sum(1 for p in metadata.values() if p.get('state') == 'active')
    dormant = sum(1 for p in metadata.values() if p.get('state') == 'dormant')
    retired = sum(1 for p in metadata.values() if p.get('state') == 'retired')
    
    # Count sources
    auto = sum(1 for p in metadata.values() if p.get('source') == 'auto')
    manual = sum(1 for p in metadata.values() if p.get('source') == 'manual')
    
    # Count dormancy levels
    dormant_levels = {}
    for p in metadata.values():
        if p.get('state') == 'dormant':
            level = p.get('dormancy_level', 0)
            dormant_levels[level] = dormant_levels.get(level, 0) + 1
    
    # Display
    print("\n" + "="*60)
    print("📊 QUICK STATUS")
    print("="*60)
    
    print(f"\n🔢 Totals:")
    print(f"   Tracked URLs: {len(tracked_urls)}")
    print(f"   Metadata entries: {len(metadata)}")
    
    print(f"\n🟢 States:")
    print(f"   Active:  {active:3d}")
    print(f"   Dormant: {dormant:3d}")
    print(f"   Retired: {retired:3d}")
    
    if dormant_levels:
        print(f"\n💤 Dormant Levels:")
        for level in sorted(dormant_levels.keys()):
            weeks = 2 ** level
            print(f"   Level {level} ({weeks:2d}w): {dormant_levels[level]:3d} posts")
    
    print(f"\n📍 Sources:")
    print(f"   Auto-discovered: {auto:3d}")
    print(f"   Manual:          {manual:3d}")
    
    # Recent activity
    recent_active = []
    for post_id, data in metadata.items():
        if data.get('state') == 'active' and data.get('activity_history'):
            last_activity = data['activity_history'][-1]
            try:
                timestamp = datetime.fromisoformat(last_activity['timestamp'])
                recent_active.append((post_id, timestamp, last_activity.get('comment_count', 0)))
            except:
                pass
    
    if recent_active:
        recent_active.sort(key=lambda x: x[1], reverse=True)
        print(f"\n🔥 Recent Activity (top 5):")
        for post_id, timestamp, count in recent_active[:5]:
            age = (datetime.now() - timestamp).total_seconds() / 3600
            if age < 1:
                age_str = f"{int(age * 60)}m ago"
            elif age < 24:
                age_str = f"{int(age)}h ago"
            else:
                age_str = f"{int(age / 24)}d ago"
            print(f"   {post_id}: {count:4d} comments ({age_str})")
    
    print("\n" + "="*60 + "\n")


if __name__ == '__main__':
    quick_status()

