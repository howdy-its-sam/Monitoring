#!/usr/bin/env python3
"""
Test script to fetch posts from r/news/new
Shows what we'd get before integrating into main scraper
"""

import requests
import json
from datetime import datetime, timezone


def fetch_reddit_new(subreddit='news', limit=25):
    """
    Fetch new posts from a subreddit
    
    Args:
        subreddit: Subreddit name (default: 'news')
        limit: Number of posts to fetch (default: 25)
    
    Returns:
        List of post data dictionaries
    """
    
    url = f'https://www.reddit.com/r/{subreddit}/new.json?limit={limit}'
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    }
    
    print(f"🌐 Fetching r/{subreddit}/new...")
    print(f"   URL: {url}")
    
    try:
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        
        data = response.json()
        posts = data['data']['children']
        
        print(f"✅ Successfully fetched {len(posts)} posts\n")
        
        return posts
        
    except Exception as e:
        print(f"❌ Error fetching data: {e}")
        return []


def analyze_posts(posts):
    """
    Analyze and display information about fetched posts
    """
    
    if not posts:
        print("No posts to analyze")
        return
    
    print("="*80)
    print(f"📊 ANALYSIS OF r/news/new ({len(posts)} posts)")
    print("="*80)
    
    total_comments = 0
    urls = []
    
    for i, post_wrapper in enumerate(posts, 1):
        post = post_wrapper['data']
        
        post_id = post.get('id')
        title = post.get('title', 'No title')
        num_comments = post.get('num_comments', 0)
        score = post.get('score', 0)
        created_utc = post.get('created_utc', 0)
        permalink = post.get('permalink', '')
        
        # Calculate age
        now = datetime.now(timezone.utc)
        post_time = datetime.fromtimestamp(created_utc, timezone.utc)
        age_seconds = (now - post_time).total_seconds()
        
        if age_seconds < 3600:
            age_str = f"{int(age_seconds / 60)}m"
        elif age_seconds < 86400:
            age_str = f"{int(age_seconds / 3600)}h"
        else:
            age_str = f"{int(age_seconds / 86400)}d"
        
        # Build full URL
        full_url = f"https://www.reddit.com{permalink}"
        urls.append(full_url)
        
        # Truncate title for display
        display_title = title[:70] + "..." if len(title) > 70 else title
        
        print(f"\n{i:2d}. {display_title}")
        print(f"    ID: {post_id} | Comments: {num_comments:4d} | Score: {score:5d} | Age: {age_str}")
        
        total_comments += num_comments
    
    # Summary statistics
    print("\n" + "="*80)
    print("📈 SUMMARY STATISTICS")
    print("="*80)
    
    comment_counts = [p['data'].get('num_comments', 0) for p in posts]
    
    print(f"\nTotal posts: {len(posts)}")
    print(f"Total comments to scrape: {total_comments:,}")
    print(f"Average comments per post: {total_comments / len(posts):.1f}")
    print(f"Min comments: {min(comment_counts)}")
    print(f"Max comments: {max(comment_counts)}")
    print(f"Median comments: {sorted(comment_counts)[len(comment_counts)//2]}")
    
    # Time estimates
    avg_scrape_time = 30  # seconds per post
    total_time = len(posts) * avg_scrape_time
    
    print(f"\n⏱️  Estimated scrape time:")
    print(f"   Per cycle: {total_time // 60}m {total_time % 60}s")
    print(f"   With no delay: scrapes continuously")
    
    if total_comments > 0:
        cycles_per_hour = 3600 / total_time
        print(f"   Cycles per hour: ~{cycles_per_hour:.1f}")
    
    # Save URLs to file
    print(f"\n💾 Saving URLs...")
    with open('news_new_urls.txt', 'w') as f:
        f.write("# Auto-generated URLs from r/news/new\n")
        f.write(f"# Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"# Total posts: {len(posts)}\n")
        f.write(f"# Total comments: {total_comments:,}\n\n")
        for url in urls:
            f.write(f"{url}\n")
    
    print(f"✅ Saved {len(urls)} URLs to: news_new_urls.txt")
    
    return urls


def main():
    print("="*80)
    print("🧪 TEST: Fetching r/news/new")
    print("="*80)
    print()
    
    # Fetch posts
    posts = fetch_reddit_new(subreddit='news', limit=25)
    
    if posts:
        # Analyze and display
        urls = analyze_posts(posts)
        
        print("\n" + "="*80)
        print("✅ TEST COMPLETE")
        print("="*80)
        print("\n💡 Next steps:")
        print("   1. Review the posts above")
        print("   2. Check news_new_urls.txt for the URL list")
        print("   3. If it looks good, I'll integrate this into the main scraper")
        print("   4. The scraper will auto-fetch these URLs and cycle through them")
    else:
        print("\n❌ Failed to fetch posts")


if __name__ == '__main__':
    main()

