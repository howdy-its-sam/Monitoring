#!/usr/bin/env python3
"""
Data Hygiene & Merge Validation
Ensures merged Reddit data integrity with schema checks, timestamp validation, and repair utilities.
Based on reference_books/data_hygiene_merge_validation.ipynb
"""

import os
import json
import re
from datetime import datetime, timezone
from typing import Dict, List, Tuple, Optional
import pandas as pd


def parse_iso_utc(s: str) -> Optional[datetime]:
    """
    Robust timestamp parsing with fallbacks.
    Returns UTC datetime or None.
    """
    if not s:
        return None
    
    # Handle Z suffix
    s = s.replace('Z', '+00:00')
    
    try:
        dt = datetime.fromisoformat(s)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception:
        # Fallback: compact format YYYYMMDD_HHMMSS
        m = re.search(r"(\d{8})[T_]?(\d{6})", s)
        if m:
            return datetime.strptime(
                m.group(1) + m.group(2), 
                "%Y%m%d%H%M%S"
            ).replace(tzinfo=timezone.utc)
        return None


def ts_from_filename(fn: str) -> Optional[datetime]:
    """
    Extract timestamp from filename pattern: scrape_###_YYYYMMDD_HHMMSS.json
    """
    m = re.search(r"scrape_\d+_(\d{8})_(\d{6})\.json$", fn)
    if not m:
        return None
    return datetime.strptime(
        m.group(1) + m.group(2), 
        "%Y%m%d%H%M%S"
    ).replace(tzinfo=timezone.utc)


def validate_post_dir(post_dir: str) -> Optional[Dict]:
    """
    Validate a single post directory's merged data.
    
    Checks:
    - len(post.score_history) == #raw_scrapes
    - Timestamp alignment (first/last)
    - Missing or extra timestamps
    
    Returns dict with validation metrics or None if no merged file.
    """
    merged_path = os.path.join(post_dir, "final_merged.json")
    raw_dir = os.path.join(post_dir, "raw_scrapes")
    
    if not os.path.exists(merged_path):
        return None
    
    with open(merged_path, "r") as f:
        merged = json.load(f)
    
    # Extract timestamps from merged post.score_history
    root_ts = [
        parse_iso_utc(ts) 
        for _, ts in merged.get("post", {}).get("score_history", [])
        if parse_iso_utc(ts)
    ]
    
    # Extract timestamps from raw scrape filenames
    raw_ts = []
    if os.path.isdir(raw_dir):
        for fn in sorted(os.listdir(raw_dir)):
            if fn.endswith(".json"):
                t = ts_from_filename(fn)
                if t:
                    raw_ts.append(t)
    
    return {
        "post_id": os.path.basename(post_dir),
        "raw_scrapes": len(raw_ts),
        "merged_root_ts": len(root_ts),
        "missing_in_merged": int(len(set(raw_ts) - set(root_ts))),
        "extra_in_merged": int(len(set(root_ts) - set(raw_ts))),
        "first_ts": min(root_ts).isoformat() if root_ts else "",
        "last_ts": max(root_ts).isoformat() if root_ts else "",
    }


def audit_tree(node: Dict, issues: List[Tuple], path: str = "post"):
    """
    Recursively audit comment tree for:
    - Monotonic timestamps in score_history
    - Proper None handling (only with deleted=True)
    
    Appends issues to the provided list.
    """
    # Check score_history monotonicity
    sh = node.get("score_history", [])
    prev = None
    for val, ts in sh:
        t = parse_iso_utc(ts)
        if prev and t and t < prev:
            issues.append((path, "non_monotonic_score_history", ts))
        prev = t or prev
    
    # Ensure None only appears when deleted=True
    if any(val is None for val, _ in sh):
        if not node.get("deleted", False):
            issues.append((path, "none_value_without_deleted_flag", ""))
    
    # Recurse into replies
    for i, ch in enumerate(node.get("replies", []) or []):
        audit_tree(ch, issues, f"{path}.replies[{i}]")


def validate_dataset(root_dir: str) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Validate entire temporal_test/ directory.
    
    Returns:
    - DataFrame of post-level validation metrics
    - DataFrame of tree-level issues
    """
    rows = []
    issues = []
    
    for pid in sorted(os.listdir(root_dir)):
        pdir = os.path.join(root_dir, pid)
        if not os.path.isdir(pdir):
            continue
        
        # Validate post directory
        row = validate_post_dir(pdir)
        if row:
            rows.append(row)
        
        # Audit comment tree
        merged_path = os.path.join(pdir, "final_merged.json")
        if os.path.exists(merged_path):
            with open(merged_path, "r") as f:
                data = json.load(f)
            
            # Audit post root
            audit_tree(data.get("post", {}), issues, f"{pid}/post")
            
            # Audit all comments
            for i, c in enumerate(data.get("comments", []) or []):
                audit_tree(c, issues, f"{pid}/comments[{i}]")
    
    integrity_df = pd.DataFrame(rows).sort_values("post_id") if rows else pd.DataFrame()
    issues_df = pd.DataFrame(issues, columns=["path", "issue", "detail"]) if issues else pd.DataFrame()
    
    return integrity_df, issues_df


def repair_none_without_deleted(data: Dict) -> int:
    """
    Repair issue where score_history has None values but deleted=False.
    Removes trailing None markers.
    
    Returns count of fixed nodes.
    """
    fixed = 0
    
    def walk(n):
        nonlocal fixed
        sh = n.get("score_history", [])
        if any(val is None for val, _ in sh) and not n.get("deleted", False):
            # Remove None entries
            n["score_history"] = [(v, t) for (v, t) in sh if v is not None]
            fixed += 1
        for ch in n.get("replies", []) or []:
            walk(ch)
    
    # Walk post
    walk(data.get("post", {}))
    
    # Walk all comments
    for c in data.get("comments", []) or []:
        walk(c)
    
    return fixed


if __name__ == '__main__':
    print("="*80)
    print("📊 DATA VALIDATION - Merged Reddit Data Integrity Check")
    print("="*80)
    print()
    
    # Validate temporal_test/
    root = 'temporal_test'
    if not os.path.exists(root):
        print(f"❌ Directory not found: {root}")
        exit(1)
    
    print(f"🔍 Validating {root}/")
    print()
    
    integrity_df, issues_df = validate_dataset(root)
    
    # Display integrity metrics
    print("="*80)
    print("1️⃣  POST-LEVEL INTEGRITY METRICS")
    print("="*80)
    print()
    
    if not integrity_df.empty:
        print(integrity_df.to_string(index=False))
        print()
        
        # Summary
        total_posts = len(integrity_df)
        perfect = len(integrity_df[
            (integrity_df['missing_in_merged'] == 0) & 
            (integrity_df['extra_in_merged'] == 0)
        ])
        
        print(f"✅ Perfect alignment: {perfect}/{total_posts} posts")
        if perfect < total_posts:
            print(f"⚠️  Issues found: {total_posts - perfect} posts")
    else:
        print("No posts found.")
    
    print()
    
    # Display tree-level issues
    print("="*80)
    print("2️⃣  TREE-LEVEL ISSUES")
    print("="*80)
    print()
    
    if not issues_df.empty:
        print(f"⚠️  Found {len(issues_df)} issues:")
        print()
        print(issues_df.to_string(index=False))
    else:
        print("✅ No tree-level issues found!")
    
    print()
    print("="*80)

