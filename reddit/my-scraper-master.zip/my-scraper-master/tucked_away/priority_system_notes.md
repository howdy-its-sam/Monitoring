# Priority System Notes & Future Enhancements

This file contains discussion notes, pseudocode, and ideas for the adaptive sampling priority system.
**This is NOT executable code** - just for planning and discussion.

---

## Current Implementation Summary

The `TreeMonitor` class in `priority.py` uses Bayesian adaptive sampling to prioritize Reddit posts based on:

- **Expected Yield (E)**: Estimated new comments based on past rate (α/β)
- **Uncertainty (U)**: Exploration bonus for uncertain estimates
- **Burst State (H)**: Detects sudden activity spikes
- **Staleness (S)**: Penalty for not checking recently
- **Virgin Bonus**: Posts never scraped get score of 1000.0

### Current Parameters:
```python
alpha0=1.0, beta0=1.0,      # Prior for rate estimation
phi=0.97,                    # Discount factor for old data
kappa=0.2,                   # Uncertainty weight
eta=0.2,                     # Burst weight
rho=1.5,                     # Staleness weight (increased from 0.3)
delta=1.0,                   # Burst decay rate
gamma=0.2,                   # Burst sensitivity
tau=3.0,                     # Staleness timescale (decreased from 5.0)
p=2.0                        # Staleness curve shape (increased from 1.5)
```

---

## Future Enhancement Ideas

### 1. Dormancy Detection

**Goal**: Automatically detect when a post has "died" (no more new comments) and stop wasting resources on it.

**Algorithm Sketch**:

```
For each tree i:
    λ_hat = α[i] / β[i]                           # Estimated rate
    λ_upper = λ_hat + 2 * sqrt(λ_hat / β[i])      # Upper confidence bound
    age_since_last_comment = clock - last_comment_time[i]
    
    if λ_upper < λ_min and age_since_last_comment > T_min:
        mark tree as 'dormant'
```

**Parameters**:
- `λ_min`: Minimum rate threshold (e.g., 1e-3 comments/minute)
- `T_min`: Minimum age before considering dormancy (e.g., 200 minutes)

### 2. Extended Priority with Dormancy

```python
def score(self, tid):
    t = self.trees[tid]
    if t.get("dormant", False):
        return 0.0  # Skip dormant trees entirely
    dt = self.clock - t["t_last"]
    # ... same formula as before
```

### 3. Maintenance Sweep

Periodically check all trees for dormancy:

```python
def maintenance(self, λ_min=1e-3, T_min=200.0):
    for tid, t in list(self.trees.items()):
        λ_hat = t["alpha"] / t["beta"]
        λ_upper = λ_hat + 2 * math.sqrt(max(λ_hat, 1e-12) / t["beta"])
        age = self.clock - t["t_last"]
        
        if λ_upper < λ_min and age > T_min:
            t["dormant"] = True
        else:
            t["dormant"] = False
```

### 4. Dynamic Post Addition

When new posts appear (e.g., from /new feed):

```python
def add_tree(self, tree_id):
    if tree_id not in self.trees:
        # Initialize with global average priors
        global_alpha = sum(t["alpha"] for t in self.trees.values()) / len(self.trees)
        global_beta = sum(t["beta"] for t in self.trees.values()) / len(self.trees)
        
        self.trees[tree_id] = {
            "alpha": global_alpha,
            "beta": global_beta,
            "b": 0.0,
            "t_last": self.clock,
            "k_obs": 0,
            "dormant": False
        }
```

**Benefit**: New posts inherit learned priors from existing posts instead of starting from scratch.

---

## Discussion Topics

### Questions to Consider:

1. **Dormancy Threshold**: What's a good `λ_min` and `T_min`?
   - Too aggressive: Might miss late-stage activity
   - Too conservative: Wastes resources on dead posts

2. **Resurrection**: Should dormant posts ever come back?
   - If a dormant post suddenly gets new comments, should we detect that?
   - How would we know without checking it?

3. **Parameter Tuning**: Current weights seem to work, but could be optimized
   - More weight on uncertainty (kappa) = more exploration
   - More weight on staleness (rho) = more even coverage
   - More weight on expected yield = more exploitation

4. **Multi-Subreddit**: How would this scale to tracking multiple subreddits?
   - Separate monitors per subreddit?
   - Global monitor with subreddit tags?

---

## Original Pseudocode from ChatGPT Session

*(Preserved for reference)*

### When a new post appears:

```
if tree_id not in monitor.trees:
    monitor.trees[tree_id] = {
        "alpha": α0,
        "beta": β0,
        "b": 0.0,
        "t_last": monitor.clock,
        "k_obs": 0
    }
```

### Algorithm sketch for dormancy:

```
for each tree i:
    λ_hat = α[i] / β[i]
    λ_upper = λ_hat + 2 * sqrt(λ_hat / β[i])
    age_since_last_comment = clock - last_comment_time[i]
    if λ_upper < λ_min and age_since_last_comment > T_min:
        mark tree as 'dormant'
```

### Extend priority computation to skip or heavily downweight dormant trees:

```python
def score(self, tid):
    t = self.trees[tid]
    if t.get("dormant", False):
        return 0.0
    dt = self.clock - t["t_last"]
    ...
    # same formula as before
```

### Periodically run a maintenance sweep:

```python
def maintenance(self, λ_min=1e-3, T_min=200.0):
    for tid, t in list(self.trees.items()):
        λ_hat = t["alpha"] / t["beta"]
        λ_upper = λ_hat + 2 * math.sqrt(max(λ_hat,1e-12)/t["beta"])
        age = self.clock - t["t_last"]
        if λ_upper < λ_min and age > T_min:
            t["dormant"] = True
        else:
            t["dormant"] = False
```

### Putting it all together:

```python
def add_tree(self, tree_id):
    if tree_id not in self.trees:
        global_alpha = sum(t["alpha"] for t in self.trees.values()) / len(self.trees)
        global_beta  = sum(t["beta"]  for t in self.trees.values()) / len(self.trees)
        self.trees[tree_id] = {
            "alpha": global_alpha,
            "beta":  global_beta,
            "b": 0.0,
            "t_last": self.clock,
            "k_obs": 0,
            "dormant": False
        }

def maintenance(self, λ_min=1e-3, T_min=200.0):
    for tid, t in self.trees.items():
        lam_hat = t["alpha"] / t["beta"]
        lam_upper = lam_hat + 2 * math.sqrt(max(lam_hat,1e-12)/t["beta"])
        age = self.clock - t["t_last"]
        t["dormant"] = (lam_upper < λ_min and age > T_min)
```

---

## Add Your Thoughts Below:

*(User can add notes, questions, and ideas here for discussion)*

def relative_gain(self, tid, c=10.0, use_power=False, alpha=0.0):
    """
    c: pseudo-size baseline
    use_power=False uses log-approx E/(T+c)
    if use_power=True, uses power utility with exponent alpha in (0,1)
    """
    t  = self.trees[tid]
    dt = self.clock - t["t_last"]
    if dt <= 0:
        return 0.0
    lam_hat = t["alpha"] / t["beta"]
    E = lam_hat * dt
    T = t.get("total_size", t.get("k_obs", 0))  # current known size
    base = T + c
    if use_power and 0.0 < alpha < 1.0:
        # marginal utility ~ (T+c)^(alpha-1) * E
        return (base ** (alpha - 1.0)) * E
    else:
        # log utility approx: E / (T + c)
        return E / base

def score(self, tid,
          w_abs=1.0, w_rel=1.0, c=10.0,
          use_power=False, alpha=0.0):
    t = self.trees[tid]
    dt = self.clock - t["t_last"]
    if dt <= 0 or t.get("dormant", False):
        return 0.0
    # components you already had
    lam_hat = t["alpha"] / t["beta"]
    E = lam_hat * dt
    U = math.sqrt(lam_hat*dt + lam_hat*(dt**2)/t["beta"])
    H = t["b"]
    S = self.staleness(dt)

    rel = self.relative_gain(tid, c=c, use_power=use_power, alpha=alpha)

    return (w_abs * E) + (w_rel * rel) + self.params["kappa"]*U \
           + self.params["eta"]*H + self.params["rho"]*S
