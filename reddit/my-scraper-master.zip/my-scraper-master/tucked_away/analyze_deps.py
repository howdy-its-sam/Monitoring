import re

deps = set()
to_check = ['unified_scraper.py']
checked = set()

while to_check:
    current = to_check.pop()
    if current in checked:
        continue
    checked.add(current)
    
    try:
        with open(current) as f:
            for line in f:
                m = re.match(r'^from (\w+) import', line)
                if m:
                    module = m.group(1) + '.py'
                    if module not in checked:
                        deps.add(module)
                        to_check.append(module)
    except:
        pass

print("PRODUCTION FILES (used by unified_scraper.py):")
for d in sorted(deps):
    print(f"  {d}")
print(f"\nCore: unified_scraper.py")
print(f"Config: subreddit_priorities.txt, reddit_credentials.txt")
print(f"Data: adaptive_data/")
