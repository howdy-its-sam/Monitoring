# Reddit Button Patterns

## Patterns
shreddit-comment[collapsed] button:has(svg[icon-name='join-outline'])
shreddit-comment[collapsed]
a[href="#"]:has-text("Read More")
button[data-read-more-experiment-name="desktop_post_body_read_more"]
button:has-text("more replies")
faceplate-partial:has-text("more reply")
button:has-text("View more comments")
a:has-text("more replies")
a:has-text("more reply")
