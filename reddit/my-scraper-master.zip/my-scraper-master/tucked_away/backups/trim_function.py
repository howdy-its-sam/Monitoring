"""
JSON Tree Trimming Utility

This module provides functions to trim scraped Reddit data by keeping only
specified attributes, dramatically reducing file sizes for focused analysis.

Usage:
    # Trim a single file
    trimmed_data = trim_json_tree("scraped_posts/post_123.json", "username_text_only")
    
    # Trim entire directory
    trim_directory("scraped_posts/", "basic_analysis", "trimmed_posts/")
    
    # Get size reduction stats
    stats = get_trim_stats("original.json", "trimmed.json")
"""

import json
import os
import shutil
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple


def load_trim_profile(profile_name: str, profile_file: str = "attribute_subset.txt") -> Dict[str, str]:
    """
    Load a trimming profile from the attribute subset file.
    
    Args:
        profile_name: Name of the profile to load (e.g., "username_text_only")
        profile_file: Path to the attribute subset file
        
    Returns:
        Dictionary mapping attribute names to "keep" or "drop"
        
    Raises:
        FileNotFoundError: If profile file doesn't exist
        ValueError: If profile doesn't exist in file
    """
    try:
        with open(profile_file, 'r', encoding='utf-8') as f:
            content = f.read()
    except FileNotFoundError:
        raise FileNotFoundError(f"Profile file '{profile_file}' not found")
    
    # Find the profile section
    profile_section = f"[{profile_name}]"
    if profile_section not in content:
        available_profiles = []
        for line in content.split('\n'):
            if line.strip().startswith('[') and line.strip().endswith(']'):
                available_profiles.append(line.strip()[1:-1])
        raise ValueError(f"Profile '{profile_name}' not found. Available profiles: {available_profiles}")
    
    # Extract profile rules
    lines = content.split('\n')
    in_profile = False
    profile_rules = {}
    
    for line in lines:
        line = line.strip()
        
        # Skip empty lines and comments
        if not line or line.startswith('#'):
            continue
            
        # Check if we're entering the target profile
        if line == profile_section:
            in_profile = True
            continue
            
        # Check if we're entering a different profile
        if line.startswith('[') and line.endswith(']') and line != profile_section:
            in_profile = False
            continue
            
        # Parse attribute rules
        if in_profile and '=' in line:
            attr_name, action = line.split('=', 1)
            attr_name = attr_name.strip()
            action = action.strip().lower()
            
            if action in ['keep', 'drop']:
                profile_rules[attr_name] = action
            else:
                print(f"Warning: Unknown action '{action}' for attribute '{attr_name}'")
    
    print(f"Loaded trim profile '{profile_name}' with {len(profile_rules)} rules")
    return profile_rules


def trim_comment_object(comment: Dict[str, Any], profile_rules: Dict[str, str]) -> Dict[str, Any]:
    """
    Trim a single comment object according to profile rules.
    
    Args:
        comment: Comment dictionary to trim
        profile_rules: Rules defining which attributes to keep/drop
        
    Returns:
        Trimmed comment dictionary
    """
    trimmed_comment = {}
    
    # Process each attribute in the comment
    for attr_name, value in comment.items():
        # Check if this attribute should be kept
        if attr_name in profile_rules:
            if profile_rules[attr_name] == 'keep':
                trimmed_comment[attr_name] = value
            # If 'drop', we skip it entirely
        else:
            # Default behavior: drop if not specified in profile
            # (This allows profiles to be more concise)
            pass  # Skip attributes not explicitly marked to keep
    
    # Special handling for children (recursive trimming)
    if 'children' in trimmed_comment and isinstance(trimmed_comment['children'], list):
        trimmed_children = []
        for child in trimmed_comment['children']:
            trimmed_child = trim_comment_object(child, profile_rules)
            trimmed_children.append(trimmed_child)
        trimmed_comment['children'] = trimmed_children
    
    return trimmed_comment


def trim_json_tree(input_file: str, profile_name: str, output_file: Optional[str] = None) -> Dict[str, Any]:
    """
    Trim a scraped Reddit JSON file to keep only specified attributes.
    
    Args:
        input_file: Path to the input JSON file
        profile_name: Name of the trim profile to use
        output_file: Optional output file path (if None, returns data in memory)
        
    Returns:
        Trimmed data dictionary
        
    Raises:
        FileNotFoundError: If input file doesn't exist
        ValueError: If profile doesn't exist
    """
    print(f"🔧 Trimming {input_file} using profile '{profile_name}'")
    
    # Load the trim profile
    profile_rules = load_trim_profile(profile_name)
    
    # Load the input data
    try:
        with open(input_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except FileNotFoundError:
        raise FileNotFoundError(f"Input file '{input_file}' not found")
    
    # Generate output filename if not provided
    if output_file is None:
        base_name = os.path.splitext(input_file)[0]
        output_file = f"{base_name}_trimmed_{profile_name}.json"
    
    # Trim the data
    print(f"  📊 Original data structure loaded")
    
    # Handle post-level attributes
    trimmed_data = {}
    for attr_name, value in data.items():
        if attr_name == 'comments':
            # Special handling for comments tree
            trimmed_comments = {}
            for comment_id, comment_obj in value.items():
                trimmed_comment = trim_comment_object(comment_obj, profile_rules)
                trimmed_comments[comment_id] = trimmed_comment
            trimmed_data[attr_name] = trimmed_comments
        else:
            # Always preserve post-level attributes completely
            trimmed_data[attr_name] = value
    
    # Save the trimmed data
    try:
        os.makedirs(os.path.dirname(output_file), exist_ok=True)
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(trimmed_data, f, indent=2, ensure_ascii=False)
        print(f"  ✅ Trimmed data saved to: {output_file}")
    except Exception as e:
        print(f"  ❌ Error saving trimmed data: {e}")
        raise
    
    # Calculate and report size reduction
    original_size = os.path.getsize(input_file)
    trimmed_size = os.path.getsize(output_file)
    reduction_percent = ((original_size - trimmed_size) / original_size) * 100
    
    print(f"  📈 Size reduction: {original_size:,} bytes → {trimmed_size:,} bytes ({reduction_percent:.1f}% smaller)")
    
    return trimmed_data


def trim_directory(input_dir: str, profile_name: str, output_dir: str) -> Dict[str, Any]:
    """
    Trim all JSON files in a directory using the specified profile.
    
    Args:
        input_dir: Directory containing JSON files to trim
        profile_name: Name of the trim profile to use
        output_dir: Directory to save trimmed files
        
    Returns:
        Dictionary with processing statistics
    """
    print(f"🗂️  Trimming all JSON files in '{input_dir}' using profile '{profile_name}'")
    
    # Ensure output directory exists
    os.makedirs(output_dir, exist_ok=True)
    
    # Find all JSON files
    json_files = [f for f in os.listdir(input_dir) if f.endswith('.json')]
    
    if not json_files:
        print(f"  ⚠️  No JSON files found in '{input_dir}'")
        return {"processed": 0, "errors": 0}
    
    print(f"  📋 Found {len(json_files)} JSON files to process")
    
    stats = {
        "processed": 0,
        "errors": 0,
        "total_original_size": 0,
        "total_trimmed_size": 0,
        "files": []
    }
    
    for json_file in json_files:
        input_path = os.path.join(input_dir, json_file)
        
        # Generate output filename
        base_name = os.path.splitext(json_file)[0]
        output_filename = f"{base_name}_trimmed_{profile_name}.json"
        output_path = os.path.join(output_dir, output_filename)
        
        try:
            # Trim the file
            trim_json_tree(input_path, profile_name, output_path)
            
            # Update statistics
            original_size = os.path.getsize(input_path)
            trimmed_size = os.path.getsize(output_path)
            
            stats["processed"] += 1
            stats["total_original_size"] += original_size
            stats["total_trimmed_size"] += trimmed_size
            stats["files"].append({
                "filename": json_file,
                "original_size": original_size,
                "trimmed_size": trimmed_size,
                "reduction_percent": ((original_size - trimmed_size) / original_size) * 100
            })
            
        except Exception as e:
            print(f"  ❌ Error processing {json_file}: {e}")
            stats["errors"] += 1
    
    # Print summary
    print(f"\n📊 Directory trimming summary:")
    print(f"  ✅ Successfully processed: {stats['processed']} files")
    print(f"  ❌ Errors: {stats['errors']} files")
    
    if stats["processed"] > 0:
        total_reduction = ((stats["total_original_size"] - stats["total_trimmed_size"]) / stats["total_original_size"]) * 100
        print(f"  📈 Total size reduction: {stats['total_original_size']:,} bytes → {stats['total_trimmed_size']:,} bytes ({total_reduction:.1f}% smaller)")
    
    return stats


def get_trim_stats(original_file: str, trimmed_file: str) -> Dict[str, Any]:
    """
    Get statistics comparing original and trimmed files.
    
    Args:
        original_file: Path to original file
        trimmed_file: Path to trimmed file
        
    Returns:
        Dictionary with comparison statistics
    """
    try:
        original_size = os.path.getsize(original_file)
        trimmed_size = os.path.getsize(trimmed_file)
        
        reduction_percent = ((original_size - trimmed_size) / original_size) * 100
        
        return {
            "original_size": original_size,
            "trimmed_size": trimmed_size,
            "size_reduction": original_size - trimmed_size,
            "reduction_percent": reduction_percent,
            "compression_ratio": original_size / trimmed_size if trimmed_size > 0 else float('inf')
        }
    except FileNotFoundError as e:
        raise FileNotFoundError(f"Could not find file: {e}")


def list_available_profiles(profile_file: str = "attribute_subset.txt") -> List[str]:
    """
    List all available trim profiles.
    
    Args:
        profile_file: Path to the attribute subset file
        
    Returns:
        List of available profile names
    """
    try:
        with open(profile_file, 'r', encoding='utf-8') as f:
            content = f.read()
    except FileNotFoundError:
        raise FileNotFoundError(f"Profile file '{profile_file}' not found")
    
    profiles = []
    for line in content.split('\n'):
        line = line.strip()
        if line.startswith('[') and line.endswith(']'):
            profile_name = line[1:-1]
            if profile_name and not profile_name.startswith('#'):
                profiles.append(profile_name)
    
    return profiles


# Example usage and testing
if __name__ == "__main__":
    # List available profiles
    try:
        profiles = list_available_profiles()
        print(f"Available trim profiles: {profiles}")
    except FileNotFoundError:
        print("❌ attribute_subset.txt not found")
    
    # Example: Trim a file (uncomment to test)
    # try:
    #     trimmed_data = trim_json_tree("scraped_posts/scraped_post_123.json", "username_text_only")
    #     print("✅ Trimming completed successfully")
    # except Exception as e:
    #     print(f"❌ Error: {e}")
