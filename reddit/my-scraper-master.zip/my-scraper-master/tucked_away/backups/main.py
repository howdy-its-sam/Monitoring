import os
import sys
import time
from datetime import datetime

from reddit_scraper_dfs import scrape_reddit_post_dfs
from trim_function import trim_json_tree
from username_obfuscator import obfuscate_usernames


def scrape_url_list(urls, delay_between_scrapes=5, auto_process=True):
    """
    Scrape a list of Reddit URLs systematically.
    
    Args:
        urls (list): List of Reddit post URLs to scrape
        delay_between_scrapes (int): Seconds to wait between each scrape (default: 5)
        auto_process (bool): Whether to automatically trim and obfuscate after scraping (default: True)
    """
    print(f"🚀 Starting batch scraping of {len(urls)} URLs")
    print(f"⏱️  Delay between scrapes: {delay_between_scrapes} seconds")
    print(f"📅 Start time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("-" * 60)
    
    results = []
    successful_scrapes = 0
    failed_scrapes = 0
    
    for i, url in enumerate(urls, 1):
        print(f"\n📋 Processing URL {i}/{len(urls)}: {url}")
        print(f"⏰ Time: {datetime.now().strftime('%H:%M:%S')}")
        
        try:
            # Generate output filename with 2-digit prefix
            import re
            post_id_match = re.search(r'/comments/([^/]+)/', url)
            if post_id_match:
                post_id = post_id_match.group(1)
                output_file = f"scraped_posts/scraped_post_{i:02d}_{post_id}.json"
            else:
                output_file = f"scraped_posts/scraped_post_{i:02d}_fallback.json"
            
            # Call the DFS function to scrape and structure the entire Reddit post
            post_data = scrape_reddit_post_dfs(url, output_file)
            
            # Check if scraping was successful
            if "error" in post_data:
                print(f"❌ Failed to scrape URL {i}: {post_data['error']}")
                failed_scrapes += 1
                results.append({
                    "url": url,
                    "success": False,
                    "error": post_data["error"],
                    "timestamp": datetime.now().isoformat()
                })
            else:
                print(f"✅ Successfully scraped URL {i}")
                print(f"   📊 Comments found: {post_data.get('total_comments', 0)}")
                
                # Auto-process the scraped data if enabled
                if auto_process:
                    try:
                        print(f"   🔧 Auto-processing: trim + obfuscate...")
                        
                        # Use the same filename that was passed to the scraper
                        scraped_file = output_file
                        
                        # Generate intermediate and final filenames
                        if post_id_match:
                            trimmed_file = f"scraped_posts/scraped_post_{i:02d}_{post_id}_trimmed.json"
                            final_file = f"scraped_posts/scraped_post_{i:02d}_{post_id}_final.json"
                        else:
                            trimmed_file = f"scraped_posts/scraped_post_{i:02d}_fallback_trimmed.json"
                            final_file = f"scraped_posts/scraped_post_{i:02d}_fallback_final.json"
                        
                        trim_json_tree(scraped_file, 'username_text_only', trimmed_file)
                        obfuscate_usernames(trimmed_file, final_file, seed=42)
                        
                        print(f"   ✅ Final processed file: {final_file}")
                        
                        # Clean up intermediate files
                        if os.path.exists(trimmed_file):
                            os.remove(trimmed_file)
                        
                    except Exception as process_error:
                        print(f"   ⚠️  Auto-processing failed: {process_error}")
                        print(f"   📄 Raw scraped data still available")
                
                successful_scrapes += 1
                results.append({
                    "url": url,
                    "success": True,
                    "comments_count": post_data.get('total_comments', 0),
                    "auto_processed": auto_process,
                    "timestamp": datetime.now().isoformat()
                })
                
        except Exception as e:
            print(f"❌ Exception occurred while scraping URL {i}: {e}")
            failed_scrapes += 1
            results.append({
                "url": url,
                "success": False,
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            })
        
        # Add delay between scrapes (except for the last one)
        if i < len(urls):
            print(f"⏳ Waiting {delay_between_scrapes} seconds before next scrape...")
            time.sleep(delay_between_scrapes)
    
    # Print final summary
    print("\n" + "=" * 60)
    print("📊 BATCH SCRAPING SUMMARY")
    print("=" * 60)
    print(f"✅ Successful scrapes: {successful_scrapes}")
    print(f"❌ Failed scrapes: {failed_scrapes}")
    print(f"📈 Success rate: {(successful_scrapes/len(urls)*100):.1f}%")
    if auto_process:
        print(f"🔧 Auto-processing: ENABLED (trim + obfuscate)")
    else:
        print(f"🔧 Auto-processing: DISABLED")
    print(f"📅 End time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    # Save results summary
    summary_file = f"scraped_posts/batch_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    os.makedirs("scraped_posts", exist_ok=True)
    
    import json
    with open(summary_file, 'w', encoding='utf-8') as f:
        json.dump({
            "summary": {
                "total_urls": len(urls),
                "successful_scrapes": successful_scrapes,
                "failed_scrapes": failed_scrapes,
                "success_rate": successful_scrapes/len(urls)*100,
                "start_time": results[0]["timestamp"] if results else None,
                "end_time": results[-1]["timestamp"] if results else None
            },
            "results": results
        }, f, indent=4, ensure_ascii=False)
    
    print(f"📄 Results summary saved to: {summary_file}")
    
    return results


def read_urls_from_file(filename="urls_to_scrape.txt"):
    """Read URLs from a text file, ignoring comments and empty lines"""
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        urls = []
        for line_num, line in enumerate(lines, 1):
            line = line.strip()
            
            # Skip empty lines and comments
            if not line or line.startswith('#'):
                continue
            
            # Validate URL format
            if line.startswith('http'):
                urls.append(line)
            else:
                print(f"⚠️  Warning: Line {line_num} doesn't look like a URL: {line}")
        
        return urls
    
    except FileNotFoundError:
        print(f"❌ URLs file '{filename}' not found!")
        print("Please create 'urls_to_scrape.txt' with your Reddit URLs (one per line)")
        return []
    except Exception as e:
        print(f"❌ Error reading URLs file: {e}")
        return []


if __name__ == "__main__":
    # URLs are now read from urls_to_scrape.txt file
    urls_to_scrape = read_urls_from_file()
    
    # Validate that URLs are provided
    if not urls_to_scrape:
        print("❌ No URLs provided!")
        print("Please add your Reddit URLs to 'urls_to_scrape.txt' (one URL per line)")
        print("Lines starting with # are comments and will be ignored")
        sys.exit(1)
    
    print(f"🎯 Found {len(urls_to_scrape)} URLs to scrape")
    print(f"🔧 Auto-processing: ENABLED (will trim + obfuscate after each scrape)")
    
    # Start batch scraping with auto-processing
    scrape_url_list(urls_to_scrape, delay_between_scrapes=5, auto_process=True)

