from playwright.sync_api import sync_playwright
import json
import time
from datetime import datetime
import re
import os

def extract_post_id(url):
    """Extract post ID from Reddit URL"""
    # Pattern to match Reddit post URLs: /r/subreddit/comments/POST_ID/title/
    pattern = r'/r/\w+/comments/([^/]+)/'
    match = re.search(pattern, url)
    if match:
        return match.group(1)
    else:
        # Fallback: use a hash of the URL if pattern doesn't match
        return str(hash(url))[-8:]

def load_attribute_configs():
    """Load attribute configurations from external files"""
    comment_attrs = {}
    post_attrs = {}
    
    # Load comment attributes
    try:
        with open('comment_attributes.txt', 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#'):
                    if '=' in line:
                        key, value = line.split('=', 1)
                        comment_attrs[key.strip()] = value.strip()
    except FileNotFoundError:
        print("Warning: comment_attributes.txt not found, using default attributes")
        # Default comment attributes
        comment_attrs = {
            'id': 'thingid',
            'username': 'author',
            'text': '[slot="comment"] p, [slot="comment"] div',
            'score': 'score',
            'parent_id': 'parentid'
        }
    
    # Load post attributes
    try:
        with open('post_attributes.txt', 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#'):
                    if '=' in line:
                        key, value = line.split('=', 1)
                        post_attrs[key.strip()] = value.strip()
    except FileNotFoundError:
        print("Warning: post_attributes.txt not found, using default attributes")
        # Default post attributes
        post_attrs = {
            'title': 'h1[slot=\'title\']',
            'author': 'a.author-name',
            'text': 'div[id*=\'-post-rtjson-content\']'
        }
    
    return comment_attrs, post_attrs

def read_button_patterns(patterns_file="button_patterns.md"):
    """
    Read button patterns from the markdown file.
    Returns a list of (selector, name) tuples.
    """
    patterns = []
    
    try:
        with open(patterns_file, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        in_patterns_section = False
        
        for line in lines:
            line = line.strip()
            
            # Skip empty lines
            if not line:
                continue
            
            # Detect patterns section
            if line == '## Patterns' and line.startswith('##'):
                in_patterns_section = True
                continue
            elif line.startswith('##'):
                in_patterns_section = False
                continue
            
            # Parse pattern lines (just the selector, generate a simple name)
            if in_patterns_section and line:
                # Generate a simple name from the selector
                if 'join-outline' in line:
                    name = "Comment expand button"
                elif 'collapsed]' in line and 'button' not in line:
                    name = "Collapsed comment container"
                elif 'Read More' in line:
                    name = "Read More button"
                elif 'View more comments' in line:
                    name = "View more comments button"
                elif 'more replies' in line:
                    name = "More replies button"
                elif 'more reply' in line:
                    name = "More reply container"
                else:
                    name = f"Pattern: {line[:50]}..."
                
                patterns.append((line, name))
        
        print(f"Loaded {len(patterns)} button patterns")
        return patterns
        
    except FileNotFoundError:
        raise FileNotFoundError(f"Button patterns file '{patterns_file}' not found. Please ensure the file exists and contains the required button patterns.")
    except Exception as e:
        raise Exception(f"Error reading button patterns from '{patterns_file}': {e}")

def scrape_reddit_post_dfs(url, output_file=None, comment_attrs=None, post_attrs=None):
    """
    Scrape a Reddit post using the exact DFS approach from the GUI controller.
    This implements the same recursive button-clicking algorithm with navigation detection.
    """
    print(f"🚀 Starting DFS Reddit post scraping for: {url}")
    
    # Generate output filename if not provided
    if output_file is None:
        post_id = extract_post_id(url)
        output_file = f"scraped_posts/scraped_post_{post_id}.json"
    
    # Ensure the scraped_posts directory exists
    os.makedirs("scraped_posts", exist_ok=True)
    
    # Load attribute configurations if not provided
    if comment_attrs is None or post_attrs is None:
        loaded_comment_attrs, loaded_post_attrs = load_attribute_configs()
        if comment_attrs is None:
            comment_attrs = loaded_comment_attrs
        if post_attrs is None:
            post_attrs = loaded_post_attrs
    
    # Initialize data structures (matching GUI approach)
    post_data = {
        "url": url,
        "title": "N/A", 
        "author": "N/A",
        "post_text": "N/A",
        "total_comments": 0,
        "extraction_timestamp": "",
        "comments": {}  # Hierarchical structure like GUI
    }
    
    # State tracking (matching GUI)
    comment_tree = {}
    comment_lookup_cache = {}  # O(1) lookup cache for comments by ID
    processed_comments = set()
    clicked_navigation_buttons = set()  # Track ONLY buttons that cause navigation
    clicked_all_buttons = set()  # Track ALL clicked buttons to avoid re-clicking
    navigation_depth = 0  # Track how deep we are in navigation calls
    
    
    
    def get_button_identifier(button):
        """Create a unique identifier for a button to track if it's been clicked - PROVEN ALGORITHM FROM GUI VERSION"""
        try:
            # Try to get href for links
            href = button.get_attribute('href')
            if href and href != '#':
                return f"href:{href}"
            
            # Try to get text content
            text = button.inner_text()
            if text:
                text = text.strip()[:50]  # Limit length
                
            # Get position as fallback
            position = button.bounding_box()
            if position:
                pos_str = f"x{int(position['x'])}_y{int(position['y'])}"
            else:
                pos_str = "no_pos"
            
            # Combine text and position for unique ID
            if text:
                return f"text:{text}_pos:{pos_str}"
            else:
                return f"pos:{pos_str}"
                
        except Exception as e:
            # Fallback to position only
            try:
                position = button.bounding_box()
                if position:
                    return f"fallback_pos:x{int(position['x'])}_y{int(position['y'])}"
                else:
                    return f"fallback_random:{hash(str(button))}"
            except:
                return f"fallback_random:{hash(str(button))}"
    
    def is_last_comment(page, comment_element):
        """Check if a comment is the last one on the page using DOM position analysis"""
        try:
            # Get all comments on the page
            all_comments = page.query_selector_all('shreddit-comment')
            if not all_comments:
                return False
            
            # Find the last comment
            last_comment = all_comments[-1]
            
            # Check if this comment is the last one
            # We compare by checking if they have the same thingid attribute
            this_id = comment_element.get_attribute('thingid')
            last_id = last_comment.get_attribute('thingid')
            
            if this_id and last_id:
                return this_id == last_id
            
            # Fallback: compare element references directly
            return comment_element == last_comment
            
        except Exception as e:
            print(f"Error checking if last comment: {e}")
            return False
    
    def get_last_comment_on_page(page):
        """Get the last comment element on the page"""
        try:
            all_comments = page.query_selector_all('shreddit-comment')
            if all_comments:
                return all_comments[-1]
            return None
        except Exception as e:
            print(f"Error getting last comment: {e}")
            return None
    
    def find_comment_in_tree(comment_id):
        """Find a comment by ID using O(1) hashmap lookup"""
        return comment_lookup_cache.get(comment_id)
    
    def calculate_true_depth(comment_id, parent_id):
        """Calculate the true depth of a comment based on its parent chain (from GUI)"""
        if not parent_id:
            return 0  # Top-level comment
        
        # Find the parent comment
        parent_comment = find_comment_in_tree(parent_id)
        if parent_comment:
            return parent_comment.get('depth', 0) + 1
        
        # If parent not found, try to estimate based on existing comments with same parent
        def search_for_sibling_depth(tree, target_parent_id):
            for cid, comment in tree.items():
                if comment.get('parent_id') == target_parent_id:
                    return comment.get('depth', 0)
                # Search in children
                if comment.get('children'):
                    child_tree = {child['id']: child for child in comment['children']}
                    result = search_for_sibling_depth(child_tree, target_parent_id)
                    if result is not None:
                        return result
            return None
        
        sibling_depth = search_for_sibling_depth(comment_tree, parent_id)
        if sibling_depth is not None:
            return sibling_depth
        
        # Default fallback - assume depth 1 if we have a parent but can't find it
        return 1
    
    def add_comment_to_tree(comment_data, tree_node):
        """Add comment to tree using O(1) hashmap lookup"""
        comment_id = comment_data['id']
        parent_id = comment_data['parent_id']
        
        # Add to lookup cache for O(1) future lookups
        comment_lookup_cache[comment_id] = comment_data
        
        if parent_id is None:
            # Top-level comment - add to root tree
            comment_tree[comment_id] = comment_data
            return True
        else:
            # Find parent using O(1) lookup
            parent_comment = comment_lookup_cache.get(parent_id)
            if parent_comment:
                # Initialize children list if it doesn't exist
                if 'children' not in parent_comment:
                    parent_comment['children'] = []
                parent_comment['children'].append(comment_data)
                return True
            else:
                # Parent not found yet - add to root tree temporarily
                # It will be moved when parent is processed
                comment_tree[comment_id] = comment_data
                return True
    
    def extract_comment_tree(page):
        """Extract and update the comment tree structure from the current page (from GUI)"""
        try:
            # Find all comment elements on the page
            comment_elements = page.query_selector_all('shreddit-comment')
            new_comments_found = 0
            error_count = 0
            max_errors = 50  # Stop if we get too many errors
            
            for i, comment in enumerate(comment_elements):
                if error_count > max_errors:
                    print(f"  ⚠️  Too many errors ({error_count}), stopping comment processing")
                    break
                try:
                    # Extract all configured comment attributes
                    comment_data = {}
                    try:
                        for attr_name, selector in comment_attrs.items():
                            if selector.startswith('[') and '=' in selector:
                                # CSS selector - query the element
                                element = comment.query_selector(selector)
                                if element:
                                    text = element.inner_text()
                                    comment_data[attr_name] = text.strip() if text else None
                                else:
                                    comment_data[attr_name] = None
                            else:
                                # Attribute name - get from element attributes
                                comment_data[attr_name] = comment.get_attribute(selector) or None
                        
                    except Exception as attr_error:
                        error_count += 1
                        print(f"    Error extracting attributes: {attr_error}")
                        # Ensure comment_data is still a valid dict even if attribute extraction fails
                        if not isinstance(comment_data, dict):
                            comment_data = {}
                    
                    # Get comment ID for processing logic
                    if not comment_data or not isinstance(comment_data, dict):
                        print(f"    Error: comment_data is not a valid dict: {type(comment_data)}")
                        continue
                    
                    comment_id = comment_data.get('id')
                    if not comment_id:
                        continue
                    
                    # Check if already processed
                    already_exists = comment_id in processed_comments
                    existing_comment = find_comment_in_tree(comment_id)
                    
                    # Skip if already processed AND has body text (fully processed)
                    existing_text_for_check = existing_comment.get('text', '') or '' if existing_comment else ''
                    if already_exists and existing_comment and existing_text_for_check and existing_text_for_check.strip():
                        continue
                    
                    # Extract username and score for processing logic
                    username = comment_data.get('username', 'Unknown')
                    current_score = comment_data.get('score', '0')
                    comment_text = comment_data.get('text') or ''
                    if comment_text is None:
                        comment_text = ''
                    parent_id = comment_data.get('parent_id')
                    
                    # Calculate true depth based on parent relationships
                    true_depth = calculate_true_depth(comment_id, parent_id)
                    
                    # Create or update comment object
                    if already_exists and existing_comment:
                        # Handle text changes and edit history tracking
                        existing_text = existing_comment.get('text', '') or ''
                        existing_text = existing_text.strip() if existing_text else ''
                        if comment_text and comment_text.strip() and comment_text.strip() != existing_text:
                            if existing_text:  # This is an edit, not initial text
                                # Add previous text to history
                                if 'text_history' not in existing_comment:
                                    existing_comment['text_history'] = []
                                existing_comment['text_history'].append([existing_text, existing_comment.get('last_edit_timestamp', datetime.now().isoformat())])
                                
                                # Update edit tracking
                                existing_comment['edit_count'] = existing_comment.get('edit_count', 0) + 1
                                existing_comment['last_edit_timestamp'] = datetime.now().isoformat()
                                
                                print(f"    📝 Comment {comment_id} edited (edit #{existing_comment['edit_count']})")
                            else:
                                # First time getting text for this comment
                                existing_comment['last_edit_timestamp'] = datetime.now().isoformat()
                                existing_comment['edit_count'] = 0
                            
                            # Update current text
                            existing_comment['text'] = comment_text
                            new_comments_found += 1  # Count as new content
                        
                        # Also update depth if it was incorrectly calculated before
                        if existing_comment.get('depth', -1) != true_depth:
                            existing_comment['depth'] = true_depth
                        
                        # Update score history if score changed
                        existing_score = existing_comment.get('current_score', '0')
                        if existing_score != current_score:
                            if 'score_history' not in existing_comment:
                                existing_comment['score_history'] = []
                            existing_comment['score_history'].append([current_score, datetime.now().isoformat()])
                            existing_comment['current_score'] = current_score
                    else:
                        # Create new comment object with all extracted attributes
                        comment_obj = comment_data.copy()  # Start with all extracted attributes
                        comment_obj.update({
                            'depth': true_depth,
                            'children': [],
                            'current_score': current_score,
                            'score_history': [[current_score, datetime.now().isoformat()]],
                            'edit_count': 0,
                            'last_edit_timestamp': datetime.now().isoformat(),
                            'text_history': []
                        })
                        
                        # Add to tree structure
                        if true_depth == 0:
                            # Top-level comment
                            comment_tree[comment_id] = comment_obj
                        else:
                            # Find parent and add as child
                            add_comment_to_tree(comment_obj, comment_tree)
                        
                        processed_comments.add(comment_id)
                        new_comments_found += 1
                    
                except Exception as e:
                    error_count += 1
                    print(f"    Error processing comment: {e}")
                    continue
            
            return new_comments_found > 0
            
        except Exception as e:
            print(f"  Error extracting comments: {e}")
            return False
    
    def scan_all_buttons(page):
        """Scan and report all available buttons for debugging"""
        # Use all patterns from the loaded file
        all_patterns = button_patterns
        
        total_found = 0
        available_count = 0
        for selector, name in all_patterns:
            try:
                buttons = page.query_selector_all(selector)
                visible_buttons = [b for b in buttons if b.is_visible()]
                count = len(visible_buttons)
                total_found += count
                
                # Count available buttons
                for button in visible_buttons:
                    try:
                        button_id = get_button_identifier(button)
                        if button_id and button_id not in clicked_all_buttons:
                            available_count += 1
                    except:
                        pass
                        
            except Exception as e:
                pass
        
        return total_found

    def find_next_button(page):
        """Find the next available button using position-based ordering - click buttons top to bottom"""
        try:
            # Use all patterns from the loaded file
            all_patterns = button_patterns
            
            # Collect ALL unclicked buttons from ALL patterns with their positions
            all_buttons_with_positions = []
            
            for selector, name in all_patterns:
                try:
                    buttons = page.query_selector_all(selector)
                    for i, button in enumerate(buttons):
                        if button.is_visible():
                            # Check if this button was already clicked
                            try:
                                button_id = get_button_identifier(button)
                                if button_id and button_id in clicked_all_buttons:
                                    continue  # Skip already clicked button
                            except:
                                pass
                            
                            # Get button position for sorting
                            try:
                                bounding_box = button.bounding_box()
                                y_position = bounding_box['y'] if bounding_box else 999999
                            except:
                                y_position = 999999
                            
                            # Add to collection with position
                            all_buttons_with_positions.append((y_position, f"{name} (#{i+1})", button))
                except Exception:
                    continue
            
            # Sort by position (top to bottom) and return the topmost button
            if all_buttons_with_positions:
                all_buttons_with_positions.sort(key=lambda x: x[0])  # Sort by y position
                _, button_info, button_element = all_buttons_with_positions[0]
                return (button_info, button_element)
            else:
                return None  # No unclicked buttons found
            
        except Exception as e:
            print(f"  Error finding buttons: {e}")
            return None
    
    def scroll_action(page):
        """Scroll down 0.75 page height - PROVEN ALGORITHM FROM GUI VERSION"""
        print("ACTION: Scroll")
        try:
            # Check if page is available
            if not page:
                raise Exception("Page not available")
            
            print("  Getting viewport dimensions...")
            viewport_height = page.evaluate("window.innerHeight")
            current_scroll = page.evaluate("window.pageYOffset")
            scroll_increment = int(viewport_height * 0.75)
            new_scroll_position = current_scroll + scroll_increment
            
            print(f"  Viewport height: {viewport_height}px")
            print(f"  Current scroll: {current_scroll}px")
            print(f"  Scrolling to: {new_scroll_position}px")
            
            # Perform scroll
            page.evaluate(f"window.scrollTo({{top: {new_scroll_position}, behavior: 'smooth'}})")
            
            # Verify scroll happened (after a brief delay)
            page.wait_for_timeout(500)
            try:
                actual_position = page.evaluate("window.pageYOffset")
                print(f"  Final scroll position: {actual_position}px")
            except Exception as e:
                print(f"  Could not verify scroll: {e}")
            
            print("  Scrolled successfully")
            
        except Exception as e:
            print(f"  Scroll error: {e}")
            raise e
    
    def click_button_and_extract(page, button):
        """Click a button and handle navigation detection. Returns True if navigation occurred."""
        nonlocal navigation_depth
        
        try:
            current_url = page.url
            
            # Get button identifier before clicking (for navigation button tracking)
            button_id = None
            try:
                button_id = get_button_identifier(button)
            except:
                pass
            
            # Scroll button into view and click
            button.scroll_into_view_if_needed()
            button.click()
            
            # Check for navigation
            try:
                page.wait_for_url(current_url, timeout=2000)
                
                # Even if no navigation, extract comments for content that may have expanded
                try:
                    extract_comment_tree(page)
                except Exception as extract_error:
                    pass
                
                # Track ALL clicked buttons to prevent re-clicking
                if button_id:
                    clicked_all_buttons.add(button_id)
                
                return False
            except:
                navigation_depth += 1
                print(f"  Navigation detected (depth: {navigation_depth}) - recursively scraping new page then going back")
                
                # FULLY SCRAPE the navigated page recursively
                # Wait a moment for the new page to load
                page.wait_for_selector("shreddit-comment", timeout=5000)
                
                # Recursively scrape the entire navigated page using DFS
                print(f"  🔄 Starting recursive DFS scrape on navigated page (depth: {navigation_depth})")
                dfs_comment_scrape(page)
                print(f"  ✓ Completed recursive DFS scrape of navigated page")
                
                print(f"  Going back to original page (target URL: {current_url})")
                page.go_back()
                
                # Wait for original page to load and verify we're back
                try:
                    page.wait_for_selector("shreddit-comment", timeout=5000)
                    
                    # Verify we're back on the expected page
                    actual_url = page.url
                    if actual_url != current_url:
                        print(f"  WARNING: Expected to return to {current_url} but got {actual_url}")
                    else:
                        print(f"  ✓ Successfully returned to original page")
                        
                except Exception as e:
                    pass
                
                # Extract data from the original page after returning (in case new content appeared)
                try:
                    extract_comment_tree(page)
                except Exception as extract_error:
                    pass
                
                navigation_depth -= 1
                
                # Track ALL clicked buttons to prevent re-clicking them
                if button_id:
                    clicked_all_buttons.add(button_id)
                
                # ALSO track navigation buttons separately for navigation-specific logic
                if button_id:
                    clicked_navigation_buttons.add(button_id)
                
                return True
                
        except Exception as e:
            print(f"  Error clicking button: {e}")
            # Reset depth on error
            navigation_depth = max(0, navigation_depth - 1)
            return False
    
    def should_continue_scrolling(page):
        """Check if scrolling reveals new content by comparing last comment before/after scroll"""
        try:
            # Get current last comment
            current_last = get_last_comment_on_page(page)
            if not current_last:
                return False
            
            current_last_id = current_last.get_attribute('thingid')
            if not current_last_id:
                return False
            
            # Scroll down
            scroll_action(page)
            
            # Get new last comment after scroll
            new_last = get_last_comment_on_page(page)
            if not new_last:
                return False
            
            new_last_id = new_last.get_attribute('thingid')
            if not new_last_id:
                return False
            
            # Check if they're different (new content loaded)
            content_changed = current_last_id != new_last_id
            return content_changed
            
        except Exception as e:
            print(f"  Error checking scroll condition: {e}")
            return False

    def dfs_comment_scrape(page):
        """
        Depth-First Search comment scraping implementation - DYNAMIC SCROLL APPROACH
        
        This algorithm clicks any available button and handles navigation properly.
        All buttons are treated the same - we detect and handle navigation when it occurs.
        Scrolls continue until no new content is revealed.
        
        Pseudocode:
        Scroll
        Append_Data():
            Append newly available comment data as replies
            while(Pick != no_button_found):
                Click (any button)
                If nav detected, extract data and go back
                Append_Data()
        While(previous scroll changed the new last comment):
            Scroll
            Append_Data()
        """
        scroll_count = 0
        
        def append_data():
            """Extract and append newly available comment data"""
            # Extract and append new comments to tree
            extract_comment_tree(page)
            
            # Scan all buttons for debugging
            scan_all_buttons(page)
        
        # Initial scroll
        print(f"Initial scroll (count: {scroll_count + 1})")
        scroll_action(page)
        scroll_count += 1
        
        # Initial data append
        append_data()
        
        # Main loop: Click ALL visible buttons, then scroll if no new content
        while True:
            # First, click ALL visible buttons until none remain
            buttons_clicked_this_round = 0
            while True:
                # Find next button
                selected_button = find_next_button(page)
                
                if selected_button is None:
                    break
                
                button_info, button_element = selected_button
                
                # Click the button
                navigation_occurred = click_button_and_extract(page, button_element)
                
                # Extract any newly revealed content
                extract_comment_tree(page)
                
                buttons_clicked_this_round += 1
                
                # If navigation occurred, we've already gone back, so continue
                if navigation_occurred:
                    continue
            
            # SAFETY CHECK: Before scrolling, verify no clickable buttons remain
            remaining_button = find_next_button(page)
            
            if remaining_button:
                # Continue the button clicking loop instead of scrolling
                continue
            
            # After confirming no buttons remain, try to scroll for more content
            if should_continue_scrolling(page):
                scroll_count += 1
                print(f"Processing content after scroll {scroll_count}")
                append_data()
            else:
                break
        
        return scroll_count
    
    # Load button patterns from file
    button_patterns = read_button_patterns()
    
    # Main scraping logic
    try:
        with sync_playwright() as p:
            # Launch browser in headful mode (REQUIRED to avoid Reddit blocking)
            browser = p.chromium.launch(headless=False, slow_mo=500)  # Increased delay to reduce rate limiting
            page = browser.new_page()
            
            # Set user agent to avoid bot detection
            page.set_extra_http_headers({
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            })
            
            try:
                # Navigate to the URL
                print(f"🌐 Navigating to: {url}")
                response = page.goto(url, timeout=30000)
                
                # Check if we got blocked
                if response.status == 403:
                    print("❌ Access denied (403) - Reddit is blocking automated access")
                    return {"error": "Access denied - Reddit blocked the request"}
                elif response.status >= 400:
                    print(f"❌ HTTP error {response.status}")
                    return {"error": f"HTTP error {response.status}"}
                
                print(f"✅ Page loaded successfully (status: {response.status})")
                
                # Wait a moment for the page to load
                print("⏳ Waiting for page to fully load...")
                page.wait_for_timeout(3000)
                
                # Wait for page to load and try different selectors
                try:
                    page.wait_for_selector("shreddit-comment", timeout=10000)
                    print("✅ Found shreddit-comment elements")
                except:
                    print("⚠️  Timeout waiting for shreddit-comment, trying alternative selectors...")
                    try:
                        page.wait_for_selector('[data-testid="comment"]', timeout=5000)
                        print("✅ Found alternative comment elements")
                    except:
                        print("❌ No comment elements found - checking page content...")
                        # Check if we're on the right page
                        title = page.title()
                        print(f"Page title: {title}")
                        
                        # Try to find any comments at all
                        all_comments = page.query_selector_all('*[id*="comment"], *[class*="comment"]')
                        print(f"Found {len(all_comments)} potential comment elements")
                        
                        if len(all_comments) == 0:
                            print("❌ No comment elements found on page")
                            return {"error": "No comment elements found on page"}
                
                # Extract post data using configured attributes
                try:
                    for attr_name, selector in post_attrs.items():
                        # Check if it's a CSS selector (contains brackets, dots, or other CSS syntax)
                        if any(char in selector for char in ['[', '.', '#', ':', '>', ' ', '+', '~']):
                            # CSS selector - query the element
                            element = page.query_selector(selector)
                            if element:
                                text = element.inner_text()
                                post_data[attr_name] = text.strip() if text else None
                            else:
                                post_data[attr_name] = None
                        else:
                            # Attribute name - get from page attributes (skip for now as these aren't working)
                            # Most Reddit data is in DOM elements, not page attributes
                            post_data[attr_name] = None
                except Exception as e:
                    print(f"Could not extract post data: {e}")
                
                # Map extracted fields to expected output format
                if 'selftext' in post_data and post_data['selftext']:
                    post_data['post_text'] = post_data['selftext']
                
                # Perform DFS comment scraping
                dfs_comment_scrape(page)
                
            except Exception as e:
                print(f"❌ Error during scraping: {e}")
                import traceback
                traceback.print_exc()
                return {"error": f"Scraping failed: {e}"}
            
            # Move click monitoring outside the try/finally to avoid browser closure issues
            print("✅ DFS scraping completed!")
            
            # Automatically save the scraped data
            post_data.update({
                "total_comments": len(processed_comments),
                "extraction_timestamp": datetime.now().isoformat(),
                "comments": comment_tree
            })
            
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(post_data, f, indent=4, ensure_ascii=False)
            print(f"✅ Data automatically saved to {output_file}")
            
        # Always close browser after completion
        print("🔄 Closing browser and exiting...")
        try:
            browser.close()
        except:
            pass
        print("✅ Program completed successfully!")
        return post_data
                    
    except Exception as e:
        print(f"❌ Failed to initialize browser: {e}")
        return {"error": f"Browser initialization failed: {e}"}
    
    # Format and return the result (matching GUI structure)
    post_data.update({
        "total_comments": len(processed_comments),
        "extraction_timestamp": datetime.now().isoformat(),
        "comments": comment_tree
    })
    
    print(f"\n🎉 Scraping completed successfully!")
    print(f"   Total comments: {post_data['total_comments']}")
    print(f"   Timestamp: {post_data['extraction_timestamp']}")
    
    # Save the structured data to a JSON file
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(post_data, f, indent=4, ensure_ascii=False)
    print(f"Structured post data and comments saved to {output_file}")
    
    return post_data

# For backward compatibility, keep the original function name as an alias
def scrape_reddit_post(url, output_file="scraped_comments.json"):
    """Backward compatibility wrapper - calls the DFS version"""
    return scrape_reddit_post_dfs(url, output_file)
