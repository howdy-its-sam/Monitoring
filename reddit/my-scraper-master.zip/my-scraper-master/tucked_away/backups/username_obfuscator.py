"""
Username Obfuscation Utility

This module provides functions to obfuscate usernames in Reddit scraped JSON files
by replacing them with random first names while preserving conversation structure.

Usage:
    # Obfuscate a single file
    obfuscated_data = obfuscate_usernames("scraped_posts/comments.json", "scraped_posts/comments_obfuscated.json")
    
    # Obfuscate with custom name list
    obfuscated_data = obfuscate_usernames("input.json", "output.json", custom_names=["Alice", "Bob", "Charlie"])
"""

import json
import os
import random
from typing import Dict, List, Any, Set
from datetime import datetime


# Default list of common first names (expanded to handle large datasets)
DEFAULT_FIRST_NAMES = [
    "Aaron", "Abigail", "Abram", "Ada", "Addison", "Adelaide", "Adrian", "Adela", "Agnes",
    "Adewale", "Aisha", "Alan", "Albert", "Alexander", "Alexandra", "Alex", "Alexis", "Alice",
    "Allison", "Amanda", "Amara", "Amber", "Amelia", "Amélie", "Amos", "Amy", "Ana", "Ananya",
    "Andrea", "Andre", "Andres", "Andrew", "Andy", "Angel", "Angela", "Anaru", "Annie", "Anthony",
    "Antonio", "April", "Aria", "Arnold", "Arjun", "Arthur", "Ashley", "Audrey", "Austin", "Ava",
    "Ayana", "Barbara", "Barry", "Bao", "Beatrice", "Becky", "Benjamin", "Bernard", "Beth",
    "Bethany", "Betty", "Beverly", "Bill", "Billy", "Blake", "Bob", "Bobby", "Bradley", "Brandon",
    "Brenda", "Brian", "Brittany", "Bruce", "Bryan", "Camila", "Carl", "Carlos", "Camille", "Carol",
    "Carolyn", "Carrie", "Casey", "Catherine", "Cathy", "Charles", "Charlotte", "Chantal", "Chen",
    "Cheryl", "Chidi", "Chris", "Christina", "Christine", "Christopher", "Cindy", "Clarence", "Claude",
    "Clifford", "Clyde", "Cody", "Colin", "Connie", "Corey", "Craig", "Crystal", "Curtis", "Cynthia",
    "Dale", "Dana", "Daniel", "Danielle", "Danny", "Darrell", "David", "Dawn", "Daichi", "Dean",
    "Debbie", "Deborah", "Debra", "Deepa", "Dennis", "Derek", "Diana", "Diane", "Diego", "Donald",
    "Donna", "Doris", "Dorothy", "Douglas", "Drew", "Dylan", "Earl", "Eddie", "Edward", "Edwin",
    "Elaine", "Eleanor", "Elizabeth", "Elena", "Ellen", "Emily", "Emma", "Emery", "Eric", "Erica",
    "Eugene", "Evelyn", "Eva", "Ethan", "Evan", "Faith", "Fatima", "Finley", "Florence", "Frances",
    "Francis", "Frank", "Fred", "Gabriel", "Gabriela", "Gary", "George", "Gerald", "Giulia", "Gloria",
    "Grace", "Gregory", "Hana", "Harold", "Harry", "Haruto", "Hassan", "Hayden", "Heather", "Helen",
    "Henry", "Hina", "Hiroshi", "Howard", "Ian", "Imani", "Isaac", "Isabel", "Ines", "Jack", "Jacob",
    "Jabari", "James", "Jane", "Janet", "Janice", "Jason", "Jean", "Jeffrey", "Jennifer", "Jeremy",
    "Jerry", "Jesse", "Jessica", "Jill", "Jim", "Jimmy", "Jin", "Joan", "Joanne", "Joe", "John",
    "Johnny", "Jonathan", "Jordan", "Jorge", "Jose", "Joseph", "Joshua", "Joyce", "Juan", "Judith",
    "Judy", "Julia", "Julie", "Justin", "Kai", "Karen", "Katarina", "Katherine", "Kathleen", "Kathryn",
    "Kathy", "Keith", "Kelly", "Kenneth", "Kevin", "Keanu", "Kenji", "Khalid", "Kim", "Kimberly",
    "Kiran", "Koa", "Kofi", "Kwame", "Lakshmi", "Lani", "Larry", "Laura", "Lawrence", "Lee", "Leila",
    "Leilani", "Leonard", "Leslie", "Linda", "Lisa", "Li", "Lois", "Louis", "Louise", "Luc", "Luca",
    "Lucian", "Lucia", "Luis", "Lucas", "Lucy", "Lynn", "Madison", "Makoa", "Malik", "Manish", "Marcos",
    "Margaret", "Maria", "Marie", "Marilyn", "Mark", "Marek", "Martha", "Martin", "Mary", "Matthew",
    "Mateo", "Mateusz", "Megan", "Meera", "Melissa", "Michael", "Michelle", "Mika", "Mildred", "Milton",
    "Misty", "Moana", "Monica", "Morgan", "Nancy", "Nadia", "Nabil", "Nathan", "Nicholas", "Nicole",
    "Nikos", "Nia", "Ngozi", "Niko", "Noah", "Noemi", "Noor", "Norma", "Norman", "Olivia", "Oliver",
    "Pamela", "Patricia", "Patrick", "Paul", "Paula", "Parker", "Peggy", "Peter", "Petra", "Philip",
    "Priya", "Rachel", "Ralph", "Randy", "Rangi", "Raymond", "Ravi", "Rebecca", "Reese", "René",
    "Richard", "Riya", "Robert", "Robin", "Roger", "Ronald", "Rosa", "Rose", "Roy", "Ruby", "Russell",
    "Ruth", "Ryan", "Sage", "Salma", "Samantha", "Samuel", "Samir", "Sanjay", "Sandra", "Sara", "Sarah",
    "Scott", "Sean", "Sharon", "Shirley", "Sofia", "Sophia", "Sora", "Stacy", "Stephanie", "Stephen",
    "Steven", "Susan", "Sven", "Sydney", "Tammy", "Tane", "Tariq", "Tatum", "Taylor", "Teresa", "Terry",
    "Theresa", "Thomas", "Timothy", "Tina", "Todd", "Tom", "Tony", "Tomas", "Tui", "Tyler", "Valerie",
    "Valentina", "Victor", "Victoria", "Vikram", "Viktor", "Vincent", "Virginia", "Wanda", "Walter",
    "Wayne", "Wei", "Wendy", "William", "Willie", "Yara", "Yousef", "Yuki", "Yuna", "Zachary", "Zahra",
    "Zoe", "Zuri"
]


def generate_name_mapping(usernames: Set[str], name_pool: List[str] = None, op_username: str = None) -> Dict[str, str]:
    """
    Generate a mapping from usernames to random first names.
    
    Args:
        usernames: Set of unique usernames to obfuscate
        name_pool: Optional custom list of names to use (defaults to DEFAULT_FIRST_NAMES)
        op_username: Original poster username to map to "OP"
        
    Returns:
        Dictionary mapping original usernames to obfuscated names
        
    Raises:
        ValueError: If there are more usernames than available names
    """
    if name_pool is None:
        name_pool = DEFAULT_FIRST_NAMES.copy()
    
    # Remove OP from usernames to process separately
    non_op_usernames = usernames.copy()
    if op_username and op_username in non_op_usernames:
        non_op_usernames.remove(op_username)
    
    # Shuffle the name pool to ensure randomness
    available_names = name_pool.copy()
    random.shuffle(available_names)
    
    # Check if we have enough names for non-OP usernames
    if len(non_op_usernames) > len(available_names):
        raise ValueError(f"Not enough names available. Need {len(non_op_usernames)} names, but only have {len(available_names)}")
    
    # Create mapping
    username_to_name = {}
    
    # Map OP to "OP" if specified
    if op_username and op_username in usernames:
        username_to_name[op_username] = "OP"
    
    # Map other usernames to random names
    for i, username in enumerate(sorted(non_op_usernames)):  # Sort for consistent mapping
        username_to_name[username] = available_names[i]
    
    return username_to_name


def extract_all_usernames(data: Dict[str, Any]) -> Set[str]:
    """
    Extract all unique usernames from Reddit scraped data.
    
    Args:
        data: The JSON data containing post and comments
        
    Returns:
        Set of all unique usernames found in the data
    """
    usernames = set()
    
    # Extract post author username
    if 'author' in data and data['author']:
        usernames.add(data['author'])
    
    # Extract usernames from comments recursively
    if 'comments' in data:
        for comment_id, comment in data['comments'].items():
            _extract_usernames_recursive(comment, usernames)
    
    return usernames


def _extract_usernames_recursive(comment: Dict[str, Any], usernames: Set[str]) -> None:
    """
    Recursively extract usernames from a comment and its children.
    
    Args:
        comment: Comment dictionary
        usernames: Set to add usernames to
    """
    # Extract username from current comment
    if 'username' in comment and comment['username']:
        usernames.add(comment['username'])
    
    # Recursively process children
    if 'children' in comment and isinstance(comment['children'], list):
        for child in comment['children']:
            _extract_usernames_recursive(child, usernames)


def obfuscate_comment_recursive(comment: Dict[str, Any], username_mapping: Dict[str, str]) -> Dict[str, Any]:
    """
    Recursively obfuscate usernames in a comment and its children.
    
    Args:
        comment: Comment dictionary to obfuscate
        username_mapping: Mapping from original usernames to obfuscated names
        
    Returns:
        Comment dictionary with obfuscated usernames
    """
    obfuscated_comment = comment.copy()
    
    # Obfuscate username in current comment
    if 'username' in obfuscated_comment and obfuscated_comment['username']:
        original_username = obfuscated_comment['username']
        if original_username in username_mapping:
            obfuscated_comment['username'] = username_mapping[original_username]
    
    # Recursively obfuscate children
    if 'children' in obfuscated_comment and isinstance(obfuscated_comment['children'], list):
        obfuscated_children = []
        for child in obfuscated_comment['children']:
            obfuscated_child = obfuscate_comment_recursive(child, username_mapping)
            obfuscated_children.append(obfuscated_child)
        obfuscated_comment['children'] = obfuscated_children
    
    return obfuscated_comment


def obfuscate_usernames(input_file: str, output_file: str = None, custom_names: List[str] = None, seed: int = None) -> Dict[str, Any]:
    """
    Obfuscate usernames in a Reddit scraped JSON file.
    
    Args:
        input_file: Path to the input JSON file
        output_file: Optional output file path (if None, generates automatically)
        custom_names: Optional custom list of names to use for obfuscation
        seed: Optional random seed for reproducible results
        
    Returns:
        Dictionary with obfuscated data and statistics
        
    Raises:
        FileNotFoundError: If input file doesn't exist
        ValueError: If there are more usernames than available names
    """
    if seed is not None:
        random.seed(seed)
    
    print(f"🔒 Obfuscating usernames in {input_file}")
    
    # Load the input data
    try:
        with open(input_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except FileNotFoundError:
        raise FileNotFoundError(f"Input file '{input_file}' not found")
    
    # Extract all unique usernames
    usernames = extract_all_usernames(data)
    print(f"  📊 Found {len(usernames)} unique usernames")
    
    if not usernames:
        print("  ⚠️  No usernames found to obfuscate")
        return data
    
    # Get OP username from post author
    op_username = data.get('author', None)
    
    # Generate username mapping
    try:
        username_mapping = generate_name_mapping(usernames, custom_names, op_username)
        print(f"  🎭 Generated {len(username_mapping)} name mappings")
        if op_username:
            print(f"  👤 OP ({op_username}) → OP")
    except ValueError as e:
        print(f"  ❌ Error: {e}")
        raise
    
    # Create obfuscated data
    obfuscated_data = data.copy()
    
    # Obfuscate post author
    if 'author' in obfuscated_data and obfuscated_data['author']:
        original_author = obfuscated_data['author']
        if original_author in username_mapping:
            obfuscated_data['author'] = username_mapping[original_author]
    
    # Obfuscate comments
    if 'comments' in obfuscated_data:
        obfuscated_comments = {}
        for comment_id, comment in obfuscated_data['comments'].items():
            obfuscated_comment = obfuscate_comment_recursive(comment, username_mapping)
            obfuscated_comments[comment_id] = obfuscated_comment
        obfuscated_data['comments'] = obfuscated_comments
    
    # Generate output filename if not provided
    if output_file is None:
        base_name = os.path.splitext(input_file)[0]
        output_file = f"{base_name}_obfuscated.json"
    
    # Save obfuscated data
    try:
        os.makedirs(os.path.dirname(output_file), exist_ok=True)
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(obfuscated_data, f, indent=2, ensure_ascii=False)
        print(f"  ✅ Obfuscated data saved to: {output_file}")
    except Exception as e:
        print(f"  ❌ Error saving obfuscated data: {e}")
        raise
    
    # Calculate and report statistics
    original_size = os.path.getsize(input_file)
    obfuscated_size = os.path.getsize(output_file)
    size_change = obfuscated_size - original_size
    
    print(f"  📈 File size change: {original_size:,} bytes → {obfuscated_size:,} bytes ({size_change:+,} bytes)")
    
    # Return statistics
    stats = {
        "input_file": input_file,
        "output_file": output_file,
        "usernames_obfuscated": len(username_mapping),
        "original_size": original_size,
        "obfuscated_size": obfuscated_size,
        "size_change": size_change,
        "username_mapping": username_mapping,
        "obfuscated_data": obfuscated_data
    }
    
    return stats


def obfuscate_directory(input_dir: str, output_dir: str = None, custom_names: List[str] = None, seed: int = None) -> Dict[str, Any]:
    """
    Obfuscate usernames in all JSON files in a directory.
    
    Args:
        input_dir: Directory containing JSON files to obfuscate
        output_dir: Directory to save obfuscated files (if None, uses input_dir + '_obfuscated')
        custom_names: Optional custom list of names to use for obfuscation
        seed: Optional random seed for reproducible results
        
    Returns:
        Dictionary with processing statistics
    """
    if output_dir is None:
        output_dir = f"{input_dir}_obfuscated"
    
    print(f"🗂️  Obfuscating usernames in all JSON files in '{input_dir}'")
    
    # Ensure output directory exists
    os.makedirs(output_dir, exist_ok=True)
    
    # Find all JSON files
    json_files = [f for f in os.listdir(input_dir) if f.endswith('.json')]
    
    if not json_files:
        print(f"  ⚠️  No JSON files found in '{input_dir}'")
        return {"processed": 0, "errors": 0}
    
    print(f"  📋 Found {len(json_files)} JSON files to process")
    
    stats = {
        "processed": 0,
        "errors": 0,
        "total_original_size": 0,
        "total_obfuscated_size": 0,
        "files": []
    }
    
    for json_file in json_files:
        input_path = os.path.join(input_dir, json_file)
        
        # Generate output filename
        base_name = os.path.splitext(json_file)[0]
        output_filename = f"{base_name}_obfuscated.json"
        output_path = os.path.join(output_dir, output_filename)
        
        try:
            print(f"\n📄 Processing {json_file}...")
            # Obfuscate the file
            file_stats = obfuscate_usernames(input_path, output_path, custom_names, seed)
            
            # Update statistics
            stats["processed"] += 1
            stats["total_original_size"] += file_stats["original_size"]
            stats["total_obfuscated_size"] += file_stats["obfuscated_size"]
            stats["files"].append({
                "filename": json_file,
                "usernames_obfuscated": file_stats["usernames_obfuscated"],
                "original_size": file_stats["original_size"],
                "obfuscated_size": file_stats["obfuscated_size"],
                "size_change": file_stats["size_change"]
            })
            
        except Exception as e:
            print(f"  ❌ Error processing {json_file}: {e}")
            stats["errors"] += 1
    
    # Print summary
    print(f"\n📊 Directory obfuscation summary:")
    print(f"  ✅ Successfully processed: {stats['processed']} files")
    print(f"  ❌ Errors: {stats['errors']} files")
    
    if stats["processed"] > 0:
        total_size_change = stats["total_obfuscated_size"] - stats["total_original_size"]
        print(f"  📈 Total size change: {stats['total_original_size']:,} bytes → {stats['total_obfuscated_size']:,} bytes ({total_size_change:+,} bytes)")
        
        total_usernames = sum(file["usernames_obfuscated"] for file in stats["files"])
        print(f"  🎭 Total usernames obfuscated: {total_usernames}")
    
    return stats


def print_username_mapping(username_mapping: Dict[str, str], limit: int = 20) -> None:
    """
    Print a sample of the username mapping for verification.
    
    Args:
        username_mapping: Dictionary mapping original usernames to obfuscated names
        limit: Maximum number of mappings to display
    """
    print(f"\n🎭 Username Mapping Sample (showing first {min(limit, len(username_mapping))}):")
    print("-" * 60)
    
    for i, (original, obfuscated) in enumerate(list(username_mapping.items())[:limit]):
        print(f"  {original:<25} → {obfuscated}")
    
    if len(username_mapping) > limit:
        print(f"  ... and {len(username_mapping) - limit} more")


# Example usage and testing
if __name__ == "__main__":
    # Example: Obfuscate a single file
    try:
        stats = obfuscate_usernames("scraped_posts/scraped_comments.json", seed=42)
        print_username_mapping(stats["username_mapping"])
        print("✅ Obfuscation completed successfully")
    except Exception as e:
        print(f"❌ Error: {e}")
    
    # Example: Obfuscate entire directory
    # try:
    #     stats = obfuscate_directory("scraped_posts/", seed=42)
    #     print("✅ Directory obfuscation completed successfully")
    # except Exception as e:
    #     print(f"❌ Error: {e}")
