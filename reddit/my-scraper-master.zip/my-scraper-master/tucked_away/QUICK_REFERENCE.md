# Reddit Scraper - Quick Reference Card

## 🚀 Quick Start

```bash
# Start adaptive scraping (60 minutes on r/news)
python3 test_temporal_scraping.py news 60

# View current status
python3 quick_status.py

# View detailed lifecycle status
python3 view_post_lifecycle.py

# Run discovery and maintenance manually
python3 manage_tracked_posts.py news
```

## 📁 Key Files

| File | Purpose | Edit? |
|------|---------|-------|
| `tracked_urls.txt` | Active URLs being tracked | Auto-updated |
| `manual_urls.txt` | User-specified URLs | ✅ Yes! |
| `post_metadata.json` | Lifecycle state & history | Auto-updated |
| `test_temporal_scraping.py` | Main scraping script | No |
| `manage_tracked_posts.py` | Discovery & lifecycle | No |

## ➕ Add a URL Manually

```bash
# Method 1: Edit file directly
nano manual_urls.txt
# Add: https://www.reddit.com/r/news/comments/abc123/post/

# Method 2: Append from command line
echo "https://www.reddit.com/r/news/comments/abc123/post/" >> manual_urls.txt

# URL will be picked up automatically within ~5 minutes
```

## 📊 Check Status

### Quick Overview
```bash
python3 quick_status.py
```
Shows: total posts, state counts, dormancy levels, recent activity

### Detailed View
```bash
python3 view_post_lifecycle.py
```
Shows: all posts grouped by state, full metadata

### Specific Post
```bash
python3 -c "import json; m=json.load(open('post_metadata.json')); \
print(json.dumps(m.get('POST_ID'), indent=2))"
```

## 🔄 Lifecycle States

| State | Description | Check Frequency |
|-------|-------------|-----------------|
| 🟢 **Active** | High activity | Every scrape (adaptive) |
| 🟡 **Dormant** | Low/no activity | Exponential backoff |
| ⚫ **Retired** | Dead after 16w | Removed from tracking |

### Dormancy Levels
- Level 0: Check in 1 week
- Level 1: Check in 2 weeks  
- Level 2: Check in 4 weeks
- Level 3: Check in 8 weeks
- Level 4: Check in 16 weeks → Retire

## ⚙️ Configuration

### Dormancy Thresholds (`manage_tracked_posts.py`)
```python
DORMANCY_THRESHOLD_COMMENTS = 5  # <5 new comments/scrape
DORMANCY_THRESHOLD_SCRAPES = 3   # Over last 3 scrapes
```

### Phase 1B Criteria (`test_temporal_scraping.py`)
Posts scraped if **ANY** of:
- Age ≤24 hours
- Scrape count <3
- State = 'active'

### Priority Boost (`priority.py`)
```python
measurement_bonus = 25.0      # Points per missing scrape
measurement_threshold = 5     # Target minimum scrapes
```

## 🐛 Troubleshooting

### Discovery not working?
```bash
# Check OAuth
python3 reddit_auth.py

# Run discovery manually
python3 manage_tracked_posts.py news --quick
```

### Posts stuck in wrong state?
```bash
# Force full maintenance
python3 manage_tracked_posts.py news

# Check activity history
python3 -c "import json; m=json.load(open('post_metadata.json')); \
print(json.dumps(m['POST_ID']['activity_history'], indent=2))"
```

### Phase 1B skipping posts?
Check metadata for age, scrape count, and state:
```bash
python3 view_post_lifecycle.py | grep POST_ID -A 3
```

## 📈 Monitoring Tips

### Watch for rate limits
```bash
tail -f /path/to/scraper/output.log | grep "429\|Rate"
```

### Count active vs dormant
```bash
python3 quick_status.py | grep -E "Active|Dormant"
```

### Find posts needing attention
```bash
# Posts with <3 scrapes
python3 -c "import json, os; m=json.load(open('post_metadata.json')); \
[print(k) for k in m if len(os.listdir(f'temporal_test/{k}/raw_scrapes')) < 3]"
```

## 🧪 Testing

```bash
# Test lifecycle transitions
python3 test_lifecycle_transitions.py

# Clean up test data afterward
rm -rf temporal_test/test_*
python3 -c "import json; m=json.load(open('post_metadata.json')); \
m={k:v for k,v in m.items() if not k.startswith('test_')}; \
json.dump(m, open('post_metadata.json','w'), indent=2)"
```

## 📝 Common Workflows

### Daily Monitoring
```bash
# Morning: Check status
python3 quick_status.py

# Afternoon: Run discovery/maintenance
python3 manage_tracked_posts.py news

# Evening: Check what's dormant
python3 view_post_lifecycle.py | grep "DORMANT" -A 20
```

### Adding Batch URLs
```bash
# Create file with URLs (one per line)
cat urls_to_add.txt >> manual_urls.txt

# Trigger discovery
python3 manage_tracked_posts.py news --quick
```

### Tuning After 24h
1. Check dormancy effectiveness:
   ```bash
   python3 quick_status.py
   ```

2. If too many dormant: Lower threshold
   ```python
   # In manage_tracked_posts.py
   DORMANCY_THRESHOLD_COMMENTS = 3  # was 5
   ```

3. If too few dormant: Raise threshold
   ```python
   DORMANCY_THRESHOLD_COMMENTS = 10  # was 5
   ```

## 🔗 Documentation

- **Full Guide**: `LIFECYCLE_SYSTEM_README.md`
- **Implementation Details**: `IMPLEMENTATION_SUMMARY.md`
- **This File**: `QUICK_REFERENCE.md`

---

**Pro Tip**: Use `watch -n 60 "python3 quick_status.py"` for live monitoring! 📊

