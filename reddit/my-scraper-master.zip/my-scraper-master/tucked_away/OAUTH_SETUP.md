# Reddit OAuth Setup Guide

## ✅ Implementation Complete!

OAuth authentication has been added to your Reddit scraper. This will increase your rate limits from **~60 to ~600 requests/minute** (10x improvement!).

## 📋 What You Need To Do

### Step 1: Create Reddit App

1. Go to: https://www.reddit.com/prefs/apps
2. Scroll to the bottom and click **"create another app..."**
3. Fill out the form:
   - **Name**: `RedditCommentScraper` (or any name you like)
   - **App type**: Select **"script"** ⚠️ Important!
   - **Description**: `Personal comment archival tool`
   - **About URL**: Leave blank
   - **Redirect URI**: `http://localhost:8080` (required but not used)
4. Click **"create app"**

### Step 2: Copy Your Credentials

After creating the app, you'll see:
- **Client ID**: The short string under "personal use script" (looks like: `abc123XYZ456`)
- **Client Secret**: Click "edit" if needed, it's the longer string labeled "secret"

### Step 3: Fill Out `reddit_credentials.txt`

Open the file `reddit_credentials.txt` in this directory and replace the placeholder values:

```
CLIENT_ID=your_actual_client_id_here
CLIENT_SECRET=your_actual_client_secret_here
USERNAME=your_reddit_username
PASSWORD=your_reddit_password
```

**Example:**
```
CLIENT_ID=abc123XYZ456
CLIENT_SECRET=def789GHI012jkl345MNO678
USERNAME=my_reddit_username
PASSWORD=my_reddit_password
```

### Step 4: Test Authentication

Run the authentication test:
```bash
python3 reddit_auth.py
```

You should see:
```
✅ OAuth authenticated as u/your_username
✅ API test successful! Logged in as: your_username
```

If you see errors, double-check your credentials.

### Step 5: Run Your Scraper

Everything is already integrated! Just run your scraper normally:
```bash
python3 test_temporal_scraping.py news 60
```

You'll see at startup:
```
🔐 Attempting OAuth authentication...
✅ OAuth authenticated as u/your_username
```

## 🔒 Security Notes

- ⚠️ The file `reddit_credentials.txt` is already added to `.gitignore` to prevent accidental commits
- ⚠️ Never share your credentials or commit them to version control
- ⚠️ If you accidentally expose your credentials, regenerate them at https://www.reddit.com/prefs/apps

## 🚀 What Changed

### Files Modified:
1. **`reddit_auth.py`** (NEW) - Handles OAuth authentication
2. **`reddit_scraper_api.py`** - Now accepts optional `session` parameter for authenticated requests
3. **`test_temporal_scraping.py`** - Automatically uses OAuth if credentials are available
4. **`.gitignore`** (NEW) - Protects your credentials from being committed

### Backward Compatibility:
- ✅ If credentials are missing or invalid, the scraper falls back to unauthenticated mode
- ✅ All existing functionality works exactly the same
- ✅ No breaking changes to any APIs

## 📊 Expected Improvements

With OAuth authentication:
- **10x higher rate limits** (~600 vs ~60 requests/minute)
- **Fewer 429 errors** (rate limit errors)
- **Faster scraping** (less waiting between batches)
- **More complete data** (less likely to hit limits before finishing)

## ❓ Troubleshooting

### "Credentials file not found"
- Make sure `reddit_credentials.txt` exists in the project root
- Check that you've filled in all four fields

### "OAuth authentication failed"
- Verify your CLIENT_ID and CLIENT_SECRET are correct
- Make sure you selected "script" type when creating the app
- Check that your username and password are correct

### "Still getting 429 errors"
- OAuth gives you 10x more requests, but you can still hit limits with very aggressive scraping
- The exponential backoff will handle this automatically
- Consider reducing the number of posts you're tracking simultaneously

## 🎉 You're All Set!

Once you've filled in your credentials, you're ready to enjoy 10x faster scraping!

