#!/usr/bin/env python3
"""
Main script for API-based Reddit scraping
Much faster than browser automation approach
"""

import sys
import os
from reddit_scraper_api import scrape_reddit_post_api
from datetime import datetime

def read_urls_from_file(filename="urls_to_scrape.txt"):
    """Read URLs from a text file, ignoring comments and empty lines"""
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        urls = []
        for line_num, line in enumerate(lines, 1):
            line = line.strip()
            
            # Skip empty lines and comments
            if not line or line.startswith('#'):
                continue
            
            # Validate URL format
            if line.startswith('http'):
                urls.append(line)
            else:
                print(f"⚠️  Warning: Line {line_num} doesn't look like a URL: {line}")
        
        return urls
    
    except FileNotFoundError:
        print(f"❌ URLs file '{filename}' not found!")
        print("Please create 'urls_to_scrape.txt' with your Reddit URLs (one per line)")
        return []
    except Exception as e:
        print(f"❌ Error reading URLs file: {e}")
        return []

def scrape_url_list(urls, auto_process=True):
    """Scrape a list of URLs using the fast API approach"""
    print(f"🚀 Starting API-based batch scraping of {len(urls)} URLs")
    print(f"📅 Start time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)
    
    successful_scrapes = 0
    failed_scrapes = 0
    
    for i, url in enumerate(urls, 1):
        print(f"\n📋 Processing URL {i}/{len(urls)}: {url}")
        print(f"⏰ Time: {datetime.now().strftime('%H:%M:%S')}")
        
        try:
            # Extract post ID from URL
            from reddit_scraper_api import extract_post_id_from_url
            post_id = extract_post_id_from_url(url)
            if not post_id:
                post_id = f"unknown_{i}"
            
            # Generate output filename using clean naming convention
            output_file = f"merged_posts/scraped_{post_id}.json"
            
            # Ensure output directories exist
            os.makedirs('merged_posts', exist_ok=True)
            os.makedirs('raw_posts', exist_ok=True)
            
            # Scrape using API
            result = scrape_reddit_post_api(url, output_file)
            
            if result:
                successful_scrapes += 1
                print(f"✅ Successfully scraped URL {i}")
                print(f"   📊 Comments found: {result['metadata']['total_comments']}")
                print(f"   📊 Coverage: {result['metadata']['coverage_percent']}%")
                print(f"   📊 API requests: {result['metadata']['api_requests']}")
                
            else:
                failed_scrapes += 1
                print(f"❌ Failed to scrape URL {i}")
                
        except Exception as e:
            failed_scrapes += 1
            print(f"❌ Error processing URL {i}: {e}")
    
    # Summary
    print("\n" + "=" * 60)
    print("📊 BATCH SCRAPING SUMMARY")
    print("=" * 60)
    print(f"✅ Successful scrapes: {successful_scrapes}")
    print(f"❌ Failed scrapes: {failed_scrapes}")
    
    if successful_scrapes > 0:
        success_rate = (successful_scrapes / len(urls)) * 100
        print(f"📈 Success rate: {success_rate:.1f}%")
    
    print(f"🔧 Auto-processing: DISABLED (keeping raw data as-is)")
    print(f"📅 End time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    return successful_scrapes, failed_scrapes

if __name__ == "__main__":
    # URLs are read from urls_to_scrape.txt file
    urls_to_scrape = read_urls_from_file()
    
    # Validate that URLs are provided
    if not urls_to_scrape:
        print("❌ No URLs provided!")
        print("Please add your Reddit URLs to 'urls_to_scrape.txt' (one URL per line)")
        print("Lines starting with # are comments and will be ignored")
        sys.exit(1)
    
    print(f"🎯 Found {len(urls_to_scrape)} URLs to scrape")
    print(f"🔧 Auto-processing: DISABLED (keeping raw data as-is)")
    print("⚡ Using FAST API-based scraping (no browser automation)")
    
    # Start batch scraping without auto-processing
    scrape_url_list(urls_to_scrape, auto_process=False)
