#!/usr/bin/env python3
"""
Adaptive Temporal Data Collection Script
Uses Bayesian adaptive sampling to intelligently prioritize which posts to scrape
NO MERGING - just collects raw data for later batch processing
"""

import time
import os
import json
import re
import math
import requests
from datetime import datetime
from reddit_scraper_api import scrape_reddit_post_api
from priority import TreeMonitor
from reddit_auth import get_authenticated_session


def extract_post_id(url):
    """Extract Reddit post ID from URL"""
    match = re.search(r'/comments/([^/]+)/', url)
    if match:
        return match.group(1)
    return None


def count_comments(comments):
    """Recursively count all comments in tree"""
    total = 0
    for c in comments:
        total += 1
        if c.get('replies'):
            total += count_comments(c['replies'])
    return total


def count_existing_scrapes(post_id):
    """Count number of existing scrapes for a post."""
    scrape_dir = f'temporal_test/{post_id}/raw_scrapes'
    if not os.path.exists(scrape_dir):
        return 0
    return len([f for f in os.listdir(scrape_dir) if f.startswith('scrape_') and f.endswith('.json')])


def calculate_change_metric(previous_data, current_data):
    """
    Calculate change between two scrapes of the same post.
    
    BLACK BOX METRIC - Can be replaced with more sophisticated calculations later.
    
    Args:
        previous_data: Previous scrape result (dict with 'comments' key) or None
        current_data: Current scrape result (dict with 'comments' key)
    
    Returns:
        float: Metric representing amount of change/activity
        
    Current implementation: Simple comment count difference
    
    Future possibilities:
        - Weighted by comment depth (top-level comments worth more)
        - Weighted by comment scores
        - Account for edits and deletions
        - Multi-dimensional change vector
    """
    
    # Current implementation: Simple count difference
    current_count = count_comments(current_data['comments'])
    
    if previous_data is None:
        # First scrape - all comments are "new"
        return current_count
    
    previous_count = count_comments(previous_data['comments'])
    
    # Return difference (clamped to non-negative)
    return max(0, current_count - previous_count)


def fetch_subreddit_new(subreddit='news', limit=25, max_retries=5):
    """Fetch new posts from a subreddit with exponential backoff retry"""
    url = f'https://www.reddit.com/r/{subreddit}/new.json?limit={limit}'
    headers = {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    }
    
    for attempt in range(max_retries):
        try:
            response = requests.get(url, headers=headers, timeout=10)
            response.raise_for_status()
            data = response.json()
            posts = data['data']['children']
            
            urls = []
            for post_wrapper in posts:
                post = post_wrapper['data']
                permalink = post.get('permalink', '')
                full_url = f"https://www.reddit.com{permalink}"
                urls.append(full_url)
            
            return urls
            
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 429:  # Rate limited
                wait_time = (2 ** attempt) * 2  # Exponential backoff: 2, 4, 8, 16, 32 seconds
                print(f"⏳ Rate limited (429). Waiting {wait_time}s before retry {attempt + 1}/{max_retries}...")
                time.sleep(wait_time)
            else:
                print(f"❌ HTTP Error fetching r/{subreddit}/new: {e}")
                return []
        except Exception as e:
            print(f"❌ Error fetching r/{subreddit}/new: {e}")
            return []
    
    print(f"❌ Failed to fetch r/{subreddit}/new after {max_retries} retries")
    return []


def run_adaptive_data_collection(subreddit='news', duration_minutes=60):
    """
    Adaptive scraping using Bayesian prioritization
    Uses hardcoded high-activity posts from r/news
    NO MERGING - just collect raw data
    
    Args:
        subreddit: Subreddit to monitor (default: 'news')
        duration_minutes: How long to run (default 60)
    """
    
    # Try to authenticate with OAuth for 10x rate limit
    print("🔐 Attempting OAuth authentication...")
    session = get_authenticated_session()
    if not session:
        print("⚠️  Running in unauthenticated mode (lower rate limits)")
    print()
    
    # Load URLs from tracked_urls.txt
    print(f"📋 Loading tracked posts from tracked_urls.txt...")
    
    urls = []
    try:
        with open('tracked_urls.txt', 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#'):  # Skip empty lines and comments
                    urls.append(line)
        print(f"✅ Loaded {len(urls)} posts to track")
    except FileNotFoundError:
        print("❌ Error: tracked_urls.txt not found")
        return
    except Exception as e:
        print(f"❌ Error reading tracked_urls.txt: {e}")
        return
    
    if not urls:
        print(f"❌ Error: No URLs available")
        return
    
    print("="*80)
    print("🧠 ADAPTIVE TEMPORAL DATA COLLECTION")
    print("="*80)
    print(f"\n📋 Configuration:")
    print(f"   Subreddit: r/{subreddit}/new")
    print(f"   Posts to track: {len(urls)}")
    print(f"   Duration: {duration_minutes} minutes")
    print(f"   Strategy: Bayesian adaptive sampling")
    print(f"   ⚠️  RAW DATA ONLY - NO MERGING")
    print()
    
    # Extract post IDs and create directories
    post_ids = []
    post_id_to_url = {}
    scrape_counts = {}
    
    print("📍 Posts to track:")
    for i, url in enumerate(urls, 1):
        post_id = extract_post_id(url)
        if post_id:
            post_ids.append(post_id)
            post_id_to_url[post_id] = url
            print(f"   {i}. {post_id}")
            
            # Create directory and check for existing scrapes
            scrape_dir = f'temporal_test/{post_id}/raw_scrapes'
            os.makedirs(scrape_dir, exist_ok=True)
            
            existing_scrapes = sorted([f for f in os.listdir(scrape_dir) if f.startswith('scrape_') and f.endswith('.json')])
            if existing_scrapes:
                last_scrape = existing_scrapes[-1]
                last_num = int(last_scrape.split('_')[1])
                scrape_counts[post_id] = last_num
                print(f"      📌 Found {len(existing_scrapes)} existing scrapes, resuming from #{last_num + 1}")
            else:
                scrape_counts[post_id] = 0
    print()
    
    # Initialize TreeMonitor with adaptive sampling
    print("🧠 Initializing Bayesian adaptive sampler...")
    monitor = TreeMonitor(
        tree_ids=post_ids,
        alpha0=1.0,   # Prior: expect some activity
        beta0=1.0,    # Prior: low confidence
        phi=0.95,     # Discount factor (0.95 = remember ~95% of history)
        kappa=0.3,    # Uncertainty weight (exploration)
        eta=0.2,      # Burst detection weight
        rho=1.5,      # Staleness penalty weight (INCREASED: stronger bias to old posts)
        delta=0.1,    # Burst decay rate
        gamma=0.2,    # Burst sensitivity
        tau=3.0,      # Staleness timescale (DECREASED: gets stale faster)
        p=2.0         # Staleness curve shape (INCREASED: steeper staleness curve)
    )
    print("✅ Sampler initialized (with virgin bonus + strong staleness bias)\n")
    
    # Calculate end time
    start_time = time.time()
    end_time = start_time + (duration_minutes * 60)
    
    print(f"🚀 Starting collection at {datetime.now().strftime('%H:%M:%S')}")
    print(f"🏁 Will stop at {datetime.fromtimestamp(end_time).strftime('%H:%M:%S')}")
    print("="*80 + "\n")
    
    # Track previous scrape data for each post (for change metric calculation)
    previous_data = {post_id: None for post_id in post_ids}
    
    total_scrapes = 0
    errors = 0
    
    # Track which posts have been scraped this session
    scraped_this_session = set()
    
    # ========================================================================
    # PHASE 1A: VIRGIN POSTS - Never scraped before
    # ========================================================================
    virgin_posts = [pid for pid in post_ids if scrape_counts[pid] == 0]
    
    if virgin_posts:
        print("="*80)
        print("📍 PHASE 1A: Virgin posts (never scraped before)")
        print("="*80)
        print(f"Scraping {len(virgin_posts)} brand new posts first...\n")
        
        for i, post_id in enumerate(virgin_posts, 1):
            # Check if time is up
            if time.time() >= end_time:
                print("⏰ Time limit reached during virgin pass")
                break
            
            try:
                url = post_id_to_url[post_id]
                scrape_counts[post_id] += 1
                scrape_num = scrape_counts[post_id]
                total_scrapes += 1
                
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                
                print(f"[{i}/{len(virgin_posts)}] 🆕 {post_id} (#1, VIRGIN)...", end=' ', flush=True)
                
                # Scrape (with OAuth session if available)
                result = scrape_reddit_post_api(url, session=session)
                
                if result:
                    # Save raw data
                    raw_file = f'temporal_test/{post_id}/raw_scrapes/scrape_{scrape_num:03d}_{timestamp}.json'
                    with open(raw_file, 'w', encoding='utf-8') as f:
                        json.dump(result, f, indent=2, ensure_ascii=False)
                    
                    # Calculate change metric
                    change_metric = calculate_change_metric(previous_data[post_id], result)
                    previous_data[post_id] = result
                    
                    # Update monitor
                    monitor.clock = (time.time() - start_time) / 60.0
                    monitor.measure_tree(post_id, change_metric)
                    
                    scraped_this_session.add(post_id)
                    
                    current_count = count_comments(result['comments'])
                    print(f"✅ {current_count} comments")
                else:
                    print(f"❌ Failed")
                    errors += 1
                    monitor.measure_tree(post_id, 0)
                    
            except KeyboardInterrupt:
                print("\n\n⚠️  Interrupted by user")
                return
            except Exception as e:
                print(f"❌ Error: {e}")
                errors += 1
        
        print(f"\n✅ Phase 1A complete: {len(virgin_posts)} virgin posts scraped\n")
    
    # ========================================================================
    # PHASE 1B: SELECTIVE BASELINE - Smart filtering based on criteria
    # ========================================================================
    session_new_posts = [pid for pid in post_ids if pid not in scraped_this_session]
    
    if session_new_posts:
        print("="*80)
        print("📍 PHASE 1B: Selective baseline (filtered by criteria)")
        print("="*80)
        
        # Load metadata to check post state/age
        metadata = {}
        try:
            if os.path.exists('post_metadata.json'):
                with open('post_metadata.json', 'r') as f:
                    metadata = json.load(f)
        except Exception as e:
            print(f"⚠️  Could not load metadata: {e}")
        
        now = datetime.now()
        posts_to_scrape = []
        posts_skipped = []
        
        for post_id in session_new_posts:
            post_meta = metadata.get(post_id, {})
            
            # Check criteria
            added_date_str = post_meta.get('added_date', now.isoformat())
            try:
                added_date = datetime.fromisoformat(added_date_str)
                age_hours = (now - added_date).total_seconds() / 3600
            except:
                age_hours = 0  # Unknown age, assume new
            
            scrape_count = scrape_counts.get(post_id, 0)
            state = post_meta.get('state', 'active')
            
            # Scrape if ANY of these are true:
            should_scrape = (
                age_hours <= 24 or           # Recent post (likely growing)
                scrape_count < 3 or          # Need minimum sample
                state == 'active'            # Explicitly active
            )
            
            if should_scrape:
                posts_to_scrape.append(post_id)
            else:
                reason = f"{state}, {scrape_count} scrapes, {age_hours:.1f}h old"
                posts_skipped.append((post_id, reason))
        
        print(f"Will scrape {len(posts_to_scrape)} posts, skipping {len(posts_skipped)}...\n")
        
        if posts_skipped:
            print(f"⏭️  Skipped {len(posts_skipped)} posts (dormant/well-sampled):")
            for post_id, reason in posts_skipped[:3]:  # Show first 3
                print(f"   - {post_id}: {reason}")
            if len(posts_skipped) > 3:
                print(f"   ... and {len(posts_skipped) - 3} more")
            print()
        
        if not posts_to_scrape:
            print("✅ Phase 1B complete: All posts filtered out\n")
        else:
            print(f"Scraping {len(posts_to_scrape)} selected posts...\n")
            
            for i, post_id in enumerate(posts_to_scrape, 1):
                # Check if time is up
                if time.time() >= end_time:
                    print("⏰ Time limit reached during session baseline")
                    break
                
                try:
                    url = post_id_to_url[post_id]
                    scrape_counts[post_id] += 1
                    scrape_num = scrape_counts[post_id]
                    total_scrapes += 1
                    
                    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                    
                    print(f"[{i}/{len(posts_to_scrape)}] {post_id} (#{scrape_num})...", end=' ', flush=True)
                    
                    # Scrape (with OAuth session if available)
                    result = scrape_reddit_post_api(url, session=session)
                    
                    if result:
                        # Save raw data
                        raw_file = f'temporal_test/{post_id}/raw_scrapes/scrape_{scrape_num:03d}_{timestamp}.json'
                        with open(raw_file, 'w', encoding='utf-8') as f:
                            json.dump(result, f, indent=2, ensure_ascii=False)
                        
                        # Calculate change metric
                        change_metric = calculate_change_metric(previous_data[post_id], result)
                        previous_data[post_id] = result
                        
                        # Update monitor
                        monitor.clock = (time.time() - start_time) / 60.0
                        monitor.measure_tree(post_id, change_metric)
                        
                        scraped_this_session.add(post_id)
                        
                        current_count = count_comments(result['comments'])
                        print(f"✅ {current_count} comments (+{int(change_metric)} new)")
                    else:
                        print(f"❌ Failed")
                        errors += 1
                        monitor.measure_tree(post_id, 0)
                        
                except KeyboardInterrupt:
                    print("\n\n⚠️  Interrupted by user")
                    return
                except Exception as e:
                    print(f"❌ Error: {e}")
                    errors += 1
            
            print(f"\n✅ Phase 1B complete: {len(posts_to_scrape)} posts scraped\n")
    
    phase1_time = int(time.time() - start_time)
    remaining_time = int(end_time - time.time())
    
    print(f"✅ Phase 1 complete: {total_scrapes} total scrapes in {phase1_time//60}m {phase1_time%60}s")
    print(f"⏱️  Remaining time for adaptive sampling: {remaining_time//60}m {remaining_time%60}s\n")
    
    # ========================================================================
    # PHASE 2: ADAPTIVE SAMPLING - Use algorithm to prioritize
    # ========================================================================
    print("="*80)
    print("🧠 PHASE 2: Adaptive sampling based on activity")
    print("="*80)
    print("Algorithm will prioritize posts with most activity...\n")
    
    # Track last discovery check
    last_discovery_check = time.time()
    
    while time.time() < end_time:
        try:
            # Update monitor's clock (in minutes since start)
            monitor.clock = (time.time() - start_time) / 60.0
            
            # Pick best post to scrape using Bayesian algorithm
            post_id, scores = monitor.pick_tree()
            url = post_id_to_url[post_id]
            
            scrape_counts[post_id] += 1
            scrape_num = scrape_counts[post_id]
            total_scrapes += 1
            
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            elapsed = int(time.time() - start_time)
            remaining = int(end_time - time.time())
            
            # Show which post was chosen and why
            score = scores[post_id]
            print(f"[{elapsed//60:02d}:{elapsed%60:02d}] 🎯 {post_id} (#{scrape_num}, score={score:.2f})...", end=' ', flush=True)
            
            # Scrape (with OAuth session if available)
            result = scrape_reddit_post_api(url, session=session)
            
            if result:
                # Save raw data
                raw_file = f'temporal_test/{post_id}/raw_scrapes/scrape_{scrape_num:03d}_{timestamp}.json'
                with open(raw_file, 'w', encoding='utf-8') as f:
                    json.dump(result, f, indent=2, ensure_ascii=False)
                
                # Calculate change metric (BLACK BOX - can be replaced later)
                change_metric = calculate_change_metric(previous_data[post_id], result)
                
                # Update previous data for next comparison
                previous_data[post_id] = result
                
                # Update monitor with observed change
                monitor.measure_tree(post_id, change_metric)
                
                # For display, show total count
                current_count = count_comments(result['comments'])
                print(f"✅ {current_count} total (+{int(change_metric)} new) ({remaining//60}m {remaining%60}s left)")
            else:
                print(f"❌ Failed")
                errors += 1
                # Update with 0 change on failure
                monitor.measure_tree(post_id, 0)
            
        except KeyboardInterrupt:
            print("\n\n⚠️  Interrupted by user")
            break
        except Exception as e:
            print(f"❌ Error: {e}")
            errors += 1
        
        # Opportunistic discovery check (every 5 minutes)
        if time.time() - last_discovery_check >= 300:  # 5 minutes
            print(f"\n🔍 Running periodic discovery check...")
            try:
                from manage_tracked_posts import discover_new_posts
                new_count = discover_new_posts(subreddit, session)
                if new_count > 0:
                    print(f"   ✅ Discovered {new_count} new posts")
                    # TODO: Reload tracked URLs and update monitor
                    # For now, new posts will be picked up on next run
                last_discovery_check = time.time()
            except Exception as e:
                print(f"   ⚠️  Discovery check failed: {e}")
            print()
        
        # Check if time is up
        if time.time() >= end_time:
            break
    
    # Collection complete
    print("\n" + "="*80)
    print("✅ ADAPTIVE COLLECTION COMPLETE!")
    print("="*80)
    
    # Summary
    duration_actual = int(time.time() - start_time)
    print(f"\n📊 Collection Summary:")
    print(f"   Total scrapes: {total_scrapes}")
    print(f"   Errors: {errors}")
    print(f"   Duration: {duration_actual//60}m {duration_actual%60}s")
    print(f"   Success rate: {(total_scrapes-errors)/total_scrapes*100:.1f}%")
    
    print(f"\n📁 Data collected by post (sorted by scrape count):")
    post_scrape_counts = [(pid, scrape_counts.get(pid, 0)) for pid in post_ids]
    post_scrape_counts.sort(key=lambda x: x[1], reverse=True)
    
    for post_id, count in post_scrape_counts:
        if count > 0:
            tree_state = monitor.trees[post_id]
            rate = tree_state['alpha'] / tree_state['beta'] if tree_state['beta'] > 0 else 0
            print(f"\n   {post_id}:")
            print(f"      Scrapes: {count}")
            print(f"      Est. comment rate: {rate:.2f} comments/minute")
            print(f"      Total observed: {tree_state['k_obs']} new comments")
            print(f"      Location: temporal_test/{post_id}/raw_scrapes/")
    
    print(f"\n🧠 Adaptive Sampling Performance:")
    print(f"   Most active posts got more attention")
    print(f"   Algorithm learned and adapted in real-time")
    
    print(f"\n💡 Next step: Run batch_merge_temporal_data.py to merge all scrapes")


if __name__ == '__main__':
    import sys
    
    if len(sys.argv) < 1:
        print("Usage: python test_temporal_scraping.py [subreddit] [duration_minutes]")
        print()
        print("Examples:")
        print("  python test_temporal_scraping.py news 60")
        print("  python test_temporal_scraping.py politics 120")
        print()
        print("Fetches posts from r/{subreddit}/new and adaptively scrapes them.")
        sys.exit(1)
    
    subreddit = sys.argv[1] if len(sys.argv) > 1 else 'news'
    duration = int(sys.argv[2]) if len(sys.argv) > 2 else 60
    
    run_adaptive_data_collection(subreddit, duration)

