#!/usr/bin/env python3
"""
Analyze score evolution from merged post data
"""

import json
import sys
from datetime import datetime

def analyze_scores(post_id):
    """Analyze score evolution over time"""
    
    merged_file = f'temporal_test/{post_id}/final_merged.json'
    
    try:
        with open(merged_file, 'r') as f:
            data = json.load(f)
    except FileNotFoundError:
        print(f"❌ File not found: {merged_file}")
        print("💡 Run merge_single_post.py first")
        return
    
    scores = data['post']['score_history']
    
    if not scores:
        print("❌ No score history found")
        return
    
    print("="*80)
    print(f"📈 SCORE EVOLUTION ANALYSIS: {post_id}")
    print("="*80)
    
    # Parse timestamps
    score_data = []
    for score, timestamp in scores:
        dt = datetime.fromisoformat(timestamp)
        score_data.append((dt, score))
    
    score_data.sort(key=lambda x: x[0])
    
    # Calculate statistics
    first_time, first_score = score_data[0]
    last_time, last_score = score_data[-1]
    min_score = min(s for _, s in score_data)
    max_score = max(s for _, s in score_data)
    
    duration = last_time - first_time
    total_hours = duration.total_seconds() / 3600
    
    print(f"\n📊 Summary:")
    print(f"   ├─ Measurements: {len(scores)}")
    print(f"   ├─ Duration: {duration}")
    print(f"   ├─ First score: {first_score:,} at {first_time.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"   ├─ Last score:  {last_score:,} at {last_time.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"   ├─ Peak score:  {max_score:,}")
    print(f"   ├─ Min score:   {min_score:,}")
    print(f"   └─ Net change:  {last_score - first_score:+,} ({(last_score/first_score - 1)*100:+.1f}%)")
    
    # Detect major changes
    print(f"\n📈 Score Timeline (showing changes > 50 points):")
    prev_score = first_score
    prev_time = first_time
    
    for i, (dt, score) in enumerate(score_data):
        change = score - prev_score
        
        if i == 0:
            print(f"   [{dt.strftime('%H:%M:%S')}] {score:5,} (initial)")
        elif abs(change) > 50:
            time_diff = dt - prev_time
            mins = time_diff.total_seconds() / 60
            print(f"   [{dt.strftime('%H:%M:%S')}] {score:5,} ({change:+4d}) +{mins:.0f}m")
            prev_score = score
            prev_time = dt
    
    # Show final
    if score_data[-1][1] != prev_score:
        time_diff = score_data[-1][0] - prev_time
        mins = time_diff.total_seconds() / 60
        change = score_data[-1][1] - prev_score
        print(f"   [{score_data[-1][0].strftime('%H:%M:%S')}] {score_data[-1][1]:5,} ({change:+4d}) +{mins:.0f}m (final)")
    
    # Volatility analysis
    changes = [abs(score_data[i][1] - score_data[i-1][1]) for i in range(1, len(score_data))]
    avg_change = sum(changes) / len(changes) if changes else 0
    
    print(f"\n📊 Volatility:")
    print(f"   ├─ Average change between measurements: {avg_change:.1f} points")
    print(f"   ├─ Max single jump: {max(changes) if changes else 0} points")
    print(f"   └─ Total range: {max_score - min_score} points")
    
    # Detect stability
    late_scores = [s for _, s in score_data[-10:]]
    late_range = max(late_scores) - min(late_scores)
    
    print(f"\n🎯 Activity Pattern:")
    print(f"   ├─ Growth rate: {(last_score - first_score) / total_hours:.1f} points/hour")
    print(f"   ├─ Last 10 measurements range: {late_range} points")
    
    if late_range < 20:
        print(f"   └─ Status: ✅ STABLE (score fluctuating within ±{late_range//2} points)")
    else:
        print(f"   └─ Status: 📈 ACTIVE (score still varying by {late_range} points)")
    
    print("\n" + "="*80)


if __name__ == '__main__':
    if len(sys.argv) != 2:
        print("Usage: python3 analyze_score_evolution.py <post_id>")
        print("Example: python3 analyze_score_evolution.py 1o64lfm")
        sys.exit(1)
    
    post_id = sys.argv[1]
    analyze_scores(post_id)

