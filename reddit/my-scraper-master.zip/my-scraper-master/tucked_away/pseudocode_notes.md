# pseudocode notes


thing 1: 

while(not at bottom of page){

    scroll down 3/4 of one page length

    while('expand' type buttons exist on screen in the comment section){
        expand_button = the 'expand' type button'

        if(expand_button opens a new page){
            save that link in a list for later
        }
        else{
            click expand_button
        }
    }
}

thing 2:



def get_replies(comment tree):
    unclicked_buttons_queue = empty queue
    clicked_buttons_list = empty list



Thing 3:
    
    Scroll
    
    Append_Data():
        Append newly available comment data as replies

        while(Pick != no_button_found):
            Click
            Append_Data()
            If nav detected, go back

    While(previous scroll changed the new last comment):
        Scroll
        Append_Data()

        

Thing 4:

    find_button(patterns, page):
        search page for ALL patterns
        return the first one found

        if no button found:
            return null

    while(scroll condition):

        scroll

        while(1):
            button = find_button()
            if(button):
                click button
            else
                break


    Thing 5:
    
    old_json contains all historical data
    new_json contains the new scrape, and gets merged into old_json

    for old_comment in old_json:
        
        bool is_present = does new_comment contain comment (check by hashing the commentid)

        if(is_present):
            update the corresponding old_comment with data from new_comment