#!/usr/bin/env python3
"""
Backfill Metadata for Existing URLs

Creates metadata entries for any URLs in tracked_urls.txt that don't have metadata.
Marks them as 'manual' source since they were added before the auto-discovery system.
"""

import json
import os
from datetime import datetime
import re


def extract_post_id(url):
    """Extract Reddit post ID from URL"""
    match = re.search(r'/comments/([^/]+)/', url)
    if match:
        return match.group(1)
    return None


def backfill_metadata():
    """Add metadata for tracked URLs that are missing it"""
    
    # Load existing metadata
    metadata = {}
    if os.path.exists('post_metadata.json'):
        with open('post_metadata.json', 'r') as f:
            metadata = json.load(f)
            # Remove schema info if present
            if '_schema_info' in metadata:
                del metadata['_schema_info']
    
    # Load tracked URLs
    tracked_urls = []
    if os.path.exists('tracked_urls.txt'):
        with open('tracked_urls.txt', 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#'):
                    tracked_urls.append(line)
    
    # Find missing metadata
    missing = []
    for url in tracked_urls:
        post_id = extract_post_id(url)
        if post_id and post_id not in metadata:
            missing.append((post_id, url))
    
    if not missing:
        print("✅ All tracked URLs have metadata")
        return
    
    print(f"Found {len(missing)} URLs without metadata\n")
    
    # Create metadata for missing posts
    now = datetime.now().isoformat()
    
    for post_id, url in missing:
        # Check if we have scrape data to determine when it was added
        scrape_dir = f'temporal_test/{post_id}/raw_scrapes'
        added_date = now
        
        if os.path.exists(scrape_dir):
            scrapes = sorted([f for f in os.listdir(scrape_dir) 
                            if f.startswith('scrape_') and f.endswith('.json')])
            if scrapes:
                # Extract date from first scrape filename
                # Format: scrape_001_20251015_092531.json
                first_scrape = scrapes[0]
                parts = first_scrape.split('_')
                if len(parts) >= 3:
                    date_str = parts[2]
                    time_str = parts[3].replace('.json', '')
                    added_date = f"{date_str[:4]}-{date_str[4:6]}-{date_str[6:8]}T{time_str[:2]}:{time_str[2:4]}:{time_str[4:6]}"
        
        metadata[post_id] = {
            'url': url,
            'added_date': added_date,
            'source': 'manual',  # Mark as manual since added before auto-discovery
            'state': 'active',
            'last_check': now,
            'last_activity': now,
            'dormancy_level': 0,
            'next_check_due': now,
            'activity_history': []
        }
        
        print(f"✅ Added metadata for {post_id} (added: {added_date[:10]})")
    
    # Save metadata
    with open('post_metadata.json', 'w') as f:
        json.dump(metadata, f, indent=2)
    
    print(f"\n✅ Backfilled metadata for {len(missing)} posts")
    print("All posts now have lifecycle metadata and will follow normal dormancy rules")


if __name__ == '__main__':
    backfill_metadata()

