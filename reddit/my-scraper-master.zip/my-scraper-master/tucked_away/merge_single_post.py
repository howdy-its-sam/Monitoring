#!/usr/bin/env python3
"""
Merge a single post's temporal data for testing
Usage: python3 merge_single_post.py <post_id>
"""

import os
import sys
import json
import re
from datetime import datetime, timezone
from reddit_scraper_api import flatten_tree, merge_flat_comments, rebuild_tree


def extract_scrape_timestamp(raw_data, filename):
    """
    Extract scrape timestamp with triple fallback:
    1. metadata.scraped_at (or legacy scrape_timestamp)
    2. filename pattern (scrape_###_YYYYMMDD_HHMMSS.json)
    3. Current time as last resort
    
    Returns UTC ISO string with Z suffix
    """
    # Try metadata first (with legacy compatibility)
    timestamp_str = raw_data.get('metadata', {}).get('scraped_at') \
                    or raw_data.get('metadata', {}).get('scrape_timestamp')
    
    if timestamp_str:
        try:
            dt = datetime.fromisoformat(timestamp_str.replace('Z', '+00:00'))
            return dt.astimezone(timezone.utc).isoformat().replace('+00:00', 'Z')
        except:
            pass
    
    # Try filename pattern
    match = re.search(r'scrape_\d+_(\d{8})_(\d{6})\.json', filename)
    if match:
        date_str, time_str = match.groups()
        try:
            dt = datetime.strptime(f'{date_str}_{time_str}', '%Y%m%d_%H%M%S')
            dt = dt.replace(tzinfo=timezone.utc)
            return dt.isoformat().replace('+00:00', 'Z')
        except:
            pass
    
    # Fallback to current time
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


def count_comments(comments):
    """Recursively count all comments in tree"""
    total = 0
    for c in comments:
        total += 1
        if c.get('replies'):
            total += count_comments(c['replies'])
    return total


def merge_two_datasets(base_data, new_data, current_time):
    """
    Merge two datasets using our flatten-merge-rebuild approach
    """
    # PHASE 1: Flatten
    old_flat = flatten_tree(base_data['comments'])
    new_flat = flatten_tree(new_data['comments'])
    
    # PHASE 2: Merge
    merged_flat = merge_flat_comments(old_flat, new_flat, current_time)
    
    # PHASE 3: Rebuild
    merged_tree, orphans = rebuild_tree(merged_flat)
    
    # Merge post data
    merged_post = base_data['post'].copy()
    new_score = new_data['post'].get('score_history', [[0, current_time]])[0][0]
    if 'score_history' not in merged_post:
        merged_post['score_history'] = []
    merged_post['score_history'].append([new_score, current_time])
    
    # Create merged result
    merged_data = {
        'post': merged_post,
        'comments': merged_tree,
        'metadata': {
            **new_data.get('metadata', {}),
            'temporal_merge': True,
            'merge_timestamp': current_time,
            'old_comment_count': len(old_flat),
            'new_comment_count': len(new_flat),
            'merged_comment_count': len(merged_flat),
            'top_level_count': len(merged_tree),
            'orphaned_count': len(orphans)
        }
    }
    
    return merged_data, orphans


def merge_single_post(post_id):
    """
    Merge all raw scrapes for a single post
    """
    
    scrape_dir = f'temporal_test/{post_id}/raw_scrapes'
    
    if not os.path.exists(scrape_dir):
        print(f"❌ Error: {scrape_dir} not found")
        return
    
    scrape_files = sorted([f for f in os.listdir(scrape_dir) if f.endswith('.json')])
    
    if not scrape_files:
        print(f"❌ No scrape files found in {scrape_dir}")
        return
    
    print("="*80)
    print(f"🔄 MERGING POST: {post_id}")
    print("="*80)
    print(f"\nFound {len(scrape_files)} scrapes to merge\n")
    
    # Load first scrape as base
    print(f"📂 Loading base: {scrape_files[0]}")
    with open(f'{scrape_dir}/{scrape_files[0]}', 'r') as f:
        merged_data = json.load(f)
    
    base_count = count_comments(merged_data['comments'])
    print(f"   ├─ {base_count} comments")
    
    # Track scrape metadata
    first_scrape_time = merged_data.get('metadata', {}).get('scrape_timestamp', 'unknown')
    print(f"   └─ Scraped at: {first_scrape_time}\n")
    
    # Merge each subsequent scrape
    all_orphans = []
    growth_log = [(1, base_count, scrape_files[0])]
    
    for i, scrape_file in enumerate(scrape_files[1:], 2):
        print(f"📂 [{i}/{len(scrape_files)}] Merging {scrape_file}...", end=' ', flush=True)
        
        try:
            with open(f'{scrape_dir}/{scrape_file}', 'r') as f:
                new_data = json.load(f)
            
            # Use our merge function with actual scrape timestamp
            scrape_time = extract_scrape_timestamp(new_data, scrape_file)
            merged_data, orphans = merge_two_datasets(merged_data, new_data, scrape_time)
            
            if orphans:
                all_orphans.extend(orphans)
            
            total = count_comments(merged_data['comments'])
            added = merged_data['metadata'].get('merged_comment_count', 0) - merged_data['metadata'].get('old_comment_count', 0)
            
            print(f"✅ {total} total (+{added} new)")
            growth_log.append((i, total, scrape_file))
            
        except Exception as e:
            print(f"❌ Error: {e}")
    
    # Save final merged result
    output_file = f'temporal_test/{post_id}/final_merged.json'
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(merged_data, f, indent=2, ensure_ascii=False)
    
    final_count = count_comments(merged_data['comments'])
    
    print("\n" + "="*80)
    print("📊 MERGE COMPLETE - SUMMARY")
    print("="*80)
    print(f"\n✅ Saved to: {output_file}")
    print(f"\n📈 Growth Analysis:")
    print(f"   ├─ Starting comments: {base_count}")
    print(f"   ├─ Final comments: {final_count}")
    print(f"   ├─ Total growth: +{final_count - base_count} comments")
    print(f"   └─ Scrapes merged: {len(scrape_files)}")
    
    if all_orphans:
        print(f"\n⚠️  Orphaned Comments: {len(all_orphans)}")
        print("   (Comments whose parent_id doesn't match any known comment)")
        
        # Show first few orphans
        print("\n   First 5 orphans:")
        for orphan in all_orphans[:5]:
            author = orphan.get('author', 'unknown')
            text = orphan.get('body', '')[:50] + '...' if len(orphan.get('body', '')) > 50 else orphan.get('body', '')
            parent = orphan.get('parent_id', 'unknown')
            print(f"      • [{author}] parent={parent}: {text}")
    
    # Show interesting scrapes (where growth happened)
    print(f"\n📊 Comment Growth Over Time:")
    for scrape_num, count, filename in growth_log:
        if scrape_num == 1:
            print(f"   Scrape {scrape_num:3d}: {count:4d} comments (base)")
        else:
            prev_count = growth_log[scrape_num - 2][1]
            change = count - prev_count
            if change > 0:
                print(f"   Scrape {scrape_num:3d}: {count:4d} comments (+{change}) ✨")
            else:
                print(f"   Scrape {scrape_num:3d}: {count:4d} comments (no change)")
    
    print("\n" + "="*80)


if __name__ == '__main__':
    if len(sys.argv) != 2:
        print("Usage: python3 merge_single_post.py <post_id>")
        print("Example: python3 merge_single_post.py 1o64lfm")
        sys.exit(1)
    
    post_id = sys.argv[1]
    merge_single_post(post_id)

