import math
import random
import time

class TreeMonitor:
    def __init__(self, tree_ids, alpha0=1.0, beta0=1.0,
                 phi=0.97, kappa=0.2, eta=0.2, rho=1.5,
                 delta=1.0, gamma=0.2, tau=3.0, p=2.0,
                 w_abs=0.6, w_rel=0.4, c=50.0, use_power=False, alpha_power=0.0,
                 measurement_bonus=25.0, measurement_threshold=5):
        """
        Initialize TreeMonitor with Bayesian adaptive sampling.
        
        Args:
            tree_ids: List of tree/post IDs to monitor
            alpha0, beta0: Prior parameters for rate estimation
            phi: Discount factor for old observations
            kappa: Weight for uncertainty (exploration)
            eta: Weight for burst detection
            rho: Weight for staleness penalty
            delta: Burst decay rate
            gamma: Burst sensitivity
            tau: Staleness timescale
            p: Staleness curve shape
            w_abs: Weight for absolute expected yield
            w_rel: Weight for relative gain (diminishing returns)
            c: Baseline constant for relative gain calculation
            use_power: If True, use power utility instead of log utility
            alpha_power: Exponent for power utility (0 < alpha < 1)
            measurement_bonus: Points added per missing scrape below threshold
            measurement_threshold: Target minimum number of scrapes per post
        """
        self.trees = {tid: {
            "alpha": alpha0,
            "beta": beta0,
            "b": 0.0,
            "t_last": 0.0,
            "k_obs": 0,
            "scrape_count": 0
        } for tid in tree_ids}
        self.params = dict(phi=phi, kappa=kappa, eta=eta, rho=rho,
                           delta=delta, gamma=gamma, tau=tau, p=p,
                           w_abs=w_abs, w_rel=w_rel, c=c,
                           use_power=use_power, alpha_power=alpha_power,
                           measurement_bonus=measurement_bonus,
                           measurement_threshold=measurement_threshold)
        self.clock = 0.0  # simulated time (e.g. hours)

    def expected_yield(self, t):
        a, b = t["alpha"], t["beta"]
        dt = self.clock - t["t_last"]
        lam_hat = a / max(b, 0.001)  # Safety: prevent division by zero
        return lam_hat * dt

    def uncertainty(self, t):
        a, b = t["alpha"], t["beta"]
        dt = self.clock - t["t_last"]
        lam_hat = a / max(b, 0.001)  # Safety: prevent division by zero
        return math.sqrt(lam_hat*dt + lam_hat*(dt**2)/max(b, 0.001))

    def staleness(self, dt):
        tau, p = self.params["tau"], self.params["p"]
        return ( (dt / tau)**p ) / (1 + (dt / tau)**p)
    
    def relative_gain(self, tid):
        """
        Calculate relative gain with diminishing returns based on post size.
        
        Implements two utility models:
        1. Log utility (default): E / (T + c)
           - Simple, interpretable
           - Natural diminishing returns
        
        2. Power utility: (T + c)^(alpha-1) * E
           - More flexible curve shape
           - alpha in (0,1) controls diminishing returns strength
        
        Args:
            tid: Tree/post ID
            
        Returns:
            Relative gain score (accounts for current post size)
        """
        t = self.trees[tid]
        dt = self.clock - t["t_last"]
        
        if dt <= 0:
            return 0.0
        
        # Expected absolute yield
        lam_hat = t["alpha"] / max(t["beta"], 0.001)  # Safety: prevent division by zero
        E = lam_hat * dt
        
        # Current known size of the post
        T = t.get("k_obs", 0)
        
        # Get parameters
        c = self.params["c"]
        use_power = self.params["use_power"]
        alpha = self.params["alpha_power"]
        
        base = max(T + c, 1.0)  # Safety: ensure base >= 1
        
        if use_power and 0.0 < alpha < 1.0:
            # Power utility: marginal utility ~ (T+c)^(alpha-1) * E
            return (base ** (alpha - 1.0)) * E
        else:
            # Log utility approximation: E / (T + c)
            return E / base

    def measurement_bias(self, tid):
        """
        Give priority boost to posts with few measurements.
        Ensures posts get adequate sampling even if activity appears low.
        
        Returns bonus score that decays as scrape_count increases.
        """
        t = self.trees[tid]
        scrape_count = t.get("scrape_count", 0)
        threshold = self.params["measurement_threshold"]  # Default: 5
        bonus_per_missing = self.params["measurement_bonus"]  # Default: 25
        
        if scrape_count < threshold:
            # Linear decay: with threshold=5, bonus=25 -> (125, 100, 75, 50, 25)
            bonus = (threshold - scrape_count) * bonus_per_missing
            return bonus
        else:
            return 0.0

    def score(self, tid):
        """
        Calculate priority score for a tree/post.
        
        Combines:
        - Absolute expected yield (w_abs * E): Raw number of expected comments
        - Relative gain (w_rel * rel): Value accounting for diminishing returns
        - Uncertainty (kappa * U): Exploration bonus
        - Burst state (eta * H): Sudden activity detection
        - Staleness (rho * S): Penalty for not checking recently
        - Measurement bias (M): Boost for under-sampled posts
        
        Returns:
            Priority score (higher = should scrape next)
        """
        t = self.trees[tid]
        dt = self.clock - t["t_last"]
        
        # Virgin bonus: Never-scraped posts get huge priority
        if t["t_last"] == 0:
            return 1000.0  # Ensures all posts scraped at least once first
        
        if dt <= 0 or t.get("dormant", False):
            return 0.0
        
        # Get parameters
        φ = self.params
        
        # Calculate components
        E = self.expected_yield(t)  # Absolute expected yield
        rel = self.relative_gain(tid)  # Relative gain with diminishing returns
        U = self.uncertainty(t)  # Uncertainty/exploration
        H = t["b"]  # Burst state
        S = self.staleness(dt)  # Staleness penalty
        M = self.measurement_bias(tid)  # Measurement count bias
        
        # Combined score with configurable weights
        return (φ["w_abs"] * E) + (φ["w_rel"] * rel) + φ["kappa"]*U + φ["eta"]*H + φ["rho"]*S + M

    def pick_tree(self):
        scores = {tid: self.score(tid) for tid in self.trees}
        return max(scores, key=scores.get), scores

    def measure_tree(self, tid, k_new):
        """Update the chosen tree after observing k_new new comments."""
        t = self.trees[tid]
        φ, δ, γ = self.params["phi"], self.params["delta"], self.params["gamma"]
        w = max(self.clock - t["t_last"], 0.001)  # Safety: ensure w > 0
        # Discounted Bayesian update
        t["alpha"] = φ * t["alpha"] + k_new
        t["beta"]  = φ * t["beta"]  + w
        # Burst state update
        t["b"] = math.exp(-δ * w) * t["b"] + γ * k_new
        t["t_last"] = self.clock
        t["k_obs"] += k_new
        t["scrape_count"] += 1  # Increment scrape count for measurement bias

    def simulate_step(self, true_rates):
        """Example: simulate new data based on true underlying Poisson rates."""
        # Increment clock by 1 time unit
        self.clock += 1.0
        tid, scores = self.pick_tree()
        # simulate new comments for each tree based on true λ
        new_counts = {i: random.poisson(l*1.0) if hasattr(random, "poisson")
                      else int(random.expovariate(1/l) < 1.0)  # crude fallback
                      for i, l in true_rates.items()}
        k_new = new_counts[tid]
        self.measure_tree(tid, k_new)
        return tid, k_new, scores[tid]

# --- Example usage ---------------------------------------
if __name__ == "__main__":
    trees = ["oak", "pine", "maple", "birch"]
    monitor = TreeMonitor(trees)
    # suppose true comment rates per hour
    true_rates = {"oak": 0.3, "pine": 0.1, "maple": 0.5, "birch": 0.05}

    for step in range(20):
        monitor.clock += 1.0  # time passes
        tid, scores = monitor.pick_tree()
        print(f"t={monitor.clock:.1f}: next -> {tid} (score={scores[tid]:.3f})")
        # simulate "measurement"
        k_new = random.poisson(true_rates[tid]) if hasattr(random, "poisson") else int(random.random() < true_rates[tid])
        monitor.measure_tree(tid, k_new)

