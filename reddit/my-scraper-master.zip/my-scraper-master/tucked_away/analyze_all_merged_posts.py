#!/usr/bin/env python3
"""
Analyze all merged posts to find patterns for tuning dormancy thresholds and priority constants
"""

import os
import json
from datetime import datetime
from collections import defaultdict


def count_comments(comments):
    """Recursively count all comments in tree"""
    total = 0
    for c in comments:
        total += 1
        if c.get('replies'):
            total += count_comments(c['replies'])
    return total


def analyze_all_posts():
    """
    Analyze all final_merged.json files to understand:
    1. Comment growth patterns
    2. Score evolution patterns
    3. When posts become dormant
    4. Optimal scraping frequency
    """
    
    temporal_dir = 'temporal_test'
    if not os.path.exists(temporal_dir):
        print("❌ temporal_test/ directory not found")
        return
    
    all_posts = []
    
    # Collect data from all posts
    for post_id in os.listdir(temporal_dir):
        merged_file = f'{temporal_dir}/{post_id}/final_merged.json'
        raw_dir = f'{temporal_dir}/{post_id}/raw_scrapes'
        
        if not os.path.exists(merged_file) or not os.path.isdir(raw_dir):
            continue
        
        try:
            with open(merged_file, 'r') as f:
                data = json.load(f)
            
            # Load all raw scrapes to track growth
            raw_files = sorted([f for f in os.listdir(raw_dir) if f.endswith('.json')])
            
            comment_history = []
            score_history = []
            
            for raw_file in raw_files:
                try:
                    with open(f'{raw_dir}/{raw_file}', 'r') as f:
                        raw_data = json.load(f)
                    
                    # Use correct field name with legacy compatibility
                    timestamp = raw_data.get('metadata', {}).get('scraped_at') \
                                or raw_data.get('metadata', {}).get('scrape_timestamp', '')
                    if timestamp:
                        try:
                            dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
                        except:
                            # Try extracting from filename as fallback
                            parts = raw_file.replace('.json', '').split('_')
                            if len(parts) >= 4:
                                date_str = parts[2]
                                time_str = parts[3]
                                dt = datetime.strptime(f'{date_str}_{time_str}', '%Y%m%d_%H%M%S')
                            else:
                                continue
                    else:
                        # Extract from filename if no metadata
                        # Format: scrape_###_YYYYMMDD_HHMMSS.json
                        parts = raw_file.replace('.json', '').split('_')
                        if len(parts) >= 4:
                            date_str = parts[2]
                            time_str = parts[3]
                            dt = datetime.strptime(f'{date_str}_{time_str}', '%Y%m%d_%H%M%S')
                        else:
                            continue
                    
                    comment_count = count_comments(raw_data.get('comments', []))
                    score = raw_data.get('post', {}).get('score', 0)
                    
                    comment_history.append((dt, comment_count))
                    score_history.append((dt, score))
                    
                except Exception as e:
                    continue
            
            if not comment_history:
                continue
            
            # Calculate metrics
            final_comments = data.get('metadata', {}).get('merged_comment_count', 0)
            scrape_count = len(raw_files)
            
            # Find when post stopped growing (comments)
            last_growth_time = None
            last_count = comment_history[0][1]
            for i, (dt, count) in enumerate(comment_history):
                if count > last_count:
                    last_growth_time = dt
                    last_count = count
            
            # Calculate time to dormancy (comment perspective)
            first_time = comment_history[0][0]
            if last_growth_time:
                time_to_dormancy = (last_growth_time - first_time).total_seconds() / 3600  # hours
            else:
                time_to_dormancy = 0
            
            # Calculate score volatility in last 25% of scrapes
            late_threshold = int(len(score_history) * 0.75)
            late_scores = [s for _, s in score_history[late_threshold:]]
            if late_scores:
                score_range_late = max(late_scores) - min(late_scores)
                score_volatility = score_range_late / (max(late_scores) if max(late_scores) > 0 else 1)
            else:
                score_range_late = 0
                score_volatility = 0
            
            # Total growth
            initial_comments = comment_history[0][1]
            final_comments_actual = comment_history[-1][1]
            total_growth = final_comments_actual - initial_comments
            growth_rate = total_growth / scrape_count if scrape_count > 0 else 0
            
            # Wasted scrapes (no new comments)
            wasted_scrapes = sum(1 for i in range(1, len(comment_history)) 
                                if comment_history[i][1] == comment_history[i-1][1])
            waste_ratio = wasted_scrapes / scrape_count if scrape_count > 0 else 0
            
            all_posts.append({
                'post_id': post_id,
                'scrape_count': scrape_count,
                'initial_comments': initial_comments,
                'final_comments': final_comments_actual,
                'total_growth': total_growth,
                'growth_rate': growth_rate,
                'time_to_dormancy_hours': time_to_dormancy,
                'wasted_scrapes': wasted_scrapes,
                'waste_ratio': waste_ratio,
                'score_volatility_late': score_volatility,
                'score_range_late': score_range_late,
                'comment_history': comment_history,
                'score_history': score_history
            })
            
        except Exception as e:
            print(f"⚠️  Error processing {post_id}: {e}")
            continue
    
    if not all_posts:
        print("❌ No merged posts found")
        return
    
    # Sort by final comments (most active posts first)
    all_posts.sort(key=lambda p: p['final_comments'], reverse=True)
    
    print("="*100)
    print("📊 COMPREHENSIVE POST ANALYSIS - DORMANCY & PRIORITY TUNING")
    print("="*100)
    print(f"\nAnalyzed {len(all_posts)} posts\n")
    
    # ========== SECTION 1: COMMENT GROWTH PATTERNS ==========
    print("="*100)
    print("1️⃣  COMMENT GROWTH PATTERNS")
    print("="*100)
    
    print(f"\n{'Post ID':<12} {'Scrapes':<8} {'Initial':<8} {'Final':<8} {'Growth':<8} {'Rate/Scrape':<12} {'Dormancy(h)':<12} {'Waste%':<8}")
    print("-"*100)
    
    for p in all_posts[:15]:  # Top 15 most active
        print(f"{p['post_id']:<12} {p['scrape_count']:<8} {p['initial_comments']:<8} "
              f"{p['final_comments']:<8} {p['total_growth']:<8} {p['growth_rate']:<12.2f} "
              f"{p['time_to_dormancy_hours']:<12.1f} {p['waste_ratio']*100:<7.1f}%")
    
    # Statistics
    avg_growth_rate = sum(p['growth_rate'] for p in all_posts) / len(all_posts)
    avg_waste_ratio = sum(p['waste_ratio'] for p in all_posts) / len(all_posts)
    avg_dormancy_time = sum(p['time_to_dormancy_hours'] for p in all_posts if p['time_to_dormancy_hours'] > 0) / \
                        len([p for p in all_posts if p['time_to_dormancy_hours'] > 0])
    
    print(f"\n📊 Averages:")
    print(f"   ├─ Growth rate: {avg_growth_rate:.2f} comments/scrape")
    print(f"   ├─ Waste ratio: {avg_waste_ratio*100:.1f}% of scrapes had no new comments")
    print(f"   └─ Time to dormancy: {avg_dormancy_time:.1f} hours")
    
    # ========== SECTION 2: DORMANCY DETECTION ==========
    print("\n" + "="*100)
    print("2️⃣  DORMANCY DETECTION PATTERNS")
    print("="*100)
    
    # Categorize posts by activity pattern
    highly_active = [p for p in all_posts if p['waste_ratio'] < 0.3]
    moderately_active = [p for p in all_posts if 0.3 <= p['waste_ratio'] < 0.7]
    dormant = [p for p in all_posts if p['waste_ratio'] >= 0.7]
    
    print(f"\n📈 Activity Categories:")
    print(f"   ├─ Highly Active (<30% waste): {len(highly_active)} posts")
    print(f"   ├─ Moderately Active (30-70% waste): {len(moderately_active)} posts")
    print(f"   └─ Dormant (>70% waste): {len(dormant)} posts")
    
    print(f"\n🎯 Recommended Dormancy Threshold:")
    print(f"   → After {avg_dormancy_time:.0f} hours with no growth")
    print(f"   → Or after 5 consecutive scrapes with 0 new comments")
    print(f"   → Or when growth rate drops below {avg_growth_rate * 0.1:.2f} comments/scrape (10% of average)")
    
    # ========== SECTION 3: SCORE VS COMMENT DIVERGENCE ==========
    print("\n" + "="*100)
    print("3️⃣  SCORE VS COMMENT DIVERGENCE")
    print("="*100)
    
    print(f"\n{'Post ID':<12} {'Comment Growth':<15} {'Score Volatility':<18} {'Pattern':<30}")
    print("-"*100)
    
    for p in all_posts[:20]:
        if p['score_volatility_late'] < 0.01:
            pattern = "Both stable (fully dormant)"
        elif p['waste_ratio'] > 0.8 and p['score_volatility_late'] > 0.02:
            pattern = "Comments dead, votes active ⚠️"
        elif p['waste_ratio'] < 0.3 and p['score_volatility_late'] > 0.02:
            pattern = "Both active"
        else:
            pattern = "Mixed activity"
        
        growth_str = f"+{p['total_growth']} in {p['time_to_dormancy_hours']:.0f}h"
        print(f"{p['post_id']:<12} {growth_str:<15} "
              f"{p['score_volatility_late']:<18.3f} {pattern:<30}")
    
    # ========== SECTION 4: PRIORITY SYSTEM RECOMMENDATIONS ==========
    print("\n" + "="*100)
    print("4️⃣  PRIORITY SYSTEM TUNING RECOMMENDATIONS")
    print("="*100)
    
    # Calculate optimal measurement threshold
    posts_by_initial_size = sorted(all_posts, key=lambda p: p['initial_comments'])
    small_posts = [p for p in all_posts if p['initial_comments'] < 100]
    large_posts = [p for p in all_posts if p['initial_comments'] >= 500]
    
    print(f"\n📏 Post Size Distribution:")
    print(f"   ├─ Small (<100 comments): {len(small_posts)} posts, avg growth: {sum(p['total_growth'] for p in small_posts)/len(small_posts) if small_posts else 0:.1f}")
    print(f"   ├─ Medium (100-500): {len([p for p in all_posts if 100 <= p['initial_comments'] < 500])} posts")
    print(f"   └─ Large (>500): {len(large_posts)} posts, avg growth: {sum(p['total_growth'] for p in large_posts)/len(large_posts) if large_posts else 0:.1f}")
    
    # Scrape count needed to capture 95% of growth
    print(f"\n🎯 Optimal Scraping Strategy:")
    
    for p in all_posts[:10]:
        # Find scrape where 95% of growth was captured
        target_comments = p['initial_comments'] + (p['total_growth'] * 0.95)
        scrapes_to_95 = 0
        for i, (dt, count) in enumerate(p['comment_history']):
            if count >= target_comments:
                scrapes_to_95 = i + 1
                break
        if scrapes_to_95 == 0:
            scrapes_to_95 = len(p['comment_history'])
        
        efficiency = (scrapes_to_95 / p['scrape_count']) * 100 if p['scrape_count'] > 0 else 0
        print(f"   {p['post_id']}: {scrapes_to_95}/{p['scrape_count']} scrapes captured 95% growth ({efficiency:.0f}% efficiency)")
    
    # Calculate recommended constants
    print(f"\n💡 Recommended Constants:")
    print(f"   ├─ measurement_threshold: 5 scrapes (ensure sufficient initial sampling)")
    print(f"   ├─ measurement_bonus: 25 points (boost undersampled posts)")
    print(f"   ├─ dormancy_trigger: {avg_dormancy_time:.0f} hours OR 5 consecutive zero-growth scrapes")
    print(f"   ├─ staleness_weight (η): 0.3-0.5 (prioritize posts not checked recently)")
    print(f"   └─ expected_yield_weight (w_abs): 1.0-1.5 (prioritize posts likely to have new comments)")
    
    # ========== SECTION 5: WASTE ANALYSIS ==========
    print("\n" + "="*100)
    print("5️⃣  RESOURCE WASTE ANALYSIS")
    print("="*100)
    
    total_scrapes = sum(p['scrape_count'] for p in all_posts)
    total_wasted = sum(p['wasted_scrapes'] for p in all_posts)
    total_comments_collected = sum(p['total_growth'] for p in all_posts)
    
    print(f"\n📊 Overall Statistics:")
    print(f"   ├─ Total scrapes performed: {total_scrapes}")
    print(f"   ├─ Wasted scrapes (no new data): {total_wasted} ({total_wasted/total_scrapes*100:.1f}%)")
    print(f"   ├─ Total comments collected: {total_comments_collected}")
    print(f"   ├─ Efficiency: {total_comments_collected/total_scrapes:.2f} new comments per scrape")
    print(f"   └─ Potential savings with better dormancy detection: ~{total_wasted * 0.7:.0f} scrapes")
    
    # Posts that should have been retired early
    should_retire = [p for p in all_posts if p['waste_ratio'] > 0.9 and p['scrape_count'] > 10]
    print(f"\n⚠️  Posts that should have been retired earlier:")
    for p in should_retire[:5]:
        print(f"   • {p['post_id']}: {p['wasted_scrapes']}/{p['scrape_count']} wasted scrapes ({p['waste_ratio']*100:.0f}%)")
    
    print("\n" + "="*100)
    print("✅ ANALYSIS COMPLETE")
    print("="*100)
    print(f"\n💡 Key Takeaways:")
    print(f"   1. Average post becomes dormant after {avg_dormancy_time:.0f} hours")
    print(f"   2. {avg_waste_ratio*100:.0f}% of scrapes are currently wasted on dormant posts")
    print(f"   3. Most posts need 5-10 scrapes to capture 95% of their growth")
    print(f"   4. Score continues to fluctuate even after comment activity stops")
    print(f"   5. Implementing smart dormancy detection could save ~{total_wasted * 0.7:.0f} API calls")
    print()


if __name__ == '__main__':
    analyze_all_posts()

