#!/usr/bin/env python3
"""
Test lifecycle transitions with mock data

Creates mock scrape data to test dormancy detection and state transitions
"""

import json
import os
from datetime import datetime, timedelta


def create_mock_scrape(post_id, scrape_num, comment_count, timestamp):
    """Create a mock scrape file"""
    scrape_dir = f'temporal_test/{post_id}/raw_scrapes'
    os.makedirs(scrape_dir, exist_ok=True)
    
    # Create mock data
    mock_data = {
        'comments': [{'id': f'comment_{i}'} for i in range(comment_count)],
        'post_data': {'id': post_id, 'title': f'Test Post {post_id}'}
    }
    
    # Format timestamp for filename
    ts_str = timestamp.strftime('%Y%m%d_%H%M%S')
    filename = f'scrape_{scrape_num:03d}_{ts_str}.json'
    filepath = os.path.join(scrape_dir, filename)
    
    with open(filepath, 'w') as f:
        json.dump(mock_data, f, indent=2)
    
    print(f"   Created {filename} with {comment_count} comments")


def test_active_to_dormant():
    """Test: Active post with low activity should go dormant"""
    print("\n" + "="*80)
    print("TEST 1: Active → Dormant (low activity)")
    print("="*80 + "\n")
    
    post_id = 'test_dormant'
    url = f'https://www.reddit.com/r/news/comments/{post_id}/test/'
    
    # Create metadata entry
    metadata = json.load(open('post_metadata.json', 'r')) if os.path.exists('post_metadata.json') else {}
    now = datetime.now()
    
    metadata[post_id] = {
        'url': url,
        'added_date': (now - timedelta(days=2)).isoformat(),
        'source': 'test',
        'state': 'active',
        'last_check': now.isoformat(),
        'last_activity': now.isoformat(),
        'dormancy_level': 0,
        'next_check_due': now.isoformat(),
        'activity_history': []
    }
    
    # Create 5 scrapes with minimal growth (< 5 comments per scrape)
    print("Creating mock scrapes with low activity...")
    for i in range(5):
        timestamp = now - timedelta(hours=5-i)
        comment_count = 10 + i  # Growth of 1 comment per scrape (< threshold)
        create_mock_scrape(post_id, i+1, comment_count, timestamp)
    
    # Add to tracked URLs
    tracked_urls = []
    if os.path.exists('tracked_urls.txt'):
        with open('tracked_urls.txt', 'r') as f:
            tracked_urls = [line.strip() for line in f if line.strip() and not line.startswith('#')]
    
    if url not in tracked_urls:
        tracked_urls.append(url)
    
    with open('tracked_urls.txt', 'w') as f:
        f.write("# Tracked URLs\n\n")
        for u in tracked_urls:
            f.write(f"{u}\n")
    
    # Save metadata
    with open('post_metadata.json', 'w') as f:
        json.dump(metadata, f, indent=2)
    
    print("\n✅ Mock data created. Running maintenance...\n")
    
    # Run maintenance
    import subprocess
    result = subprocess.run(['python3', 'manage_tracked_posts.py', 'news'], capture_output=True, text=True)
    print(result.stdout)
    
    # Check result
    metadata = json.load(open('post_metadata.json', 'r'))
    if post_id in metadata:
        state = metadata[post_id]['state']
        print(f"\n✅ Test 1 Result: Post state = {state}")
        if state == 'dormant':
            print("   ✅ SUCCESS: Post transitioned to dormant")
        else:
            print("   ⚠️  Expected dormant, got {state}")
    else:
        print(f"\n❌ Post {post_id} not found in metadata")


def test_dormant_escalation():
    """Test: Dormant post with continued low activity should escalate level"""
    print("\n" + "="*80)
    print("TEST 2: Dormant level escalation")
    print("="*80 + "\n")
    
    post_id = 'test_escalate'
    url = f'https://www.reddit.com/r/news/comments/{post_id}/test/'
    
    # Create metadata entry (already dormant)
    metadata = json.load(open('post_metadata.json', 'r')) if os.path.exists('post_metadata.json') else {}
    now = datetime.now()
    
    metadata[post_id] = {
        'url': url,
        'added_date': (now - timedelta(weeks=2)).isoformat(),
        'source': 'test',
        'state': 'dormant',
        'last_check': (now - timedelta(weeks=1, days=1)).isoformat(),  # Overdue
        'last_activity': (now - timedelta(weeks=2)).isoformat(),
        'dormancy_level': 0,
        'next_check_due': (now - timedelta(days=1)).isoformat(),  # Overdue
        'activity_history': []
    }
    
    # Create scrapes with no growth
    print("Creating mock scrapes with no activity...")
    for i in range(5):
        timestamp = now - timedelta(weeks=2, hours=5-i)
        comment_count = 50  # No growth
        create_mock_scrape(post_id, i+1, comment_count, timestamp)
    
    # Add to tracked URLs
    tracked_urls = []
    if os.path.exists('tracked_urls.txt'):
        with open('tracked_urls.txt', 'r') as f:
            tracked_urls = [line.strip() for line in f if line.strip() and not line.startswith('#')]
    
    if url not in tracked_urls:
        tracked_urls.append(url)
    
    with open('tracked_urls.txt', 'w') as f:
        f.write("# Tracked URLs\n\n")
        for u in tracked_urls:
            f.write(f"{u}\n")
    
    # Save metadata
    with open('post_metadata.json', 'w') as f:
        json.dump(metadata, f, indent=2)
    
    print("\n✅ Mock data created. Running maintenance...\n")
    
    # Run maintenance
    import subprocess
    result = subprocess.run(['python3', 'manage_tracked_posts.py', 'news'], capture_output=True, text=True)
    print(result.stdout)
    
    # Check result
    metadata = json.load(open('post_metadata.json', 'r'))
    if post_id in metadata:
        level = metadata[post_id].get('dormancy_level', 0)
        print(f"\n✅ Test 2 Result: Dormancy level = {level}")
        if level == 1:
            print("   ✅ SUCCESS: Level escalated from 0 to 1")
        else:
            print(f"   ⚠️  Expected level 1, got {level}")
    else:
        print(f"\n❌ Post {post_id} not found in metadata")


def test_dormant_reactivation():
    """Test: Dormant post with activity spike should reactivate"""
    print("\n" + "="*80)
    print("TEST 3: Dormant → Active (activity spike)")
    print("="*80 + "\n")
    
    post_id = 'test_reactivate'
    url = f'https://www.reddit.com/r/news/comments/{post_id}/test/'
    
    # Create metadata entry (dormant)
    metadata = json.load(open('post_metadata.json', 'r')) if os.path.exists('post_metadata.json') else {}
    now = datetime.now()
    
    metadata[post_id] = {
        'url': url,
        'added_date': (now - timedelta(weeks=3)).isoformat(),
        'source': 'test',
        'state': 'dormant',
        'last_check': (now - timedelta(weeks=2, days=1)).isoformat(),
        'last_activity': (now - timedelta(weeks=3)).isoformat(),
        'dormancy_level': 1,
        'next_check_due': (now - timedelta(days=1)).isoformat(),  # Overdue
        'activity_history': []
    }
    
    # Create scrapes: initially low, then spike
    print("Creating mock scrapes with activity spike...")
    for i in range(5):
        timestamp = now - timedelta(hours=5-i)
        if i < 3:
            comment_count = 50 + i  # Low growth
        else:
            comment_count = 50 + i + 20  # Spike! (+20 comments)
        create_mock_scrape(post_id, i+1, comment_count, timestamp)
    
    # Add to tracked URLs
    tracked_urls = []
    if os.path.exists('tracked_urls.txt'):
        with open('tracked_urls.txt', 'r') as f:
            tracked_urls = [line.strip() for line in f if line.strip() and not line.startswith('#')]
    
    if url not in tracked_urls:
        tracked_urls.append(url)
    
    with open('tracked_urls.txt', 'w') as f:
        f.write("# Tracked URLs\n\n")
        for u in tracked_urls:
            f.write(f"{u}\n")
    
    # Save metadata
    with open('post_metadata.json', 'w') as f:
        json.dump(metadata, f, indent=2)
    
    print("\n✅ Mock data created. Running maintenance...\n")
    
    # Run maintenance
    import subprocess
    result = subprocess.run(['python3', 'manage_tracked_posts.py', 'news'], capture_output=True, text=True)
    print(result.stdout)
    
    # Check result
    metadata = json.load(open('post_metadata.json', 'r'))
    if post_id in metadata:
        state = metadata[post_id]['state']
        print(f"\n✅ Test 3 Result: Post state = {state}")
        if state == 'active':
            print("   ✅ SUCCESS: Post reactivated due to activity spike")
        else:
            print(f"   ⚠️  Expected active, got {state}")
    else:
        print(f"\n❌ Post {post_id} not found in metadata")


if __name__ == '__main__':
    print("\n" + "="*80)
    print("🧪 LIFECYCLE TRANSITION TESTS")
    print("="*80)
    
    # Run tests
    test_active_to_dormant()
    test_dormant_escalation()
    test_dormant_reactivation()
    
    print("\n" + "="*80)
    print("✅ ALL TESTS COMPLETE")
    print("="*80 + "\n")
    
    print("Run 'python3 view_post_lifecycle.py' to see current states")

