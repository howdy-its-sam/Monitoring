# Relative Gain Enhancement - Explained

## What Changed?

Your adaptive sampling system now includes **diminishing returns** - it recognizes that 10 new comments on a small post (50 comments) is more valuable than 10 new comments on a mega-thread (1000 comments).

---

## The Enhancement

### **New Method: `relative_gain()`**

Calculates the **value per comment** based on current post size.

**Formula (Log Utility - Default):**
```
relative_gain = E / (T + c)
```

Where:
- `E` = Expected new comments (λ * dt)
- `T` = Current total comments (`k_obs`)
- `c` = Baseline constant (default: 50)

### **Updated Score Function:**

```
score = (w_abs * E) + (w_rel * rel) + κ*U + η*H + ρ*S
```

**Components:**
- `w_abs * E`: **Absolute gain** (raw expected comments)
- `w_rel * rel`: **Relative gain** (value accounting for size)
- `κ*U`: Uncertainty (exploration)
- `η*H`: Burst detection
- `ρ*S`: Staleness penalty

---

## Current Configuration

**Default Parameters:**
```python
w_abs = 0.6      # 60% weight on absolute yield
w_rel = 0.4      # 40% weight on relative gain
c = 50.0         # Baseline (posts <200 comments get boost)
use_power = False  # Use simple log utility
```

**This means:**
- Still prioritizes high-activity posts (60% absolute)
- But gives smaller posts fair consideration (40% relative)
- Posts under ~200 comments get a relative boost

---

## Real-World Examples

### **Scenario 1: Two Active Posts**

**Post A (Mega-thread):**
- 1000 comments currently
- λ = 10 comments/min
- dt = 5 minutes since last scrape
- E = 50 expected comments

**Post B (Growing thread):**
- 100 comments currently
- λ = 8 comments/min
- dt = 5 minutes since last scrape
- E = 40 expected comments

#### **Old System (Pure Absolute):**
```
Post A: score ≈ 50 (higher)
Post B: score ≈ 40 (lower)
```
Post A wins easily.

#### **New System (w_abs=0.6, w_rel=0.4, c=50):**
```
Post A: 
  Absolute: 0.6 * 50 = 30
  Relative: 0.4 * (50 / 1050) = 0.019
  Total: ~30.02

Post B:
  Absolute: 0.6 * 40 = 24
  Relative: 0.4 * (40 / 150) = 0.107
  Total: ~24.11
```
Post A still wins, but Post B is much more competitive!

### **Scenario 2: Breaking News**

**Post C (New, exploding):**
- 30 comments currently
- λ = 15 comments/min (very active!)
- dt = 3 minutes
- E = 45 expected comments

```
Post C:
  Absolute: 0.6 * 45 = 27
  Relative: 0.4 * (45 / 80) = 0.225
  Total: ~27.23
```

Despite having fewer total comments than Post A, Post C gets high priority due to:
- High absolute activity (λ=15)
- **Very high relative gain** (small size amplifies value)

---

## Tuning the System

### **Adjust `w_abs` vs `w_rel`:**

**More Absolute (w_abs=0.8, w_rel=0.2):**
- Strongly favors high-activity posts
- Mega-threads get most attention
- Good for: Capturing breaking news with massive engagement

**Balanced (w_abs=0.6, w_rel=0.4):** ← **Current**
- Balanced approach
- Large posts still prioritized, but smaller posts get fair shot
- Good for: General purpose scraping

**More Relative (w_abs=0.4, w_rel=0.6):**
- Favors smaller, growing posts
- More even distribution across posts
- Good for: Comprehensive coverage, avoiding mega-thread bias

**Pure Relative (w_abs=0.0, w_rel=1.0):**
- Only cares about relative value
- Small posts heavily favored
- Risk: Might miss major events in large threads

### **Adjust `c` (Baseline Constant):**

**Small c (c=10):**
- Strong diminishing returns even for small posts
- 100-comment post: rel = E/110 (small boost)
- 1000-comment post: rel = E/1010 (tiny)

**Medium c (c=50):** ← **Current**
- Moderate diminishing returns
- 100-comment post: rel = E/150 (good boost)
- 1000-comment post: rel = E/1050 (small)

**Large c (c=200):**
- Weak diminishing returns
- Only very small posts (<50) get significant boost
- Closer to pure absolute

---

## How It Affects Your Scraping

### **Before (Pure Absolute):**
```
Run 1: 1o62wt2 (1000 comments, very active) → Scraped
Run 2: 1o62wt2 (1020 comments) → Scraped again
Run 3: 1o62wt2 (1045 comments) → Scraped again
...
Small posts rarely checked
```

### **After (Relative Gain):**
```
Run 1: 1o62wt2 (1000 comments, very active) → Scraped
Run 2: 1o7amkl (50 comments, moderate activity) → Gets a turn!
Run 3: 1o62wt2 (1045 comments) → Back to big post
Run 4: 1o78a8b (80 comments, growing) → Smaller post gets attention
...
More balanced coverage
```

---

## Expected Benefits

1. **Better Coverage**: Smaller posts won't be ignored
2. **Fairer Allocation**: Resources distributed more evenly
3. **Breaking News Detection**: Small, exploding posts get caught early
4. **Natural Lifecycle**: As posts grow, they naturally get less priority
5. **Still Captures Big Events**: 60% absolute weight ensures major threads tracked

---

## Testing the New System

When you run your next collection, watch for:
- More even distribution of scrapes across posts
- Smaller posts getting more attention
- Large posts still tracked, but not dominating
- Overall better balance in the summary stats

You can always adjust `w_abs`, `w_rel`, and `c` based on what you observe!

