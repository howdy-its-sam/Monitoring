# Fix #16 Recovery Patch Plan
### Addressing the Deadlock from Predictive Deferral Overload

---

## 🚨 Summary of Failure

The Fix #16 predictive rate-limiting system successfully **prevented 429 errors**, but created a **throughput deadlock**:

- All posts were deferred simultaneously due to low available budget.
- The main loop had **no sleep or yield** between deferrals.
- As a result, the loop entered a **tight spin**, consuming CPU but never allowing Reddit’s API window to refill.
- Discovery and scraping stalled entirely after 5 minutes.

### Evidence from Logs

| Metric | Value | Meaning |
|--------|--------|----------|
| Deferral Rate | 99.8% | Nearly all posts deferred |
| Throughput | 0.0 RPS | No forward progress |
| 429 Errors | 0 | Predictive limiter worked |
| CPU Usage | High | Loop spinning without pause |

---

## 🧩 Root Cause

The reactive-to-predictive transition introduced a new choke point:  
when the budget was insufficient, *all posts were deferred*, but the loop immediately retried without yielding.

### Problem Flow

```text
→ Estimate cost
→ available_budget < estimated_cost → defer()
→ immediately re-enter main loop
→ defer() again → repeat indefinitely
```

---

## ✅ Goals of the Recovery Patch

1. Maintain **predictive safety** (no 429s).  
2. Restore **continuous scraping** with controlled yielding.  
3. Ensure the system self-stabilizes after deferrals.  
4. Add **observability** to detect future overloads.

---

## 🔧 Recommended Fixes

### **Fix 16A — Add Adaptive Cooldown**
Add a short cooldown when *no post qualifies* for scraping:

```python
if all_deferred:
    cooldown = min(10, 0.5 * (rate_limiter.window_seconds / 60))
    print(f"⏸️ Cooling down for {cooldown:.1f}s to allow refill")
    time.sleep(cooldown)
```

**Why:** Prevents infinite loop while giving Reddit’s window time to recover.

---

### **Fix 16B — Track Deferral Density**
Introduce a counter for consecutive deferrals to trigger forced cooldown:

```python
deferral_streak += 1
if deferral_streak > 50:
    print("⚠️ Excessive deferrals — forcing 10s wait")
    time.sleep(10)
    deferral_streak = 0
```

**Why:** Avoids CPU burn when the scheduler is fully starved.

---

### **Fix 16C — BudgetManager-Controlled Yielding**

Let the BudgetManager decide how long to wait dynamically:

```python
if budget_manager.should_defer(available_budget):
    yield_duration = budget_manager.get_deferral_threshold() / 10
    print(f"⏸️ Deferring for {yield_duration:.1f}s (adaptive)")
    time.sleep(yield_duration)
    continue
```

**Why:** Ties the sleep duration to real cost dynamics, adapting automatically to workload.

---

### **Fix 16D — Queue-Aware Idle Mode**

When 90%+ of posts are deferred, enter idle discovery mode instead of retrying:

```python
ready_ratio = ready_posts / max(1, total_tracked_posts)
if ready_ratio < 0.1:
    print("🕵️ Entering discovery-only mode for 30s...")
    perform_idle_discovery()
    time.sleep(30)
    continue
```

**Why:** Keeps system productive during global deferral conditions.

---

### **Fix 16E — Telemetry: Deferral Metrics**

Extend telemetry snapshot to include deferral metrics:

```python
@dataclass
class TelemetrySnapshot:
    ...
    deferral_rate: Optional[float] = None  # Deferred / total attempts per 60s
    deferral_streak: Optional[int] = None
```

Add alert logic:
```python
if telemetry.deferral_rate > 0.9 and uptime_minutes > 5:
    print("🚨 DEFERRAL OVERLOAD: No posts processed for >5 min")
```

**Why:** Early warning of system starvation.

---

## 🧠 Implementation Notes

- Integrate cooldown logic directly inside the main scraping loop in `unified_scraper.py`.
- Track deferral streaks as a local variable; reset whenever a scrape succeeds.
- Use telemetry deferral rate to auto-tune `yield_duration` over time (optional future optimization).
- Keep cooldown ≤10s to maintain responsiveness but prevent starvation.

---

## 🧪 Testing Plan

### 1. **15-Minute Diagnostic Test**

```bash
python3 unified_scraper.py 15 10.0 --no-bootstrap --dir=fix16_recovery_test
```
**Expect:**  
- Continuous scraping resumes (1-5 RPS).  
- Deferral rate stabilizes below 50%.  
- No 429s.  

### 2. **1-Hour Validation Test**

```bash
python3 unified_scraper.py 60 10.0 --no-bootstrap --dir=fix16_recovery_v2
```
**Expect:**  
- No more infinite deferral loops.  
- Gain oscillates 0.8–1.1 (healthy equilibrium).  
- Uptime ≥90%.

### 3. **10-Hour Stability Test**

**Goal:** Confirm adaptive deferral behavior under long-term API throttling.  
**Success Criteria:**  
- <10 forced cooldowns/hour.  
- No throughput collapse.  
- <5% idle time due to starvation.

---

## 📈 Expected Improvements

| Metric | Before | After | Change |
|--------|--------|--------|--------|
| Deferral Rate | 99.8% | <50% | ↓ |
| Throughput | 0 RPS | 2–5 RPS | ↑ |
| 429 Errors | 0 | 0 | ✅ |
| Uptime Efficiency | ~60% | ≥90% | ↑ |
| CPU Utilization | 90–100% | <50% | ↓ |

---

## 📚 Files to Modify

| File | Purpose |
|------|----------|
| `unified_scraper.py` | Add adaptive cooldowns, streak handling |
| `rate_limiter.py` | Expose window_seconds for cooldown computation |
| `telemetry.py` | Add deferral tracking fields |
| `adaptive_scheduler.py` | Provide ready/deferred ratio for telemetry |

---

## 🧩 Summary

This recovery patch transforms Fix #16 from a **predictive limiter** into a **self-stabilizing feedback system**.

✅ Prevents 429s  
✅ Keeps CPU idle under load  
✅ Maintains throughput  
✅ Detects starvation early

Once applied, the scraper will safely throttle under high demand while continuing to make forward progress without supervision.
