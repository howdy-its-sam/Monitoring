# Final Refinements and Implementation Notes
*Supplemental to Fix #16–18 Patch Plan*

---

## 🧭 Overview

This document summarizes final refinements, implementation details, and safety checks to accompany the **Predictive Rate Limiting & Budget Management (Fix #16–18)** rollout.  
These suggestions aim to enhance system stability, maintain long-run throughput, and prevent idle blocking.

---

## 1. Avoid Sleeping Inside the Main Loop

**Problem:** `time.sleep(60)` freezes telemetry and discovery.  
**Fix:** Replace sleeps with deferrals:

```python
scheduler.defer_post(post_id, delay=60)
continue
```

**Why:** This allows the scraper to continue working on other posts while deferring low-budget ones, maintaining queue activity and continuous telemetry.

---

## 2. BudgetManager Integration Consistency

Ensure `BudgetManager.record_cost()` is always called, even if a scrape is deferred:

```python
if actual_cost:
    budget_manager.record_cost(actual_cost)
else:
    budget_manager.record_cost(estimated_cost)
```

**Why:** Prevents adaptive thresholds from being biased toward low-cost scrapes only.

---

## 3. Stale History Reset for CostPredictor

The historical cost distribution should be refreshed periodically to prevent bias:

```python
if len(self.history) == self.history.maxlen:
    self.history.clear()
```

**Why:** Keeps prediction model adaptive during long runs (6h+).

---

## 4. Reserve Pool Decay Logic

Reintegrate unused reserve budget automatically after idle periods:

```python
if total_available == self.max_requests:
    self.reserve_budget = int(self.max_requests * 0.25)
```

**Why:** Prevents capacity loss if system stays idle after a high-cost burst.

---

## 5. Telemetry Write Buffering

Reduce I/O pressure by batching telemetry writes:

```python
if len(self.pending_records) >= 20:
    flush_to_disk()
```

Or rotate telemetry files hourly to prevent excessive disk writes.

**Why:** Prevents small write bottlenecks and improves performance stability.

---

## 6. Depth Mode Fallback

Add a safe fallback for missing depth data:

```python
depth_mode = depth_advisor.get_depth_mode(post_id) or "medium"
```

**Why:** Prevents `NoneType` prediction errors.

---

## 7. Budget Sync Between Limiter and Manager

Synchronize both systems periodically:

```python
budget_manager.p90_cost = max(
    budget_manager.p90_cost,
    rate_limiter.rolling_mean_cost()
)
```

**Why:** Keeps adaptive deferral thresholds consistent with actual limiter behavior.

---

## 8. Cross-Module Import Safety

To avoid circular imports, enforce the following structure:

```
core/
  ├─ scheduler/
  ├─ rate_limit/
  ├─ cost_model/
  ├─ telemetry/
  └─ unified_scraper.py
```

**Why:** Keeps modules clean and ensures import independence.

---

## 9. Absolute Cost Error in Telemetry

Change cost error metric to absolute value:

```python
error_pct = abs(actual - estimated) / max(1, actual) * 100
```

**Why:** Makes over- and under-estimates contribute equally to error statistics.

---

## 10. Deep Thread Edge Case Near Rate Window Reset

Ensure old timestamps are pruned correctly to prevent overshoot when large scrapes start near reset boundaries:

```python
if (now - self.timestamps[0]) > self.window_seconds:
    self.timestamps.popleft()
```

**Why:** Keeps the token bucket aligned with Reddit’s 10-minute window.

---

## 11. Validation Sequence Enhancements

**After P0 Test:**
- Verify cost ratio: `estimated_cost / actual_cost` between 0.7–1.3
- Ensure `budget_before_scrape` ≥ `estimated_cost + 20`

**After P1 Test:**
- Plot `p90_cost_threshold` vs time; should change smoothly.

**After P2 Test:**
- Check `reserve_used` ratio < 10% but > 0 when deep posts appear.

---

## 12. Optional Tools and Utilities

### a. Cost Trace Plotter

A lightweight analysis tool for cost prediction accuracy:

```bash
python3 analyze_costs.py --file cost_predictions.jsonl
```

### b. Telemetry Summary Endpoint

Add quick inspection method:

```python
telemetry.get_cost_summary()
```

### c. Dry-Run Mode

Allow scraping simulation without API calls to benchmark prediction models.

---

## ✅ Summary of Benefits

With these refinements applied, the system achieves:

| Aspect | Before | After |
|--------|---------|-------|
| Idle Blocking | Possible (sleep) | Eliminated (defer) |
| Budget Adaptation | Lagging | Real-Time |
| Disk I/O | High | Buffered |
| Telemetry Bias | Skewed | Balanced |
| Reserve Behavior | Static | Auto-Recovering |
| Cross-Imports | Risky | Modularized |

**Expected runtime outcome:** continuous operation for 24–48 hours at 5–8 scrapes/min sustained without manual intervention.

---

**Author’s Note:**  
These refinements complement Fix #16–18, ensuring adaptive and self-correcting long-term stability with minimal operational overhead.
