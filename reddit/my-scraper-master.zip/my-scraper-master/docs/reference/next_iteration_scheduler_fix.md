# Adaptive Scraper – Next Iteration Scheduler Fix

**Version:** v1.0  
**Date:** October 16, 2025  
**Objective:** Restore throughput equilibrium (~10 RPS) by repairing the temperature-to-interval mapping, decoupling gain logic, and preventing controller collapse — without sacrificing the excellent VPR and discovery performance achieved in the first test.

---

## 🧩 Summary of the Problem

| Symptom | Root Cause |
|----------|-------------|
| RPS pinned near 0 (0.037 RPS vs 10 target) | Scheduler intervals hours-long → no “ready” posts |
| Gain pinned at 0.5 | EMA decayed → controller starved |
| Queue full ( > 500 posts ) but idle | Interval mapping too conservative |
| Discovery & VPR excellent | Quality fine; scheduling logic broken |

### In short
> The scraper has great **taste** (high-value scrapes) but no **tempo** (almost never scrapes).

---

## ⚙️ Immediate Hotfixes

### 1. Clamp + Rescale the Interval Function
**File:** `adaptive_scheduler.py`

```python
MIN_INTERVAL = 30       # 30 s lower bound
MAX_INTERVAL = 1800     # 30 min upper bound
ALPHA        = 3.0      # curve strength

next_interval = base_interval * (1 + ALPHA * math.log1p(max(0.0, 1.0 - min(1.0, temperature))))
next_interval = max(MIN_INTERVAL, min(MAX_INTERVAL, next_interval))
```

**Effect:**  
Smooth, bounded intervals → no multi-hour cooldowns.

---

### 2. Aggressive Initial Intervals for New Posts

```python
if post.scrape_count == 0:
    return 60   # 1 minute
elif post.scrape_count == 1:
    return 180  # 3 minutes
```

Keeps early scrapes hot to bootstrap the activity estimate.

---

### 3. Decouple Readiness from Gain

**Before:**
```python
if post.next_scrape_time <= now and controller.gain > 0.7:
    ready.append(post)
```

**After:**
```python
ready = [p for p in queue if p.next_scrape_time <= now]
launch_cap = max(1, int(base_concurrency * max(0.5, controller.gain)))
to_launch  = ready[:launch_cap]
```

Gain now scales **how many** posts run, not **whether** they can.

---

### 4. EMA Floor to Prevent Collapse
**File:** `rate_controller.py`

```python
rate_ema = max(rate_ema * 0.95 + rps_instant * 0.05, 0.2 * target_rps)
controller_gain = max(0.5, min(1.5, rate_ema / target_rps))
```

Stops the feedback loop where low EMA ⇒ low gain ⇒ zero scrapes.

---

### 5. Heartbeat Scrape (Failsafe)

```python
if not ready_posts and queue:
    to_launch = [pick_least_recently_scraped(queue)]
```

Guarantees at least one scrape per loop to re-prime the system.

---

### 6. Interval Telemetry

Every 60 s record:

```python
interval_median_s
interval_p90_s
interval_max_s
soonest_next_scrape_delta_s
```

Healthy range after fix:
- median ≈ 60–300 s  
- p90 ≤ 900 s  
- max ≤ 1800 s  

---

## 🧮 Principled Mapping (Long-Term Replacement)

When ready for a smoother mathematical form:

```python
MIN_INTERVAL = 30
MAX_INTERVAL = 1800
BETA = 0.85
T = clamp(T, 0.0, 1.0)   # 0=cold, 1=hot

interval = (MIN_INTERVAL**BETA * (MAX_INTERVAL**(1 - BETA))) * (MAX_INTERVAL / MIN_INTERVAL) ** (1 - T)
interval = max(MIN_INTERVAL, min(MAX_INTERVAL, interval))
```

Optional activity correction:
```python
interval /= (1 + math.sqrt(lambda_hat))
```

---

## 🔎 Diagnostics to Add During Run

Print/log every 10 s:

```
queue_len, ready_count, launch_cap, rps_instant, rate_ema, gain
interval_median_s, interval_p90_s, interval_max_s, soonest_next_scrape_delta_s
```

and for top 10 upcoming posts:
```
(post_id, next_scrape_delta_s, scrape_count, temperature)
```

Indicators of success:
- ready_count > 0 most of the time  
- soonest_next_scrape_delta < 900 s  
- EMA > 2 within 10 min, stabilizes ~ 8–10 RPS

---

## ✅ Validation Targets (1-hour sanity run)

| Metric | Target | Expected After Fix |
|---------|---------|-------------------|
| RPS EMA | 8–10 | stabilizes near target |
| Gain | 0.8–1.2 | oscillates, not pinned |
| Median Interval | 60–300 s | bounded |
| Queue Churn | visible | healthy |
| Waste | < 20 % | maintained |
| VPR | ≥ 10 | maintained |

---

## 🛠 Optional Enhancements

1. **Dynamic Cooldown by ΔInfo**
   ```python
   next_interval *= 1 / math.sqrt(1 + post.delta_info)
   ```
2. **Batch Release:** every 5 min release 5 % of queue regardless of readiness.  
3. **Emergency Reheat:**  
   halve all intervals if gain < 0.6 for > 5 min.  
4. **Idle Utilization Monitor:**  
   trigger reallocation if idle > 80 % for > 10 min.

---

## 🧾 Implementation Checklist

| Step | Description | Status |
|------|--------------|--------|
| 1 | Replace interval function with bounded log curve | ⬜ |
| 2 | Add aggressive initial intervals | ⬜ |
| 3 | Decouple gain from readiness | ⬜ |
| 4 | Add EMA floor & gain clamp | ⬜ |
| 5 | Heartbeat scrape | ⬜ |
| 6 | Interval telemetry & diagnostics | ⬜ |

---

## 🧠 Why This Fix Matches Observed Behavior

- Discovery & VPR prove selection and value models are fine.  
- Queue freeze came from time-based throttling, not logic errors.  
- Bounded intervals + EMA floor restore self-correction behavior.  
- System will recover throughput while keeping precision.

---

**Next Run Recommendation:**  
Run 60–90 min with verbose telemetry before attempting another 4-hour equilibrium test.  
Expect RPS ≈ 5–10 within first 15 min and gain to oscillate smoothly instead of collapsing.

---

**Prepared by:** ChatGPT (GPT-5)  
**For:** Sam Williamson – Adaptive Scraper Project  
**Date:** October 16, 2025  
