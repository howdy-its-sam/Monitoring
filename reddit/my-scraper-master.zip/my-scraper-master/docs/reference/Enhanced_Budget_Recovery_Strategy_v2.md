# Enhanced Budget Recovery Strategy (Fix16+ Refinements)

## Overview

This plan addresses the **persistent deferral loop** issue seen after Fix16. It enhances the rate limiter, adds recovery modes, and introduces smarter cooldown and drift tracking mechanisms.

---

## 1. Strengthen Budget Floor Protection

### Problem
Rapid consecutive 60-second sleeps prevent full budget recovery.

### Solution
Implement streak-based deep sleep:

```python
if available_budget == 0:
    self.zero_budget_streak += 1
    if self.zero_budget_streak >= 3:
        print("💤 Hard budget starvation detected, full 3-min recovery sleep...")
        time.sleep(180)
        self.zero_budget_streak = 0
    else:
        time.sleep(60)
    continue
else:
    self.zero_budget_streak = 0
```

**Effect:** Prevents tight retry loops; allows meaningful refill periods.

---

## 2. Deferred-Recovery Mode

### Problem
When most posts defer simultaneously, the system keeps looping at full demand with no capacity.

### Solution
Enter a low-RPS recovery state when deferrals exceed 50%:

```python
if deferred_ratio > 0.5:
    gain *= 0.8
    target_rps = max(1.0, target_rps * 0.5)
    print(f"🪫 Recovery mode: {deferred_ratio:.0%} deferred, gain={gain:.2f}, RPS={target_rps}")
```

Exit when deferred < 30%.  
**Effect:** Stabilizes queue pressure and allows token replenishment.

---

## 3. Budget Drift Tracker

### Problem
Budget slowly declines across cycles, even when limiter appears stable.

### Solution
Track rolling average of budget delta per loop:

```python
self.budget_drift = ema(self.budget_drift, available_budget - last_budget)
if self.budget_drift < 0 and available_budget < 100:
    print("⚠️ Sustained negative drift, slowing scrape tempo 25%")
    self.target_rps *= 0.75
```

**Effect:** Detects “silent starvation” trends before a full collapse.

---

## 4. Pre-Flight Batch Validation

### Problem
Batches begin even when the current budget cannot afford them.

### Solution

```python
estimated_batch_cost = batch_size * avg_cost_per_post
if available_budget < estimated_batch_cost * 0.8:
    print(f"⏸️ Budget too low ({available_budget}) for batch (~{estimated_batch_cost}); delaying 45s")
    time.sleep(45)
    continue
```

**Effect:** Avoids immediate post-start deferrals.

---

## 5. Predictive Cooldown

### Problem
Sleep durations don’t account for true refill rate.

### Solution

```python
self.avg_sleep_refill = ema(self.avg_sleep_refill, tokens_gained / sleep_time)
predicted_sleep = (target_budget - available_budget) / max(self.avg_sleep_refill, 0.8)
time.sleep(clamp(predicted_sleep, 15, 180))
```

**Effect:** Adapts cooldown dynamically to actual observed refill rate.

---

## 6. Safety Guard in Rate Limiter

### Problem
Micro-scrapes trigger 429s when limiter reaches near-zero.

### Solution

```python
def ensure_min_budget(self, min_tokens=5):
    if self.available_budget() < min_tokens:
        print(f"🧯 Top-up: waiting until {min_tokens} tokens available...")
        while self.available_budget() < min_tokens:
            time.sleep(5)
```

**Effect:** Guarantees minimal buffer before any new request batch.

---

## Optional Enhancements

| Feature | Description | Benefit |
|----------|--------------|----------|
| **Dynamic RPS Scaling** | Adjust RPS using rolling 15-min success ratio | Tracks Reddit’s real API elasticity |
| **Subreddit Cost Estimator** | Average cost per subreddit/post | Better pre-scrape planning |
| **Periodic Health Snapshots** | Log budget, drift, deferral ratio every 10 min | Simplifies telemetry analysis |

---

# Validation Plan

### Phase 1 — Recovery Test (90 minutes)

**Goal:** Verify deep sleep and streak logic.  
**Success:** No deferral loops > 5 min when RPS = 0.

### Phase 2 — Drift Test (6 hours)

**Goal:** Confirm long-term budget stability.  
**Success:** Budget oscillates between 50–400; no starvation streaks > 15 min.

### Phase 3 — Endurance Test (12 hours)

**Goal:** Validate adaptive scaling and recovery modes.  
**Success:** RPS sustained > 4 for 90% of runtime; deferred ratio < 20% average.

---

# Expected Benefits

| Metric | Before | After | Target |
|--------|--------|--------|--------|
| 429 Errors | 32 | ≤5 | ✅ |
| Consume Failures | 58 | ≤10 | ✅ |
| Average RPS | 2.5 | 5–8 | ✅ |
| Uptime Efficiency | 70% | 95%+ | ✅ |

---

# Summary

By combining **deep-sleep recovery**, **adaptive throttling**, and **budget drift detection**, the scraper learns to self-stabilize under extreme queue pressure.  
These refinements ensure recovery from low-budget states without manual resets — enabling full autonomous operation during long tests.
