# 🧩 PATCH_NOTES.md
**Title:** Fix Idle Time, Throughput, and Allocation Drift  
**Scope:** Unified Scraper System  
**Date:** (insert current date)  
**Version:** v2.3  

---

## 📋 Overview

This patch addresses systemic under-utilization and throughput collapse caused by feedback coupling between instantaneous request rate (`RPS`) and dynamic coverage scaling.  
Observed problems included:
- Gain pinned at 0.5 for >30 min  
- RPS ≈ 0, utilization ≈ 0%  
- Long idle periods despite available request budget  
- “Excess bandwidth” alerts under full idleness  

---

## ⚙️ Root Causes

| # | Problem | Effect |
|---|----------|--------|
| 1 | **Allocator used instantaneous RPS** | Self-throttling; coverage collapsed during idle |
| 2 | **Discovery tied to coverage fraction** | Slow polling, stale post detection |
| 3 | **No opportunistic work when idle** | Idle gaps not converted to new discoveries |
| 4 | **Post discovery rate not used in scaling** | Budget mis-allocation between high-activity and low-activity subs |
| 5 | **Lack of telemetry on coverage drift** | No visibility into allocator performance |

---

## 🧠 Implementation Summary

### ✅ Goals
1. Normalize coverage against **target budget**, not instantaneous RPS.  
2. Weight allocations by **posting rate × cost**.  
3. Decouple discovery cadence from coverage fraction.  
4. Convert all idle time to **new discovery work**.  
5. Log granular coverage and utilization metrics for diagnostics.  

---

## 🧩 Code-Level Modifications

(Full file-by-file instructions from previous message go here — allocator, poller, unified_scraper, telemetry, etc.)

---

## 🧪 Testing & Validation

| Metric | Pre-Patch | Post-Patch (Target) |
|:--|--:|--:|
| Avg RPS | ~0 | 5–10 RPS |
| Gain | 0.5 (pinned) | 0.8–1.2 (stable) |
| Idle Time | > 80 % | < 10 % |
| Discovery Rate | Burst-only | Continuous |
| Waste Rate | 43 % | < 15 % |
| Utilization | 0 % | 60–90 % |
| Coverage Skew (|Fₜ−Fᵣ|) | > 0.5 | < 0.1 |
| Idle-Recovery Yield | — | > 70 % |

---

## 📊 Observability Targets

| Signal | Description | Healthy Range |
|:--|:--|:--|
| `F_realized / F_target` | Coverage accuracy | 0.9–1.1 |
| `Top-10 share` | % of API requests for top-rank subs | 50–70 % |
| `Deep work share` | % requests to deep scrapes | ≤ 20 % |
| `Idle discovery per min` | Conversions of idle time to discovery | ≥ 3–5 bursts/min |
| `Rate EMA` | Smoothed RPS signal | Tracks target within ±15 % |

---

## ✅ Outcome

The unified scraper will:
- Maintain **continuous throughput** near its request budget.  
- Keep the **global gain controller** active (not pinned).  
- Allocate API effort proportionally to **subreddit activity × priority**.  
- Automatically convert idle time into productive discovery.  
- Produce stable coverage metrics suitable for long-term adaptive tuning.
