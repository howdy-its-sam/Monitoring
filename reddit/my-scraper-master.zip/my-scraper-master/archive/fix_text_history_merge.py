#!/usr/bin/env python3
"""
Fixed Merge Script for text_history Tracking

The problem: Raw scrapes have text in text_history[0][0], not in 'body' field.
The existing merge logic looks for 'body', so it never detects text changes.

This script properly extracts text from text_history and accumulates changes.
"""

import json
from pathlib import Path
from collections import defaultdict
from typing import Dict, List, Any


def flatten_comments(comments: List[Dict]) -> Dict[str, Dict]:
    """Flatten nested comment tree into dict keyed by comment ID"""
    result = {}
    
    def traverse(comment_list):
        for comment in comment_list:
            comment_id = comment.get('id')
            if comment_id:
                result[comment_id] = comment
            
            # Recursively process replies
            if comment.get('replies'):
                traverse(comment['replies'])
    
    traverse(comments)
    return result


def rebuild_comment_tree(flat_dict: Dict[str, Dict], original_structure: List[Dict]) -> List[Dict]:
    """
    Rebuild comment tree maintaining original structure but with updated data.
    Uses original structure as template to preserve order and nesting.
    """
    def rebuild_node(original_comment):
        comment_id = original_comment.get('id')
        if not comment_id or comment_id not in flat_dict:
            return None
        
        # Get updated comment data
        updated = flat_dict[comment_id].copy()
        
        # Rebuild replies recursively
        if original_comment.get('replies'):
            updated['replies'] = []
            for original_reply in original_comment['replies']:
                rebuilt_reply = rebuild_node(original_reply)
                if rebuilt_reply:
                    updated['replies'].append(rebuilt_reply)
        else:
            updated['replies'] = []
        
        return updated
    
    result = []
    for original in original_structure:
        rebuilt = rebuild_node(original)
        if rebuilt:
            result.append(rebuilt)
    
    return result


def merge_temporal_scrapes_fixed(post_dir: Path) -> Dict[str, Any]:
    """
    Merge all temporal scrapes with PROPER text_history accumulation.
    
    Key fix: Extract text from text_history[0][0], not from 'body' field.
    """
    raw_scrapes_dir = post_dir / 'raw_scrapes'
    
    if not raw_scrapes_dir.exists():
        print(f"  No raw_scrapes directory found")
        return None
    
    scrape_files = sorted(raw_scrapes_dir.glob('scrape_*.json'))
    
    if not scrape_files:
        print(f"  No scrape files found")
        return None
    
    print(f"  Found {len(scrape_files)} scrape files to merge")
    
    # Track cumulative data for each comment
    comment_data = {}  # comment_id -> full comment dict (from first appearance)
    text_histories = defaultdict(list)  # comment_id -> [[text, ts], ...]
    score_histories = defaultdict(list)  # comment_id -> [[score, ts], ...]
    
    # Process scrapes chronologically
    for i, scrape_file in enumerate(scrape_files, 1):
        with open(scrape_file) as f:
            scrape = json.load(f)
        
        # Extract timestamp - try metadata first, then parse filename
        metadata = scrape.get('metadata', {})
        timestamp = metadata.get('scrape_timestamp', metadata.get('scraped_at', ''))
        
        if not timestamp and 'scrape_' in scrape_file.name:
            # Parse from filename: scrape_NNN_YYYYMMDD_HHMMSS.json
            parts = scrape_file.stem.split('_')
            if len(parts) >= 3:
                timestamp = f"{parts[2][:4]}-{parts[2][4:6]}-{parts[2][6:8]}T{parts[3][:2]}:{parts[3][2:4]}:{parts[3][4:6]}"
        
        # Flatten comment tree
        flat_comments = flatten_comments(scrape.get('comments', []))
        
        for comment_id, comment in flat_comments.items():
            # Initialize on first appearance
            if comment_id not in comment_data:
                # Store the full comment data (copy to avoid mutation)
                comment_data[comment_id] = comment.copy()
            
            # Extract current values from THIS scrape
            # KEY FIX: Text is in text_history[0][0], not 'body'
            text_hist = comment.get('text_history', [])
            current_text = text_hist[0][0] if text_hist and text_hist[0] else ''
            
            score_hist = comment.get('score_history', [])
            current_score = score_hist[0][0] if score_hist and score_hist[0] else 0
            
            # SCORE: Always append (we want full history)
            score_histories[comment_id].append([current_score, timestamp])
            
            # TEXT: Only append if changed
            last_text = text_histories[comment_id][-1][0] if text_histories[comment_id] else None
            if current_text != last_text:
                text_histories[comment_id].append([current_text, timestamp])
        
        if i % 10 == 0 or i == len(scrape_files):
            print(f"    Processed {i}/{len(scrape_files)} scrapes...")
    
    # Rebuild comment tree with accumulated histories
    for comment_id in comment_data:
        comment_data[comment_id]['text_history'] = text_histories[comment_id]
        comment_data[comment_id]['score_history'] = score_histories[comment_id]
        
        # Update current score to latest
        if score_histories[comment_id]:
            comment_data[comment_id]['score'] = score_histories[comment_id][-1][0]
    
    # Use the latest scrape's structure as template
    with open(scrape_files[-1]) as f:
        latest_scrape = json.load(f)
    
    # Reconstruct tree structure
    merged_tree = rebuild_comment_tree(comment_data, latest_scrape.get('comments', []))
    
    # Update metadata
    merged_metadata = latest_scrape.get('metadata', {}).copy()
    merged_metadata['merge_info'] = {
        'source_scrapes': len(scrape_files),
        'scrape_files': [f.name for f in scrape_files],
        'unique_comments': len(comment_data),
        'is_true_merge': True,
        'merge_fixed': True,
        'note': 'text_history properly accumulated from all temporal scrapes'
    }
    
    return {
        'comments': merged_tree,
        'metadata': merged_metadata
    }


def count_edits_in_merged(merged_data: Dict) -> int:
    """Count comments with multiple text_history entries"""
    count = 0
    
    def traverse(comments):
        nonlocal count
        for comment in comments:
            text_hist = comment.get('text_history', [])
            if len(text_hist) > 1:
                count += 1
            if comment.get('replies'):
                traverse(comment['replies'])
    
    traverse(merged_data.get('comments', []))
    return count


def main():
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python3 fix_text_history_merge.py <post_id_or_path>")
        print("Example: python3 fix_text_history_merge.py 1o9bh67")
        print("Or: python3 fix_text_history_merge.py fix16cdf_24h_endurance/1o9bh67/")
        sys.exit(1)
    
    post_path = sys.argv[1]
    
    # Handle both post_id and full path
    if '/' in post_path:
        post_dir = Path(post_path)
    else:
        post_dir = Path('fix16cdf_24h_endurance') / post_path
    
    if not post_dir.exists():
        print(f"Error: {post_dir} does not exist")
        sys.exit(1)
    
    print(f"Merging temporal scrapes for: {post_dir.name}")
    print("="*60)
    
    merged_data = merge_temporal_scrapes_fixed(post_dir)
    
    if not merged_data:
        print("Failed to merge data")
        sys.exit(1)
    
    # Count edits captured
    edit_count = count_edits_in_merged(merged_data)
    total_comments = merged_data['metadata']['merge_info']['unique_comments']
    
    print()
    print("="*60)
    print("MERGE COMPLETE")
    print("="*60)
    print(f"Total comments: {total_comments}")
    print(f"Comments with text edits: {edit_count}")
    print(f"Edit rate: {edit_count/total_comments*100 if total_comments > 0 else 0:.2f}%")
    
    # Save to test output
    output_file = f"test_merged_{post_dir.name}.json"
    with open(output_file, 'w') as f:
        json.dump(merged_data, f, indent=2)
    
    print(f"\nSaved to: {output_file}")
    
    # Show sample of edited comments
    if edit_count > 0:
        print("\nSample edited comments:")
        count = 0
        
        def find_edits(comments, depth=0):
            nonlocal count
            if count >= 3:
                return
            
            for comment in comments:
                if count >= 3:
                    return
                
                text_hist = comment.get('text_history', [])
                if len(text_hist) > 1:
                    count += 1
                    print(f"\n{count}. Comment {comment.get('id')} by {comment.get('author')}")
                    print(f"   Versions: {len(text_hist)}")
                    print(f"   First: '{text_hist[0][0][:60]}'")
                    print(f"   Last:  '{text_hist[-1][0][:60]}'")
                
                if comment.get('replies'):
                    find_edits(comment['replies'], depth+1)
        
        find_edits(merged_data.get('comments', []))


if __name__ == '__main__':
    main()

