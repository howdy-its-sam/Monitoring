# Fix #16 - Buffer Logic Correction

## Problem Identified

**Test**: 1-hour validation (started ~5:53 PM, stopped ~6:24 PM after 31 minutes)  
**Issue**: Infinite deferral loop - scraper refused to scrape even with sufficient budget

### Root Cause

**Original Logic** (BROKEN):
```python
if available_budget < estimated_cost + 20:
    defer()  # "need 2, have 20" → defers!
```

**Why it failed**:
- Estimated cost: 2 requests
- Buffer: +20 requests (fixed)
- Required: 2 + 20 = 22
- Available: 20
- Result: 20 < 22 → **DEFER** (even though 20 is 10x what we need!)

**Impact**:
- Scraper could only work when budget > 40
- During normal operation (budget 20-30), everything got deferred
- Log file: 1.2M lines, mostly deferral spam
- Waste rate: 53%
- Effective throughput: ~0 scrapes/min

### Example Deferrals from Log
```
⏸️  Insufficient budget: need ~2, have 20  ← 10x overhead!
⏸️  Insufficient budget: need ~5, have 20  ← 4x overhead!
⏸️  Insufficient budget: need ~3, have 20  ← 6.6x overhead!
```

## The Fix

**New Logic** (FIXED):
```python
required_budget = int(estimated_cost * 1.5)  # 50% safety margin
if available_budget < required_budget:
    defer()
```

**Why it works**:
- Estimated cost: 2 requests
- Buffer: × 1.5 (proportional)
- Required: 2 × 1.5 = 3
- Available: 20
- Result: 20 >= 3 → **PROCEED** ✅

### Buffer Scaling Examples

| Est. Cost | Old Buffer (Fixed +20) | Old Required | New Buffer (1.5x) | New Required |
|-----------|------------------------|--------------|-------------------|--------------|
| 2 | +20 | 22 | ×1.5 | 3 |
| 5 | +20 | 25 | ×1.5 | 8 |
| 10 | +20 | 30 | ×1.5 | 15 |
| 20 | +20 | 40 | ×1.5 | 30 |
| 50 | +20 | 70 | ×1.5 | 75 |
| 100 | +20 | 120 | ×1.5 | 150 |

**Key improvements**:
1. ✅ Small posts (2-10 reqs) now proceed with 20+ budget (vs blocked before)
2. ✅ Medium posts (20-50 reqs) have reasonable buffers
3. ✅ Large posts (100+ reqs) get MORE protection (150 vs 120)

## Code Changes

**File**: `unified_scraper.py`  
**Lines**: 428-431

```python
# OLD:
if available_budget < estimated_cost + 20:  # Too aggressive!
    print(f"⏸️  Insufficient budget: need ~{estimated_cost}, have {available_budget}")
    continue

# NEW:
required_budget = int(estimated_cost * 1.5)  # 50% safety margin
if available_budget < required_budget:
    print(f"⏸️  Insufficient budget: need ~{required_budget} (est={estimated_cost}), have {available_budget}")
    continue
```

## Expected Impact

**Before fix** (broken test):
- Throughput: ~0 scrapes/min (stuck in deferral loop)
- Budget usage: <20% (refused to use available budget)
- Deferrals: Thousands per minute

**After fix** (expected):
- Throughput: 4-6 scrapes/min
- Budget usage: 80-90% (efficient use)
- Deferrals: Only when truly needed (budget < 10)

## Next Steps

1. ✅ Fix applied
2. ⏳ Run new 1-hour validation test
3. ⏳ Verify no infinite deferrals
4. ⏳ Confirm 4-6 scrapes/min throughput
5. ⏳ Check for 429 errors (<5 target)

## Test Command

```bash
python3 -u unified_scraper.py 60 10.0 --no-bootstrap --dir=fix16_validation_v2
```

**Success Criteria**:
- ✅ No deferral loops
- ✅ Throughput: 4-6 scrapes/min
- ✅ 429 errors: <5 total
- ✅ Consume failures: <10 total
- ✅ Budget usage: 70-90%

