# Budget Recovery Strategy Comparison

Comparing `Enhanced_Budget_Recovery_Strategy_v2.md` (reference_books) vs `FIX16_FAILURE_ANALYSIS_V2.md` (our plan)

---

## Summary

**Verdict**: The reference doc has **excellent complementary insights** that go beyond our plan. About **50% overlap**, **50% valuable additions**.

### Key Additions Worth Implementing:
1. ✅ **Streak-based deep sleep** (better than our fixed 60s)
2. ✅ **Deferred-recovery mode** (missing from our plan)
3. ✅ **Budget drift tracker** (missing from our plan)
4. ✅ **Pre-flight batch validation** (better than our budget-aware sizing)
5. ✅ **Predictive cooldown** (more sophisticated than our adaptive cooldown)
6. ✅ **Rate limiter safety guard** (good defensive addition)

### Overlap (Already Planned):
- Budget floor protection (we have Fix 16D, theirs is more sophisticated)
- Adaptive cooldown (we have Fix 16F, theirs is predictive vs deficit-based)

---

## Detailed Comparison

### 1. Budget Floor Protection

**Our Plan (Fix 16D)**:
```python
if available_budget == 0:
    print("🛑 CRITICAL: Budget depleted, sleeping 60s...")
    time.sleep(60)  # Refill ~54 requests
    continue
```

**Reference Doc Enhancement**:
```python
if available_budget == 0:
    self.zero_budget_streak += 1
    if self.zero_budget_streak >= 3:
        print("💤 Hard budget starvation detected, full 3-min recovery sleep...")
        time.sleep(180)  # MUCH longer sleep after repeated failures
        self.zero_budget_streak = 0
    else:
        time.sleep(60)
    continue
```

**Analysis**:
- ✅ **BETTER** - Streak tracking prevents rapid retry loops
- ✅ **ADD THIS** - Our fixed 60s sleep could create tight loops if budget keeps hitting 0
- **Value**: HIGH (prevents the exact infinite loop we saw)

---

### 2. Deferred-Recovery Mode

**Our Plan**: ❌ **MISSING**

**Reference Doc**:
```python
if deferred_ratio > 0.5:
    gain *= 0.8
    target_rps = max(1.0, target_rps * 0.5)
    print(f"🪫 Recovery mode: {deferred_ratio:.0%} deferred, gain={gain:.2f}, RPS={target_rps}")
```

**Analysis**:
- ✅ **EXCELLENT ADDITION** - We don't have this concept
- **Problem it solves**: When 90% of posts defer (as we saw), system keeps trying full batches
- **Effect**: Reduces queue pressure, allows budget to recover
- **Value**: VERY HIGH (directly addresses our failure mode)

**How it helps our case**:
```
Current behavior (without this):
- 5 posts ready
- All 5 defer
- Next loop: Try 5 posts again → all defer
- Budget never recovers because we keep trying

With recovery mode:
- 5 posts ready
- All 5 defer (deferred_ratio = 1.0 > 0.5)
- Enter recovery: target_rps *= 0.5, gain *= 0.8
- Next loop: Try 2-3 posts instead of 5
- Budget has breathing room to refill
```

---

### 3. Budget Drift Tracker

**Our Plan**: ❌ **MISSING**

**Reference Doc**:
```python
self.budget_drift = ema(self.budget_drift, available_budget - last_budget)
if self.budget_drift < 0 and available_budget < 100:
    print("⚠️ Sustained negative drift, slowing scrape tempo 25%")
    self.target_rps *= 0.75
```

**Analysis**:
- ✅ **PROACTIVE vs REACTIVE** - Detects problem BEFORE budget hits 0
- **What it catches**: The gradual 6-hour decline we observed (540 → 0)
- **Value**: MEDIUM-HIGH (early warning system)

**Evidence from our logs**:
```
Hour 0: Budget ~540
Hour 2: Budget ~400 (drift = -70/hour)
Hour 4: Budget ~200 (drift = -100/hour) ← Would trigger warning here
Hour 6: Budget = 0 (too late!)
```

With drift tracking, would have detected negative trend at Hour 3-4 and slowed down, preventing the collapse.

---

### 4. Pre-Flight Batch Validation

**Our Plan (Fix 16E)**:
```python
max_affordable = available_budget // 10
batch_size = min(base_batch_size, max_affordable)
```

**Reference Doc**:
```python
estimated_batch_cost = batch_size * avg_cost_per_post
if available_budget < estimated_batch_cost * 0.8:
    print(f"⏸️ Budget too low for batch; delaying 45s")
    time.sleep(45)
    continue
```

**Analysis**:
- ✅ **COMPLEMENTARY** - Different approach, both valuable
- **Ours**: Proactively limits batch size
- **Theirs**: Skips batch entirely if can't afford it
- **Value**: MEDIUM (use both! Check before batch, then limit size)

**Combined approach**:
```python
# 1. Reference doc: Pre-flight check
estimated_batch_cost = batch_size * 10
if available_budget < estimated_batch_cost * 0.8:
    time.sleep(45)
    continue

# 2. Our approach: Limit batch size if tight
max_affordable = available_budget // 10
batch_size = min(batch_size, max_affordable)
```

---

### 5. Predictive Cooldown

**Our Plan (Fix 16F)**:
```python
needed_refill = max(0, safe_threshold - available_budget)
sleep_time = needed_refill / 0.9  # 0.9 req/sec refill rate
sleep_time = max(15, min(120, sleep_time))
```

**Reference Doc**:
```python
self.avg_sleep_refill = ema(self.avg_sleep_refill, tokens_gained / sleep_time)
predicted_sleep = (target_budget - available_budget) / max(self.avg_sleep_refill, 0.8)
time.sleep(clamp(predicted_sleep, 15, 180))
```

**Analysis**:
- ✅ **THEIRS IS BETTER** - Learns actual refill rate vs using fixed 0.9
- **Why**: Reddit's rate limit might not be exactly 0.9/sec, could vary
- **Value**: MEDIUM (refinement over our approach)

**Recommendation**: Use theirs, it's more adaptive

---

### 6. Rate Limiter Safety Guard

**Our Plan**: ❌ **MISSING**

**Reference Doc**:
```python
def ensure_min_budget(self, min_tokens=5):
    if self.available_budget() < min_tokens:
        while self.available_budget() < min_tokens:
            time.sleep(5)
```

**Analysis**:
- ✅ **DEFENSIVE PROGRAMMING** - Guarantees minimum buffer
- **Where to use**: Before every `consume()` call
- **Value**: LOW-MEDIUM (nice-to-have, prevents edge cases)

---

## Recommendations

### Tier 1: Must Implement (Directly Fix Our Failure)

1. ✅ **Streak-based deep sleep** (replaces our Fix 16D)
   - Prevents rapid retry loops when budget=0
   
2. ✅ **Deferred-recovery mode** (NEW)
   - Reduces batch pressure when deferrals spike
   - **This is the missing piece!**

3. ✅ **Budget drift tracker** (NEW)
   - Early warning system before collapse
   - Would have caught the 6-hour decline

### Tier 2: Strongly Recommended (Better Than Our Plan)

4. ✅ **Predictive cooldown** (replaces our Fix 16F)
   - Learns actual refill rate vs assuming 0.9/sec

5. ✅ **Pre-flight batch validation** (complements our Fix 16E)
   - Check before batch, then limit size

### Tier 3: Nice-to-Have (Defensive)

6. ⏳ **Rate limiter safety guard**
   - Prevents micro-scrape 429s
   
7. ⏳ **Optional enhancements** (Dynamic RPS scaling, Subreddit cost estimator)
   - Future optimizations, not critical for stability

---

## Revised Implementation Plan

### Phase 1: Core Fixes (Fixes 16C-16F + Reference Additions)

**From Our Plan**:
- ✅ Fix 16C: Adaptive safety margin (`max(est*1.15, est+5)`)

**From Reference Doc** (Tier 1):
- ✅ Streak-based deep sleep (enhanced Fix 16D)
- ✅ Deferred-recovery mode (NEW)
- ✅ Budget drift tracker (NEW)

**From Reference Doc** (Tier 2):
- ✅ Predictive cooldown (enhanced Fix 16F)
- ✅ Pre-flight batch validation (enhanced Fix 16E)

### Phase 2: Defensive Enhancements (Optional)

- ⏳ Rate limiter safety guard
- ⏳ Dynamic RPS scaling
- ⏳ Subreddit cost estimator

---

## Expected Impact

### Without Reference Doc Additions (Our Original Plan):

| Issue | Our Fix | Risk |
|-------|---------|------|
| Small scrapes | Fix 16C (margin+5) | ✅ Fixed |
| Budget=0 loop | Fix 16D (sleep 60s) | ⚠️ Might still loop |
| Batch pressure | Fix 16E (limit size) | ⚠️ Partial fix |
| Slow recovery | Fix 16F (deficit calc) | ⚠️ Fixed 0.9/sec might be wrong |

**Estimated success**: 60-70% (would help, but might still have loops)

### With Reference Doc Additions (Combined Plan):

| Issue | Combined Fix | Risk |
|-------|-------------|------|
| Small scrapes | Fix 16C (margin+5) | ✅ Fixed |
| Budget=0 loop | Streak sleep (60s → 180s) | ✅ Fixed |
| High deferrals | Recovery mode (RPS *= 0.5) | ✅ Fixed |
| Gradual decline | Drift tracker | ✅ Early warning |
| Batch pressure | Pre-flight + limit size | ✅ Fixed |
| Slow recovery | Predictive cooldown (learned) | ✅ Fixed |

**Estimated success**: 90-95% (comprehensive solution)

---

## Files to Modify (Updated)

### 1. `unified_scraper.py`

**New additions**:
- Line ~100: Add instance variables:
  ```python
  self.zero_budget_streak = 0
  self.last_budget = 540
  self.budget_drift = 0
  self.deferred_count = 0
  self.attempted_count = 0
  ```

- Line ~280: Budget floor with streak logic
- Line ~285: Budget drift tracking
- Line ~290: Deferred-recovery mode check
- Line ~320: Pre-flight batch validation
- Line ~430: Adaptive safety margin (Fix 16C)
- Line ~500: Predictive cooldown

### 2. `rate_limiter.py`

**New additions**:
- `ensure_min_budget()` method
- Track `avg_sleep_refill` for predictive cooldown

### 3. `telemetry.py`

**New additions**:
- Log drift, deferral ratio, recovery mode activations
- Track zero_budget_streak events

---

## Unnecessary Features

**None!** All features in the reference doc add value:

1. ✅ Streak sleep: Prevents rapid loops
2. ✅ Recovery mode: Reduces queue pressure
3. ✅ Drift tracker: Early warning
4. ✅ Pre-flight validation: Prevents wasteful batches
5. ✅ Predictive cooldown: Adaptive vs fixed rate
6. ✅ Safety guard: Defensive programming

Even the "optional enhancements" are valuable for future optimization.

---

## Conclusion

**The reference doc is EXCELLENT** - it has insights we missed:

### What We Had (Original):
- ✅ Adaptive safety margin
- ✅ Budget floor protection (basic)
- ✅ Batch size limiting
- ✅ Adaptive cooldown (deficit-based)

### What We Were Missing:
- ❌ Streak tracking (rapid loop prevention)
- ❌ Deferred-recovery mode (queue pressure relief)
- ❌ Budget drift detection (early warning)
- ❌ Pre-flight batch validation
- ❌ Predictive cooldown (learned refill rate)

**Recommendation**: **Implement ALL Tier 1 + Tier 2 features** from the reference doc. They directly address our failure modes and are more sophisticated than our original plan.

The combined approach (our Fixes 16C-16F + reference doc additions) should achieve **90-95% success rate** vs our original 60-70%.

---

## Next Steps

1. ✅ Implement Fix 16C (adaptive safety margin)
2. ✅ Implement streak-based deep sleep
3. ✅ Implement deferred-recovery mode
4. ✅ Implement budget drift tracker
5. ✅ Implement predictive cooldown
6. ✅ Implement pre-flight batch validation
7. ⏳ Run 2-hour validation test
8. ⏳ Run 12-hour endurance test

**Estimated implementation time**: 3-4 hours (vs 2 hours for original plan)  
**Expected payoff**: Near-bulletproof budget management

