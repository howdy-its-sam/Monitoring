# 10-Hour Stability Test Plan

**Start Time**: October 16, 2025 @ 10:42 PM MDT  
**Expected End**: October 17, 2025 @ 8:42 AM MDT  
**Duration**: 600 minutes (10 hours)  
**Target RPS**: 10.0  
**Test Directory**: `stability_test_10h/`

---

## 🎯 Test Objectives

### Primary Goals
1. ✅ Validate **zero 429 errors** over extended period
2. ✅ Confirm **request-based rate limiting** works long-term
3. ✅ Verify **staggered rescheduling** maintains continuous flow
4. ✅ Assess **diurnal stability** (nighttime activity patterns)

### Secondary Goals
5. ✅ Measure **sustained throughput** over 10 hours
6. ✅ Validate **comprehensive coverage** maintained
7. ✅ Check **controller stability** (gain oscillation)
8. ✅ Monitor **budget utilization** patterns

---

## 📊 Expected Results

Based on v2 15-minute test:

| Metric | Expected (10h) | Basis |
|--------|---------------|-------|
| **Total Scrapes** | 6,000-7,200 | 11-12 scrapes/min × 600 min |
| **Total API Requests** | 40,000-50,000 | 5.5 reqs/scrape avg |
| **Avg Throughput** | 10-12 scrapes/min | 0.17-0.2 RPS |
| **Peak Throughput** | 50-60 scrapes/min | 0.8-1.0 RPS bursts |
| **429 Errors** | 0 | Rate limiter prevents |
| **Low Budget Deferrals** | 200-300 | ~30 per hour |
| **Posts Tracked** | 1,500-2,000 | Continuous discovery |

---

## 📅 Monitoring Checkpoints

### Checkpoint Schedule

**30-Minute Check** (11:12 PM):
- Verify initialization successful
- Check early scrape rate
- Confirm no 429 errors

**1-Hour Check** (11:42 PM):
- Validate sustained throughput
- Check budget patterns
- Verify rate limiter working

**3-Hour Check** (1:42 AM):
- Mid-test assessment
- Nighttime activity analysis
- Controller stability check

**6-Hour Check** (4:42 AM):
- Overnight stability validation
- Budget utilization review
- Throughput consistency check

**9-Hour Check** (7:42 AM):
- Pre-completion assessment
- Final stability confirmation
- Prepare for analysis

**Completion** (8:42 AM):
- Full analysis and report
- Compare to all previous tests
- Production readiness assessment

---

## ✅ Success Criteria

| Criterion | Target | Critical? |
|-----------|--------|-----------|
| **Zero 429 errors** | 0 throughout | YES |
| **Sustained scrapes/min** | 10-15 avg | YES |
| **Budget never depleted** | >0 always | YES |
| **No crashes** | Runs full 10h | YES |
| **Gain oscillating** | 0.4-1.5 range | NO |
| **VPR maintained** | ≥5 avg | NO |
| **Coverage quality** | 85%+ on deep | NO |

---

## 🔍 Key Metrics to Monitor

### Throughput Metrics
- Scrapes per hour (should be ~600-720)
- API requests per hour (should be ~4,000-5,000)
- Burst instant RPS (expect 2-4 RPS peaks)
- Sustained average RPS (expect 0.15-0.25)

### Rate Limiter Metrics
- Budget utilization (should oscillate 50-400)
- Proactive deferrals (expect ~30/hour)
- Low budget frequency (should decrease after hour 2)
- Request tracking accuracy (compare to actual usage)

### Controller Metrics
- Gain stability (should oscillate, not pin)
- EMA convergence (should stabilize around 2-3 RPS)
- Utilization percentage (20-30% expected)

### Quality Metrics
- Average ΔInfo per scrape (10-25 expected)
- Waste rate (should drop below 40% after hour 2)
- Coverage on deep posts (85%+ maintained)
- Depth distribution (70-80% medium expected)

---

## 🚨 Alert Conditions

Monitor for these issues:

| Alert | Condition | Action |
|-------|-----------|--------|
| **429 Error** | Any occurrence | CRITICAL - investigate immediately |
| **Crash/Stop** | Process dies | CRITICAL - check logs and restart |
| **Budget Depletion** | <0 for >5 min | WARNING - rate limiter may be broken |
| **Throughput Collapse** | <5 scrapes/min for >30 min | WARNING - check queue starvation |
| **Excessive Deferrals** | >60/hour | INFO - consider lowering threshold |

---

## 📈 Analysis Plan

### Post-Test Analysis

**1. Rate Limit Compliance**:
```bash
# Check for any 429 errors
grep -c "429" stability_test_10h.log

# Count proactive deferrals
grep -c "⏸️  Low budget" stability_test_10h.log

# Analyze budget patterns
cat stability_test_10h/telemetry_snapshots.jsonl | jq '.available_tokens'
```

**2. Throughput Analysis**:
```bash
# Scrapes per hour
cat stability_test_10h/request_trace.jsonl | jq -s 'group_by(.timestamp[:13]) | map({hour: .[0].timestamp[11:13], scrapes: length, requests: (map(.requests_used) | add)})'

# Peak performance
cat stability_test_10h/request_trace.jsonl | jq -s 'group_by(.timestamp[:16]) | map({time: .[0].timestamp[11:16], scrapes: length}) | max_by(.scrapes)'
```

**3. Quality Metrics**:
```bash
# Average ΔInfo and efficiency
cat stability_test_10h/request_trace.jsonl | jq -s '{avg_delta_info: (map(.delta_info) | add / length), avg_efficiency: (map(.efficiency) | add / length)}'

# Deep post analysis
cat stability_test_10h/request_trace.jsonl | jq -s 'map(select(.requests_used > 50)) | {count: length, total_reqs: (map(.requests_used) | add)}'
```

---

## 📋 Expected Patterns

### Hour-by-Hour Expectations

**Hours 0-2 (10:42 PM - 12:42 AM)**:
- High activity (evening Reddit traffic)
- Frequent deferrals (learning budget patterns)
- Many new posts discovered
- Gain oscillating widely

**Hours 2-6 (12:42 AM - 4:42 AM)**:
- Reduced activity (overnight lull)
- Fewer deferrals (lower post rate)
- Steady scraping of existing posts
- Gain stabilizing

**Hours 6-10 (4:42 AM - 8:42 AM)**:
- Increasing activity (morning traffic)
- More deferrals (new posts arriving)
- Controller adapting to load change
- Gain responding to increased temperature

---

## 🎓 What This Test Validates

### Technical Validation
- ✅ Request-based rate limiting over long duration
- ✅ Staggered rescheduling prevents queue starvation
- ✅ Batch processing sustains throughput
- ✅ System handles diurnal activity variations

### Operational Validation
- ✅ No memory leaks over 10 hours
- ✅ No file descriptor exhaustion
- ✅ Telemetry logging doesn't overflow
- ✅ State persistence works correctly

### Compliance Validation
- ✅ Reddit API limits respected consistently
- ✅ No forced backoffs from violations
- ✅ Budget management sustainable
- ✅ Graceful handling of expensive posts

---

## 🚀 Post-Test Actions

### If Test Succeeds (All criteria met):
1. Mark as **production-ready** for 10 RPS target
2. Create comprehensive final report
3. Document all fixes and learnings
4. Consider 24-hour test for full diurnal cycle

### If Minor Issues (1-2 criteria missed):
1. Analyze specific failure points
2. Implement targeted fixes
3. Run 2-hour focused retest
4. Then retry 10-hour test

### If Major Issues (3+ criteria missed):
1. Full diagnostic review
2. Identify systemic problems
3. Return to shorter tests
4. Iterate on fixes

---

## 📝 Test Configuration

```python
Duration: 600 minutes (10 hours)
Target RPS: 10.0
Bootstrap: False (starting fresh)
Directory: stability_test_10h/

Fixes Active:
- Fix #12: Staggered rescheduling (±15%)
- Fix #11: Enhanced batch scaling (10-100 range)
- Fix #13: Rate limiter (540 req/10min)
- Fix #14: Enhanced telemetry
- Fix #15: Request-based rate limiting

Rate Limiter:
- Max requests: 540 per 10 minutes
- Budget threshold: <50 triggers 60s deferral
- Tracking: Actual API requests (not scrapes)

Scheduler:
- Min interval: 30 seconds
- Max interval: 30 minutes
- Stagger: ±15% randomization
```

---

## 🎯 Success Definition

This test is **successful** if:

1. ✅ Runs full 10 hours without crashing
2. ✅ Zero 429 rate limit errors
3. ✅ Achieves 6,000+ total scrapes
4. ✅ Maintains 10-15 scrapes/min average
5. ✅ Budget never depletes completely
6. ✅ Quality metrics remain strong (VPR ≥5)

**If all 6 criteria met** → System is **production-ready** for continuous operation at current configuration.

---

**Test Started**: October 16, 2025 @ 22:42 MDT  
**Monitoring**: Automated checkpoints at 30min, 1h, 3h, 6h, 9h  
**Status**: 🏃 RUNNING

