# Score-Based Pruning Analysis: Complete Results

## Executive Summary

Analyzed **657,747 comments** across **4,973 posts** from all historical test data to evaluate the potential throughput gains from pruning low-score comment chains.

**Bottom Line**: Score-based pruning provides **modest gains (0.4%-1.9%)**, not the dramatic 75% improvement initially hypothesized.

---

## Methodology

### Data Analyzed
- **Total comments**: 657,747
- **Total posts**: 4,973  
- **Average comments/post**: 132.3
- **Data sources**: 24h test, 16h test, 12h test, 2h test, validation runs

### Pruning Strategies Tested

For each strategy, we simulated stopping traversal when N consecutive **parent→child** comments in a chain all have scores ≤ threshold:

1. **2 consecutive score=1** (depths: any, ≥3, ≥4, ≥5)
2. **2 consecutive score≤2** (depths: any, ≥3, ≥4, ≥5)  
3. **2 consecutive score≤3** (depths: any, ≥4, ≥5)
4. **3 consecutive score=1** (depths: ≥4, ≥5)
5. **3 consecutive score≤2** (depths: ≥4, ≥5)

### Calculation Method

**Requests Saved** = Total descendants that wouldn't be fetched if pruning triggered  
**Throughput Gain** = `1 / (1 - requests_saved%)` - 1

---

## Key Findings

### Top Strategies by Requests Saved

| Strategy | Requests Saved | % of Total | Throughput Gain | 24h Projection Gain |
|----------|---------------|------------|----------------|-------------------|
| **2 consecutive score≤3 (any depth)** | **39,746** | **6.04%** | **+6.4%** | **+270 scrapes** |
| 2 consecutive score≤2 (any depth) | 28,415 | 4.32% | +4.5% | +190 scrapes |
| 2 consecutive score=1 (any depth) | 15,956 | 2.43% | +2.5% | +105 scrapes |
| 2 consecutive score≤2 (depth ≥3) | 14,171 | 2.15% | +2.2% | +92 scrapes |
| **2 consecutive score≤3 (depth ≥4)** | **11,953** | **1.82%** | **+1.9%** | **+77 scrapes** |

### Depth Distribution of Pruning Events

Where do pruning opportunities occur?

**2 consecutive score=1 (depth ≥4)** (6,222 events):
- Depth 4: **63.3%** of events
- Depth 5: 17.3%
- Depth 6: 9.4%
- Depth 7+: 10.0%

**Insight**: Most pruning happens at depth 4-5, where conversations naturally peter out.

### Average Descendants Pruned Per Event

- **All strategies**: 0.6-1.0 descendants per pruning event
- **Why so low?** Most low-score comment chains are **leaf nodes** or near-leaves with few/no children

---

## Throughput Impact Analysis

### Current Baseline (24h test)
- **Throughput**: 2.90 scrapes/min
- **24h projection**: 4,173 scrapes

### Best Conservative Strategy
**2 consecutive score=1 (depth ≥4)**
- **Requests saved**: 4,908 (0.75%)
- **New throughput**: 2.92 scrapes/min (+0.02/min, +0.8%)
- **24h projection**: 4,204 scrapes (+31)
- **Data loss**: 0.75% of comments

### Best Aggressive Strategy  
**2 consecutive score≤3 (any depth)**
- **Requests saved**: 39,746 (6.04%)
- **New throughput**: 3.09 scrapes/min (+0.19/min, +6.4%)
- **24h projection**: 4,443 scrapes (+270)
- **Data loss**: 6.04% of comments

---

## Why Not 75%?

The original hypothesis of 75% throughput gains appears to be **incorrect** for several reasons:

### 1. **High-Value Comments Have High Scores**
The most interesting discussions (2750 score, 1099 score, etc.) would **never** be pruned by score-based rules.

### 2. **Low-Score Chains Are Already Short**
Comments with score=1 typically have:
- 0-1 descendants on average
- Few deep reply chains
- Limited exponential growth

### 3. **Most Comments Aren't in Chains**
Looking at the data:
- 23,282 pruning events for "2× score=1"
- Only 15,956 comments would be saved
- Average: **0.7 descendants per prune**

This means **most low-score comments are leaves** (no children).

### 4. **Depth Distribution**
60% of pruning events happen at **depth 1-2**, where:
- There's less exponential growth potential
- Comments are still visible/relevant
- Pruning would lose valuable context

---

## Recommendations

### 🎯 **Recommended Strategy** (if implementing)

**2 consecutive score=1 (depth ≥5)**
- **Gain**: +0.8% throughput (+34 scrapes/24h)
- **Data loss**: Only 0.42% of comments
- **Risk**: Minimal - only prunes deep, low-engagement threads

**Implementation**:
```python
def should_prune_comment(comment, parent_comment):
    if comment.depth < 5:
        return False  # Don't prune shallow comments
    
    if parent_comment.score <= 1 and comment.score <= 1:
        return True  # Prune 1→1 chains at depth ≥5
    
    return False
```

### ⚠️ **NOT Recommended**

**Any "any depth" strategy** - Would prune at depths 1-2 where:
- 60% of pruning events occur
- Context is still valuable
- Risk of missing interesting tangents

### 💡 **Alternative Optimization Strategies**

If you want **bigger throughput gains**, consider:

1. **Depth Limits** (not score-based):
   - Cap traversal at depth 8-10 (regardless of score)
   - Would save more than score-based (exponential growth)
   
2. **Reply Count Limits**:
   - Skip fetching "more" objects for comments with <5 children
   - Targets the long tail more effectively

3. **Subreddit-Specific Rules**:
   - Apply aggressive pruning to low-value subreddits
   - Preserve deep scraping for high-value communities

---

## Data Quality Impact

### What You'd Lose (Best Conservative Strategy)

**2 consecutive score=1 (depth ≥5)**:
- **0.42%** of total comments (2,787 comments)
- **3,788 pruning events** across 4,973 posts
- **76% occur at depths 5-6** (very deep threads)

**Example of what gets pruned**:
```
Comment (score=15, depth=4)
  └─ Reply (score=1, depth=5) ← Still fetched
      └─ Reply (score=1, depth=6) ← PRUNED HERE
          └─ Reply (score=1, depth=7) ← Not fetched
```

**What you keep**:
- All high-score discussions
- All shallow threads (depth <5)
- Most valuable context

---

## Conclusion

**Score-based pruning provides marginal gains (0.4%-1.9%)**, not transformative improvements.

### Action Items

1. **✅ Keep current approach** - 6% data loss for 6% gain isn't worth it
2. **❌ Don't implement score-based pruning** unless:
   - You're storage-constrained
   - 0.8% gain is meaningful for your use case
3. **💡 Focus on other optimizations** if you want big throughput gains:
   - Fix #16 budget management (already implemented, working well!)
   - Depth limits
   - Subreddit targeting

### Files Generated

- **`consecutive_score_pruning_analysis.json`** - Full results dataset
- **`pruning_analysis_results_v2.txt`** - Console output
- **`analyze_consecutive_score_pruning.py`** - Analysis script (reusable)

---

## Appendix: Full Results Table

| Strategy | Requests Saved | % Saved | Pruning Events | Avg Pruned/Event | Throughput Gain |
|----------|---------------|---------|----------------|------------------|-----------------|
| 2× score≤3 (any) | 39,746 | 6.04% | 65,681 | 0.6 | +6.4% |
| 2× score≤2 (any) | 28,415 | 4.32% | 45,097 | 0.6 | +4.5% |
| 2× score=1 (any) | 15,956 | 2.43% | 23,282 | 0.7 | +2.5% |
| 2× score≤2 (≥3) | 14,171 | 2.15% | 15,886 | 0.9 | +2.2% |
| 2× score≤3 (≥4) | 11,953 | 1.82% | 12,227 | 1.0 | +1.9% |
| 2× score≤2 (≥4) | 9,373 | 1.43% | 10,164 | 0.9 | +1.5% |
| 2× score=1 (≥3) | 7,890 | 1.20% | 9,244 | 0.9 | +1.2% |
| 2× score≤3 (≥5) | 6,932 | 1.05% | 7,492 | 0.9 | +1.1% |
| 3× score≤2 (≥4) | 6,170 | 0.94% | 6,597 | 0.9 | +0.9% |
| 2× score≤2 (≥5) | 5,335 | 0.81% | 6,240 | 0.9 | +0.8% |
| 2× score=1 (≥4) | 4,908 | 0.75% | 6,222 | 0.8 | +0.8% |
| 3× score≤2 (≥5) | 3,988 | 0.61% | 4,069 | 1.0 | +0.6% |
| 3× score=1 (≥4) | 2,924 | 0.44% | 3,223 | 0.9 | +0.5% |
| 2× score=1 (≥5) | 2,787 | 0.42% | 3,788 | 0.7 | +0.4% |
| 3× score=1 (≥5) | 1,905 | 0.29% | 2,038 | 0.9 | +0.3% |

---

**Analysis Date**: October 18, 2025  
**Analyzer**: `analyze_consecutive_score_pruning.py`  
**Dataset**: 7,903 JSON files (24h + 16h + 12h + validation tests)

