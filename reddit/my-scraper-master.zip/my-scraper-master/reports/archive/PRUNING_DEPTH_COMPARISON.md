# Score Pruning: Depth Threshold Comparison

## Real Data Analysis (315 posts total)

Using `analyze_one_chains.py` on actual scraped Reddit data.

## Key Findings

### Depth Distribution of 1→1 Chains

| Depth | Occurrences | Percentage | Cumulative |
|-------|-------------|------------|------------|
| 2 | 74 | **53.6%** | 53.6% |
| 3 | 40 | **29.0%** | 82.6% |
| 4 | 13 | 9.4% | 92.0% |
| 5 | 4 | 2.9% | 94.9% |
| 6 | 5 | 3.6% | 98.5% |
| 8+ | 2 | 1.5% | 100.0% |

### Descendants Distribution

- **Median descendants**: 0 (most 1→1 chains are leaf nodes!)
- **Mean descendants**: 0.73
- **75th percentile**: 1 descendant
- **Max observed**: 10 descendants
- **High-impact (>5 descendants)**: Only 4 occurrences (2.9%)

## Variant Comparison

### Variant A: `depth >= 4`

**Coverage**:
- Catches: 13 + 4 + 5 + 2 = **24 occurrences** (17.4%)
- Misses: **114 occurrences** (82.6%) at depths 2-3

**Savings**:
- Minimal - misses most opportunities
- **NOT RECOMMENDED**

### Variant B: `depth >= 3`

**Coverage**:
- Catches: 40 + 13 + 4 + 5 + 2 = **64 occurrences** (46.4%)
- Misses: **74 occurrences** (53.6%) at depth 2

**Savings**:
- Moderate - catches about half
- Conservative (preserves depth-2 threads)

**Tradeoff**:
- ✅ Safe: Doesn't touch early replies
- ❌ Misses: Over half the opportunities

### Variant C: `depth >= 2` (RECOMMENDED)

**Coverage**:
- Catches: **138 occurrences** (100%)
- Misses: 0 occurrences

**Savings**:
- Maximum - catches all opportunities
- **101 comments pruned** from 79 posts
- Plus "more" expansion savings (unmeasured but significant)

**Tradeoff**:
- ✅ Maximum efficiency
- ⚠️  Prunes at depth 2 (early), but only when BOTH parent AND child = 1 (low engagement)

## The "More" Object Factor

### Why Low Descendants != Low Savings

**The script counts fetched descendants**, but the real savings is from **not fetching "more" objects**.

Example from log:
```
Progress: 1776 comments, 181 more objects remaining
⚠️  Stopping due to max request limit (200)
```

When we encounter 1→1 at depth 3, we might not have fetched the descendants yet (they're in a "more" object). The script shows 0 descendants, but reality:
- **Script sees**: 0 descendants (not fetched)
- **Reality**: "more" object with 50-200 comments underneath
- **Requests saved**: 5-20 (from not expanding "more")

## Adjusted Savings Estimate

### Conservative Estimate

**From script**: 101 pruned descendants  
**Assumption**: 20% of 1→1 occurrences have unexpanded "more" objects  
**Calculation**:
- 138 occurrences × 20% = 27 with "more"
- Each "more" saves ~10 requests average
- **Additional savings**: 270 requests

**Total savings**: 101 comments + 270 requests = **~370 request savings** in 15 minutes

**With 186 scrapes using ~1100 requests**:
- Savings: 370 / 1100 = 33.6%
- New budget: 730 requests available
- Additional scrapes: 730 / 6 avg = **~122 more scrapes**
- **New throughput**: (186 + 122) / 15 = **20.5 scrapes/min** (+65%)

### Optimistic Estimate

If 40% of 1→1 chains have "more" objects with 15 avg requests:
- 138 × 40% = 55 with "more"
- 55 × 15 = 825 requests saved
- Additional scrapes: 825 / 6 = **~138 more scrapes**
- **New throughput**: (186 + 138) / 15 = **21.6 scrapes/min** (+74%)

## Recommendation Matrix

| Depth Threshold | Opportunities Caught | Est. Throughput Gain | Risk Level | Recommended? |
|-----------------|---------------------|----------------------|------------|--------------|
| >= 5 | 8% | +5-10% | Very low | ❌ Too conservative |
| >= 4 | 17% | +10-20% | Low | ⚠️  Misses too much |
| **>= 3** | **46%** | **+30-40%** | Low | ✅ **Safe choice** |
| **>= 2** | **100%** | **+50-75%** | Medium | ✅ **Best ROI** |

## Final Recommendation

### Implement: `depth >= 2` with strict score=1 rule

**Rationale**:
1. **Data-driven**: Median first occurrence is depth 2-3
2. **Maximum coverage**: Catches 100% of dead threads
3. **Low risk**: Requires BOTH parent=1 AND child=1 (very specific signal)
4. **High reward**: +50-75% throughput improvement

**Rule**:
```python
if depth >= 2 and parent_score == 1 and current_score == 1:
    # Skip expanding "more" objects under this comment
    continue
```

**Expected results in 16h test**:
- Current: ~8,000-10,000 scrapes
- With pruning: ~12,000-17,000 scrapes (+50-70%)

### Safety Valve

If you're concerned about depth 2, **start with depth >= 3** and adjust based on:
1. Tomorrow's 16h test results
2. Manual review of pruned threads
3. Cost prediction accuracy

Can always relax 3→2 later for extra throughput.

---

**Summary**: Real data shows **depth >= 2** is the sweet spot, catching all 1→1 chains while maintaining quality through strict score=1 requirement.


