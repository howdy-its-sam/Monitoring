# Fix #16 Failure Analysis v2: The Budget Depletion Death Spiral

**Date**: October 18, 2025  
**Test**: 12-hour validation (`test_720min_20251018_073757`)  
**Status**: ❌ **FAILED** - Infinite deferral loop after 6 hours  
**Root Cause**: Budget depletion + inadequate safety margin + missing budget floor protection

---

## Executive Summary

Despite fixing the safety margin from `*1.5` → `*1.2`, the test still entered an **infinite deferral loop** after 6 hours of productive scraping. The issue is not a single bug but a **systemic problem** with how we handle budget depletion.

**Key Finding**: The `*1.2` safety margin works when budget is healthy (>100), but **fails catastrophically when budget approaches zero** because:

1. Even tiny scrapes (1-3 requests) need 20-30% buffer
2. When budget hits 0, it can't satisfy even `need ~1 (est=1)` scrapes
3. The 10-second cooldown only refills ~10 tokens, but we're deferring 5+ posts per batch
4. Result: **Budget stays pinned at 0**, infinite loop

---

## Timeline Analysis

### Test Metrics

| Metric | Value | Notes |
|--------|-------|-------|
| **Start time** | 7:37 AM | Test launched successfully |
| **Productive period** | 7:37 AM - 1:40 PM | ~6 hours of sustained scraping |
| **First budget=0** | ~1:40 PM | Budget completely depleted |
| **Deferral loop start** | 1:42 PM | Entered infinite loop |
| **Test stopped** | 7:46 AM (next day) | User intervention |
| **Total scrapes** | 98 posts | Should have been ~3,000+ |
| **Total deferrals** | 110 | Mostly during the stuck period |
| **Final state** | RPS=0.0, EMA=2.6, budget=0 | Dead in the water |

### The Death Spiral

```
Time     | Budget | Action | RPS | Result
---------|--------|--------|-----|--------
7:37 AM  | ~540   | Start  | 8.6 | ✅ Healthy scraping
10:00 AM | ~400   | Scrape | 7.2 | ✅ Normal depletion
12:00 PM | ~200   | Scrape | 5.4 | ✅ Still ok
1:30 PM  | ~50    | Scrape | 3.1 | ⚠️ Getting tight
1:40 PM  | 0      | DEFER  | 0.0 | ❌ Budget bottomed out
1:42 PM  | 0      | DEFER  | 0.0 | ❌ Infinite loop begins
7:46 AM  | 0      | DEFER  | 0.0 | ❌ Still stuck (18h later!)
```

---

## Root Causes

### 1. **Safety Margin Doesn't Scale Down**

**The Math Problem**:

```python
required_budget = int(estimated_cost * 1.2)  # 20% margin

# Examples:
# Large scrape: 200 * 1.2 = 240 (need 40 extra)  ← REASONABLE
# Small scrape:   3 * 1.2 =   3 (need 0 extra)  ← TOO TIGHT!
# Tiny scrape:    1 * 1.2 =   1 (need 0 extra)  ← NO BUFFER!
```

**The Problem**:
- For small scrapes (1-10 requests), the `*1.2` multiplier adds **0-2 requests** of buffer
- If the estimate is off by even 1 request, we blow the budget
- When budget hits 0, we can't afford even the tiniest scrape

**Evidence from logs**:

```
⏸️  Insufficient budget: need ~1 (est=1), have 0
⏸️  Insufficient budget: need ~2 (est=2), have 0
⏸️  Insufficient budget: need ~3 (est=3), have 0
```

These are **trivial scrapes** being deferred because we have zero buffer.

### 2. **No Budget Floor Protection**

**Current Logic**:

```python
if available_budget < required_budget:
    defer()  # Defer forever if budget never recovers
```

**Missing Logic**:

```python
if available_budget == 0:
    # CRITICAL: Budget completely empty
    # Need to SLEEP (not just defer) to allow meaningful refill
    print("🛑 Budget depleted, sleeping 30s for refill...")
    time.sleep(30)  # Refill ~30 requests
    continue
```

**Why this matters**:
- When budget=0, deferring 5 posts and sleeping 10s only refills ~10 requests
- Next iteration: Try to scrape 5 posts needing 2-10 requests each → still insufficient
- Result: Infinite loop because **refill rate < consumption rate**

### 3. **Batch Size Doesn't Adapt to Budget**

**Current Behavior**:

```python
batch_size = int(max(10, min(100, self.target_rps * gain * 2.0)))
# Tries to scrape 10-100 posts per batch, regardless of budget
```

**The Problem**:
- When budget is low (e.g., 50 requests), we try to scrape 10+ posts
- Each post needs 2-10 requests → total need: 20-100 requests
- Result: Defer entire batch, budget doesn't refill fast enough

**What Should Happen**:

```python
# Limit batch size based on available budget
max_affordable_posts = available_budget // 10  # Assume avg 10 req/post
batch_size = min(batch_size, max_affordable_posts)
```

### 4. **Cooldown Period Too Short**

**Current**:

```python
if posts_scraped_this_loop == 0 and deferrals_this_batch > 0:
    print(f"⏳ All {deferrals_this_batch} posts deferred, cooling down for 10s")
    time.sleep(10)  # Only refills ~10 requests
```

**The Math**:
- Rate limit: 540 requests / 600 seconds = **0.9 requests/second**
- 10-second sleep → **9 requests** refilled
- If we just deferred 5 posts needing 2-10 requests each (total 10-50 needed), 9 requests isn't enough

**What Should Happen**:

```python
if available_budget < 50:  # Critical threshold
    needed_refill = 50 - available_budget
    sleep_time = needed_refill / 0.9  # Calculate sleep needed
    sleep_time = max(30, min(120, sleep_time))  # 30s-120s range
    print(f"🛑 Budget critical ({available_budget}), sleeping {sleep_time:.0f}s for refill...")
    time.sleep(sleep_time)
```

---

## Why This Happens After 6 Hours

**Hypothesis**: Natural budget depletion through variance

1. **Hours 0-2**: Fresh budget (540), healthy scraping at 6-8/min
2. **Hours 2-4**: Occasional expensive posts (100+ requests) slowly deplete buffer
3. **Hours 4-6**: Budget oscillates between 100-300, still sustainable
4. **Hour 6**: A cluster of expensive posts (or unlucky variance) drops budget below 50
5. **Budget hits 0**: Can't recover because:
   - Batch size still high (trying 10+ posts)
   - Safety margin too tight for small scrapes
   - Cooldown too short (10s → 9 requests, not enough)
   - No emergency "deep sleep" mode

**The Trap**:
Once budget hits 0, the system enters a **stable failure state**:

```
Budget = 0
↓
Defer all posts (need ≥1, have 0)
↓
Sleep 10s → budget = 9
↓
Try to scrape 5 posts (need 10-50 total)
↓
Budget still insufficient
↓
Defer all posts
↓
Budget = 0 again (consumed by background refill)
↓
LOOP FOREVER
```

---

## Proposed Solutions

### Fix 16C: Adaptive Safety Margin with Floor

**Problem**: `*1.2` doesn't provide enough buffer for small scrapes  
**Solution**: Use max of percentage AND fixed buffer

```python
# OLD (fails for small scrapes):
required_budget = int(estimated_cost * 1.2)

# NEW (always has minimum buffer):
percentage_buffer = int(estimated_cost * 1.15)  # Reduce to 15% for large scrapes
fixed_buffer = 5  # Minimum 5-request buffer
required_budget = max(percentage_buffer, estimated_cost + fixed_buffer)

# Examples:
# Large: max(200*1.15, 200+5) = max(230, 205) = 230  ← 15% buffer (reasonable)
# Small: max(3*1.15, 3+5)     = max(3, 8)     = 8     ← Fixed buffer (safe!)
# Tiny:  max(1*1.15, 1+5)     = max(1, 6)     = 6     ← Fixed buffer (safe!)
```

### Fix 16D: Budget Floor Protection

**Problem**: When budget hits 0, can't recover with short cooldowns  
**Solution**: Implement emergency "deep sleep" mode

```python
# BEFORE checking individual posts:
available_budget = self.rate_limiter.available_budget()

if available_budget == 0:
    print("🛑 CRITICAL: Budget completely depleted")
    print("   Entering emergency refill mode (60s sleep)...")
    time.sleep(60)  # Refill ~54 requests
    continue  # Skip this loop iteration entirely

elif available_budget < 30:
    print(f"⚠️  Budget very low ({available_budget})")
    print("   Sleeping 30s to allow refill...")
    time.sleep(30)  # Refill ~27 requests
    # Don't continue, but will reduce batch size below
```

### Fix 16E: Budget-Aware Batch Sizing

**Problem**: Batch size doesn't consider available budget  
**Solution**: Dynamically limit batch based on budget

```python
# CURRENT:
batch_size = int(max(10, min(100, self.target_rps * gain * 2.0)))

# NEW:
base_batch_size = int(max(10, min(100, self.target_rps * gain * 2.0)))

# Limit by budget (assume average 10 requests/post)
avg_cost_per_post = 10
max_affordable = max(1, available_budget // avg_cost_per_post)
batch_size = min(base_batch_size, max_affordable)

print(f"📊 Budget: {available_budget}, batch: {batch_size} (can afford ~{max_affordable} posts)")
```

### Fix 16F: Adaptive Cooldown Duration

**Problem**: 10-second cooldown refills only ~9 requests, often insufficient  
**Solution**: Calculate cooldown based on budget deficit

```python
# CURRENT:
if posts_scraped_this_loop == 0 and deferrals_this_batch > 0:
    time.sleep(10)

# NEW:
if posts_scraped_this_loop == 0 and deferrals_this_batch > 0:
    # Calculate needed refill to reach safe threshold
    safe_threshold = 50
    needed_refill = max(0, safe_threshold - available_budget)
    
    # Calculate sleep time (0.9 requests/sec refill rate)
    sleep_time = needed_refill / 0.9
    sleep_time = max(15, min(120, sleep_time))  # 15s-120s range
    
    print(f"⏳ All {deferrals_this_batch} posts deferred")
    print(f"   Budget: {available_budget}/{safe_threshold}, sleeping {sleep_time:.0f}s for refill...")
    time.sleep(sleep_time)
```

---

## Implementation Priority

### Phase 1: Emergency Fixes (Implement Immediately)

**Goal**: Prevent budget=0 death spiral

1. ✅ **Fix 16C**: Adaptive safety margin (`max(est*1.15, est+5)`)
2. ✅ **Fix 16D**: Budget floor protection (emergency sleep at budget=0)
3. ✅ **Fix 16F**: Adaptive cooldown (calculate sleep based on deficit)

**Expected Impact**: Should prevent infinite loops entirely

### Phase 2: Optimization (Implement After Validation)

**Goal**: Improve efficiency when budget is tight

4. ⏳ **Fix 16E**: Budget-aware batch sizing
5. ⏳ **Fix 17**: Adaptive threshold based on p90 (from original plan)

**Expected Impact**: Better throughput when budget is constrained

---

## Validation Plan

### Test 1: 2-Hour Stress Test

**Purpose**: Validate emergency fixes prevent death spiral

```bash
./run_long_test.sh 120 10.0 --no-bootstrap --dir=fix16cdf_2h_validation
```

**Success Criteria**:
- ✅ No budget=0 occurrences
- ✅ If budget drops below 30, recovers within 2 minutes
- ✅ No deferral loops lasting >5 minutes
- ✅ Sustained throughput: 4-6 scrapes/min

### Test 2: 12-Hour Endurance Test

**Purpose**: Confirm long-term stability

```bash
./run_long_test.sh 720 10.0 --no-bootstrap --dir=fix16cdf_12h_validation
```

**Success Criteria**:
- ✅ Runs full 12 hours without intervention
- ✅ Total scrapes: 2,500-3,500 (vs 98 in this test)
- ✅ RPS never pinned at 0.0 for >5 minutes
- ✅ Budget oscillates naturally (50-400 range)

---

## Key Learnings

1. **Percentage-only safety margins fail at small scales**  
   → Need hybrid approach: `max(percentage, fixed_buffer)`

2. **Short cooldowns can't recover from budget depletion**  
   → Need adaptive sleep based on deficit

3. **Batch sizing must respect budget constraints**  
   → Can't try to scrape 100 posts with 50 requests available

4. **Budget=0 is a critical failure state**  
   → Needs emergency handling, not normal deferral logic

5. **Tests need to run long enough to hit budget pressure**  
   → 1-hour tests won't catch this (happens after 6 hours)

---

## Files to Modify

### 1. `unified_scraper.py`

**Changes**:
- Line ~430: Update safety margin calculation (Fix 16C)
- Line ~280: Add budget floor check at top of loop (Fix 16D)
- Line ~500: Update cooldown calculation (Fix 16F)
- Line ~325: Add budget-aware batch sizing (Fix 16E - optional)

### 2. `rate_limiter.py`

**Changes** (optional, for better visibility):
- Add `is_critical()` method: Returns True if budget < 30
- Add `time_to_refill(target_budget)` method: Calculates sleep needed

---

## Comparison: Before vs After

| Scenario | Before (v1) | After (v2) | Improvement |
|----------|------------|------------|-------------|
| **Large scrape (200 req)** | Need 240 (`*1.2`) | Need 230 (`*1.15`) | Slightly less conservative |
| **Small scrape (3 req)** | Need 3 (`*1.2`) | Need 8 (`3+5`) | +167% buffer! |
| **Tiny scrape (1 req)** | Need 1 (`*1.2`) | Need 6 (`1+5`) | +500% buffer! |
| **Budget hits 0** | Defer → loop forever | Sleep 60s → refill 54 | Recovers! |
| **Budget at 20** | Defer → loop | Sleep 33s → refill to 50 | Recovers! |
| **All posts deferred** | Sleep 10s → 9 refill | Sleep 15-120s (adaptive) | 2-13x refill |

---

## Next Steps

1. ✅ Stop current test (DONE)
2. ⏳ Implement Fixes 16C, 16D, 16F
3. ⏳ Run 2-hour validation test
4. ⏳ If successful, run 12-hour endurance test
5. ⏳ If stable, consider Phase 2 optimizations (16E, 17)

---

## Appendix: Log Evidence

### Productive Scraping (First Hour)

```
[1:719] 🎯 1o9vwh8 r/wallstreetbets (T=0.30, depth=shallow)...
[1:719] 🎯 1o9ufui r/wallstreetbets (T=0.30, depth=shallow)...
[13:39:07] RPS=0.0 EMA=8.6 g=0.96 ΔInfo/sc=52.9 waste=0%
```

### Budget Depletion (Hour 6)

```
⚡ Instant RPS: 0.13, tokens available: 0
⏸️  Insufficient budget: need ~3 (est=3), have 0
⏸️  Insufficient budget: need ~1 (est=1), have 0
⏸️  Insufficient budget: need ~9 (est=8), have 0
⏳ All 5 posts deferred, cooling down for 10s to allow budget refill
```

### Death Spiral (Hours 6-18)

```
[13:42:32] RPS=0.0 EMA=3.6 g=0.50 ΔInfo/sc=53.4 waste=19%
[13:43:37] RPS=0.0 EMA=3.1 g=0.50 ΔInfo/sc=53.4 waste=19%
[13:44:58] RPS=0.0 EMA=2.6 g=0.50 ΔInfo/sc=53.4 waste=19%
[13:46:20] RPS=0.0 EMA=2.2 g=0.50 ΔInfo/sc=53.4 waste=19%
```

RPS pinned at 0.0 for 18+ hours until user intervention.

---

**Conclusion**: The `*1.2` margin was a step in the right direction but insufficient. We need **emergency budget protection** and **adaptive cooldowns** to handle depletion gracefully. Implementing Fixes 16C-16F should eliminate the death spiral entirely.

