# Idle Time & Throughput Fixes - Implementation Complete

## Summary

All 8 fixes from the plan have been successfully implemented. The system should now:
- Maintain continuous throughput near target budget
- Keep global gain controller active (not pinned)
- Allocate API effort proportionally to subreddit activity × priority
- Automatically convert idle time into productive discovery
- Provide enhanced observability metrics

## Implementation Details

### ✅ Fix #1: Normalize Coverage to Target Budget
**File**: `coverage_allocator.py`
**Lines**: 146-154

- Changed from `current_rps` to `budget_rps` for available budget
- Added EMA floor at 60% of target budget
- **Impact**: Prevents self-throttling during idle periods

### ✅ Fix #2: Include Post Rate in Demand Scaling
**File**: `coverage_allocator.py`
**Lines**: 161-192

- Added posting rate (posts/hour) to demand calculation
- Applied rate weighting to both demand and final fractions
- **Impact**: Prevents high-rate subreddits from dominating budget

### ✅ Fix #3: Decouple Discovery from Coverage
**File**: `discovery_poller.py`
**Lines**: 68-96

- Changed from coverage-based to rank-based polling intervals
- Formula: `interval = 30.0 + (5.0 * rank)` seconds
- Clamped to 20s - 300s range
- **Impact**: Discovery stays fresh regardless of coverage fraction

### ✅ Fix #4: Opportunistic Discovery When Idle
**File**: `unified_scraper.py`
**Lines**: 285-320

- Added idle detection logic (5+ seconds since last discovery)
- Calls `poller.poll_top_k_due(K=5)` during idle periods
- Records idle discoveries in telemetry
- **Impact**: Fills gaps instead of sleeping

### ✅ Fix #5: Add Discovery Rate Tracking
**File**: `discovery_poller.py`
**Lines**: 68-70, 188-189, 265-291

- Added `discovery_history` deque to track (timestamp, subreddit, post_id)
- Implemented `get_recent_discovery_rates(window_minutes=10)`
- Records every discovery in `poll_subreddit()`
- **Impact**: Enables rate-aware budget allocation

### ✅ Fix #6: Update unified_scraper.py to Use New Features
**File**: `unified_scraper.py`
**Lines**: 267-277

- Passes `ema_rps` to coverage allocator
- Passes `posts_per_subreddit` from discovery rates
- **Impact**: Better-informed coverage calculations

### ✅ Fix #7: Enhanced Observability and Telemetry
**File**: `telemetry.py`
**Lines**: 89-92, 235-354

Added tracking for:
- `request_history` - per-scrape details (subreddit, depth, requests)
- `idle_discoveries` - timestamps of idle-triggered discoveries
- `coverage_history` - F_target vs F_realized per subreddit

Added methods:
- `_compute_top_k_share(k, allocator)` - % of requests to top K subs
- `_compute_depth_share(depth)` - % of requests using specified depth
- `_compute_idle_discovery_rate()` - idle discovery bursts per minute
- `_compute_avg_coverage_skew()` - average |F_target - F_realized|
- `log_coverage_metrics(...)` - log coverage drift to JSONL

**Impact**: Full visibility into allocation and utilization

### ✅ Fix #8: Post Selection Policy Abstraction
**Files**: `coverage_allocator.py`, `selection_policy.json`, `unified_scraper.py`

**coverage_allocator.py**:
- Added `selection_policy` and `policy_file` fields (lines 69-71)
- Updated `should_scrape_post()` to accept `post_data` parameter (lines 196-228)
- Added `_load_selection_policy()` method (lines 255-275)
- Added `_apply_selection_rule()` method (lines 277-324)

**selection_policy.json**:
- Created default policy with 3-tier sampling strategy
- Top 10: track everything
- Mid-tier (10-25): only posts with activity (5+ comments, 20+ score)
- Lower-tier (26+): 15% random sample

**unified_scraper.py**:
- Pass post data dict to `should_scrape_post()` (lines 232-241, 294-303)

**Impact**: Zero-code experimentation with discovery strategies

## Files Modified

1. `discovery_poller.py` - Fixes #3, #4, #5
2. `coverage_allocator.py` - Fixes #1, #2, #8
3. `telemetry.py` - Fix #7
4. `unified_scraper.py` - Fixes #4, #6, #8
5. `selection_policy.json` - Fix #8 (new file)

## Expected Improvements

| Metric | Before | Expected After |
|--------|--------|----------------|
| Avg RPS | ~0 | 5-10 rps |
| Global gain | 0.5 (pinned min) | 0.8-1.2 (stable) |
| Idle time | 80%+ | <10% |
| Discovery rate | Burst-only | Continuous stream |
| Waste rate | 43% | <15% |
| Utilization | 0% | 60-90% |

## Testing

To test the fixes:

```bash
# Kill current scraper
pkill -f unified_scraper.py

# Clear old data for fresh start (optional)
rm -rf adaptive_data_v2/

# Run with new fixes
python3 unified_scraper.py 10 10.0 --no-bootstrap --dir=adaptive_data_v2 > scraper_v2.log 2>&1 &

# Monitor
tail -f scraper_v2.log
```

Watch for:
- Higher RPS (5-10 instead of 0)
- Gain stabilizing near 1.0
- Continuous discovery activity
- No "excess bandwidth" alerts
- Lower waste rate (<15%)

## Next Steps

1. Test with fresh run
2. Monitor metrics for 30+ minutes
3. Verify throughput improvements
4. Experiment with different selection policies
5. Compare v2 vs v1 performance

## Configuration Files

### selection_policy.json

Easily switch strategies by editing this file:

**Strategy 1: Greedy (maximize coverage)**
```json
{
  "strategy": "greedy",
  "rules": [{"ranks": [0, 999], "method": "all"}]
}
```

**Strategy 2: Viral only**
```json
{
  "strategy": "viral",
  "rules": [{"ranks": [0, 999], "method": "hot_only", "min_comments": 50}]
}
```

**Strategy 3: Balanced (default)**
Already configured in `selection_policy.json`

No code changes needed - just edit JSON and restart!

---

**Implementation Date**: October 16, 2025
**Total Files Modified**: 5
**Total Lines Changed**: ~450
**Status**: ✅ COMPLETE - Ready for Testing

