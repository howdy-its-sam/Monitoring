# Long-Running Test Guide

## Quick Start

Run a test that **temporarily** disables all sleep modes:

```bash
./run_long_test.sh 960 10.0 --no-bootstrap --dir=test_output
```

That's it! The script will:
1. ✅ Save your current power settings
2. ✅ Disable ALL sleep modes (system, disk, standby, powernap, wake-on-LAN)
3. ✅ Run your test with maximum caffeinate protection (`-dis` flags)
4. ✅ Automatically restore settings when done (or if interrupted with Ctrl+C)

## What Gets Disabled (Temporarily)

| Setting | Normal | During Test | Why |
|---------|--------|-------------|-----|
| System Sleep | ON | OFF | Prevents computer from sleeping |
| Disk Sleep | 10 min | OFF | Keeps drives spinning (faster I/O) |
| Standby | ON | OFF | Prevents deep sleep after long idle |
| Power Nap | ON | OFF | Prevents wake-for-background-tasks |
| Wake on LAN | ON | OFF | Prevents network-triggered wakes |

## Usage Examples

**16-hour mega test:**
```bash
./run_long_test.sh 960 10.0 --no-bootstrap --dir=fix16_recovery_16h
```

**1-hour validation:**
```bash
./run_long_test.sh 60 10.0 --no-bootstrap --dir=quick_test
```

**Custom test with all options:**
```bash
./run_long_test.sh 120 15.0 --dir=custom_test --some-other-flag
```

## Safety Features

### Automatic Cleanup
- Settings restore **even if you press Ctrl+C** (trap on EXIT/INT/TERM)
- Settings restore **even if script crashes** (trap on EXIT)
- Settings restore **when test completes normally**

### Manual Restore (if needed)
If something goes terribly wrong and settings don't restore:

```bash
sudo pmset -a sleep 1 disksleep 10 standby 1 powernap 1 womp 1
```

### Check Current Settings
```bash
pmset -g
```

### Verify Script is Working
Before running a long test, try a 1-minute test:

```bash
./run_long_test.sh 1 10.0 --no-bootstrap --dir=test_1min
```

Watch for:
- "🔧 Disabling ALL sleep modes temporarily..." ✅
- "✅ Sleep modes disabled" ✅  
- "🚀 Starting test..." ✅
- Test runs for ~1 minute ✅
- "🔧 Restoring normal power settings..." ✅
- "✅ Power settings restored" ✅

## Running in Background

The script uses `tee` to both display output AND save to a log file. If you want to run completely in background:

```bash
nohup ./run_long_test.sh 960 10.0 --no-bootstrap --dir=test > /dev/null 2>&1 &
```

⚠️ **Warning**: Running in background means cleanup won't trigger if you close terminal. Only do this if you're confident the test will complete normally.

## Monitoring Progress

While test is running, check the log file:

```bash
# Last 50 lines
tail -50 test_960min_YYYYMMDD_HHMMSS.log

# Follow in real-time
tail -f test_960min_YYYYMMDD_HHMMSS.log

# Search for errors
grep -E "(ERROR|⚠️|CRITICAL)" test_960min_YYYYMMDD_HHMMSS.log
```

## Troubleshooting

### "Permission denied"
```bash
chmod +x run_long_test.sh
```

### "sudo: command not found" 
The script needs sudo to change power settings. Enter your password when prompted.

### Computer still went to sleep
Check if you:
- Closed the laptop lid → **Don't do this!**
- Selected Sleep from menu → **Don't do this!**
- Ran the script in background with `&` → Use the script normally (it has its own log file)

### Settings not restored
Manually restore with:
```bash
sudo pmset -a sleep 1 disksleep 10 standby 1 powernap 1 womp 1
```

## What to Do During Test

**✅ DO:**
- Leave laptop open
- Keep plugged into power
- Let it run overnight
- Check logs occasionally with `tail -f`

**❌ DON'T:**
- Close the laptop lid
- Select Sleep from Apple menu
- Unplug (might hit low battery sleep)
- Kill terminal window (use Ctrl+C in the window instead)

## Log Files

Each test creates a timestamped log file:
```
test_960min_20251018_073000.log
```

Format: `test_<duration>min_<YYYYMMDD>_<HHMMSS>.log`

This prevents overwriting previous test logs.

