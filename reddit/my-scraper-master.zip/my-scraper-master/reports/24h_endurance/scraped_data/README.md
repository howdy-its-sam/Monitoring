# 24-Hour Test - Scraped Data

**Test ID:** test_1440min_20251018_112237  
**Date:** October 18-19, 2025  
**Total Posts:** 331  
**Exemplar Posts:** 6

---

## 📂 Directory Structure

```
scraped_data/
├── merged/                      # Merged files (latest state) for all posts
│   ├── 1hnzdk8_merged.json     # One file per post
│   ├── 1hopm1d_merged.json
│   └── ... (331 files total)
│
└── temporal_examples/           # Full temporal history for exemplars
    ├── EXEMPLARS_INDEX.json    # Index explaining each example
    ├── 1o9bh67_LARGE_HIGH_ACTIVITY/
    │   ├── raw_scrapes/
    │   │   ├── scrape_001_*.json
    │   │   ├── scrape_002_*.json
    │   │   └── ... (all temporal snapshots)
    │   └── scheduler_state.json
    └── ... (6 exemplar directories)
```

---

## 📊 Merged Files

**Location:** `merged/`  
**Count:** 331 files  
**Format:** `{post_id}_merged.json`

Each merged file contains:
- **Latest comment tree state** with complete score_history
- **Metadata** about the post and scraping
- **Merge info** showing how many source scrapes it came from

**Key Point:** The "merged" file is actually just the **latest scrape**, which already contains the full `score_history` for each comment. We use temporal snapshots, so the latest one is the merged version.

### Example Structure:

```json
{
  "comments": [
    {
      "id": "abc123",
      "author": "user1",
      "body": "Comment text",
      "score": 42,
      "score_history": [
        [15, "2025-10-19T11:06:58"],
        [28, "2025-10-19T11:12:03"],
        [42, "2025-10-19T11:22:10"]
      ],
      "replies": [...]
    }
  ],
  "metadata": {
    "post_id": "1hnzdk8",
    "subreddit": "wallstreetbets",
    "total_comments": 247,
    "scrape_timestamp": "2025-10-19T11:22:10",
    "merge_info": {
      "source_scrapes": 6,
      "is_merged": true
    }
  }
}
```

---

## 📁 Temporal Examples

**Location:** `temporal_examples/`  
**Count:** 6 posts  
**Purpose:** Validation and learning

These posts include **complete temporal history** (all scrapes) to demonstrate:
- How score_history is built over time
- How new comments appear in successive scrapes
- Different activity patterns

### Exemplars Index

See `temporal_examples/EXEMPLARS_INDEX.json` for details on each example.

**Quick reference:**
- `LARGE_HIGH_ACTIVITY` - Extensive growth (100+ scrapes, 1000+ comments)
- `MEDIUM_HIGH_ACTIVITY` - Sustained activity (50+ scrapes)
- `MEDIUM_MODERATE_ACTIVITY` - Typical re-scraping (5-10 scrapes)
- `SMALL_MODERATE_ACTIVITY` - Smaller post with growth
- `LARGE_SINGLE_SCRAPE` - Single snapshot of larger discussion
- `TINY_SINGLE_SCRAPE` - Minimal post (edge case)

---

## 🔍 How to Use This Data

### Quick Analysis - Use Merged Files

For most analysis, use the `merged/` files:

```python
import json
from pathlib import Path

# Read a merged file
with open('merged/1hnzdk8_merged.json') as f:
    data = json.load(f)

# Access comments
for comment in data['comments']:
    print(f"{comment['author']}: {comment['body'][:50]}")
    print(f"  Score evolution: {comment['score_history']}")
```

### Deep Dive - Use Temporal Examples

To understand how data evolves:

```python
# Load all scrapes for an exemplar
example_dir = Path('temporal_examples/1o9bh67_LARGE_HIGH_ACTIVITY/raw_scrapes')
scrapes = sorted(example_dir.glob('scrape_*.json'))

for scrape_file in scrapes:
    with open(scrape_file) as f:
        data = json.load(f)
        print(f"{data['metadata']['scrape_timestamp']}: {data['metadata']['total_comments']} comments")
```

---

## 📈 Data Statistics

- **Total merged files:** 331
- **Exemplar posts:** 6
- **Date range:** October 18-19, 2025 (24 hours)
- **Subreddits:** 35
- **Total comments:** ~90,000+ (across all posts)

---

## 📚 Related Documentation

- `../DATA_INTERPRETATION_GUIDE.md` - Complete guide to data structure
- `../REDDIT_JSON_TREE_STRUCTURE.md` - JSON format reference
- `../24H_ENDURANCE_TEST_FINAL_REPORT.md` - Full test report
- `temporal_examples/EXEMPLARS_INDEX.json` - Exemplar details

---

**Dataset Created:** October 20, 2025  
**Source:** fix16cdf_24h_endurance/  
**Processing:** create_merged_dataset.py


---

## ✅ Merge Quality Verification

The merged files have been created with **true cumulative score histories**:

- **331 merged files** created
- **325 files verified** to have multi-entry score histories
- Each comment's `score_history` array contains chronological entries from ALL scrapes

### Example Verification (Post 1o9qp5p):
- 17 source scrapes
- 1,314 comments with complete score histories
- Sample comment tracked across all 17 scrapes:
  - Score evolution: 773 → 777 → 788 → ... → 818 (+45 total)

### How Merging Works:

1. Process all scrape files chronologically (sorted by filename)
2. For each comment seen across scrapes, append `[score, timestamp]` to history
3. Final merged file contains latest comment tree with complete temporal data

**Result:** Each comment's `score_history` shows how its score evolved over time!
