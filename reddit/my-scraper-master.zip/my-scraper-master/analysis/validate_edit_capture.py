#!/usr/bin/env python3
"""
Validate Edit Capture - Compare our text_history detection vs Reddit's edited field
"""

import json
from pathlib import Path


def count_reddit_edited_field(post_dir):
    """Count comments with edited=True in latest raw scrape"""
    raw_scrapes = post_dir / 'raw_scrapes'
    scrape_files = sorted(raw_scrapes.glob('scrape_*.json'))
    
    if not scrape_files:
        return 0
    
    # Check latest scrape
    with open(scrape_files[-1]) as f:
        data = json.load(f)
    
    count = 0
    examples = []
    
    def traverse(comments):
        nonlocal count
        for comment in comments:
            if comment.get('edited'):
                count += 1
                if len(examples) < 5:
                    examples.append({
                        'id': comment.get('id'),
                        'author': comment.get('author'),
                        'edited': comment.get('edited')
                    })
            if comment.get('replies'):
                traverse(comment['replies'])
    
    traverse(data.get('comments', []))
    return count, examples


def count_text_history_changes(merged_file):
    """Count comments with len(text_history) > 1 in merged file"""
    with open(merged_file) as f:
        data = json.load(f)
    
    count = 0
    examples = []
    
    def traverse(comments):
        nonlocal count
        for comment in comments:
            text_hist = comment.get('text_history', [])
            if len(text_hist) > 1:
                count += 1
                if len(examples) < 5:
                    examples.append({
                        'id': comment.get('id'),
                        'author': comment.get('author'),
                        'versions': len(text_hist),
                        'first': text_hist[0][0][:40] if text_hist[0][0] else '',
                        'last': text_hist[-1][0][:40] if text_hist[-1][0] else ''
                    })
            if comment.get('replies'):
                traverse(comment['replies'])
    
    traverse(data.get('comments', []))
    return count, examples


def main():
    # Check the test merge we just created
    post_dir = Path('fix16cdf_24h_endurance/1o9bh67')
    merged_file = Path('test_merged_1o9bh67.json')
    
    print("="*70)
    print("EDIT CAPTURE VALIDATION")
    print("="*70)
    print(f"\nPost: {post_dir.name}")
    print()
    
    # Count Reddit's edited field
    reddit_count, reddit_examples = count_reddit_edited_field(post_dir)
    print(f"Reddit's edited=True:        {reddit_count} comments")
    
    # Count our text_history changes
    our_count, our_examples = count_text_history_changes(merged_file)
    print(f"Our text_history changes:    {our_count} comments")
    
    print()
    print(f"Capture rate: {our_count}/{reddit_count} = {our_count/reddit_count*100 if reddit_count > 0 else 0:.1f}%")
    
    if our_count > reddit_count:
        diff = our_count - reddit_count
        print(f"\nNote: We captured {diff} MORE changes than Reddit's edited field.")
        print("This is GOOD - likely includes deletions which Reddit doesn't always flag as 'edited'")
    elif our_count < reddit_count:
        diff = reddit_count - our_count
        print(f"\nWarning: We missed {diff} edits that Reddit flagged")
    else:
        print("\nPerfect match!")
    
    print("\n" + "-"*70)
    print("Sample of Reddit's edited comments:")
    for i, ex in enumerate(reddit_examples, 1):
        print(f"{i}. {ex['id']} by {ex['author']} (edited: {ex['edited']})")
    
    print("\n" + "-"*70)
    print("Sample of our captured changes:")
    for i, ex in enumerate(our_examples, 1):
        print(f"{i}. {ex['id']} by {ex['author']} ({ex['versions']} versions)")
        print(f"   '{ex['first']}' → '{ex['last']}'")


if __name__ == '__main__':
    main()

