#!/usr/bin/env python3
"""
Analyze comments-per-request efficiency across all historical scrapes.

This calculates the "API cost per comment" - i.e., if we get 10 comments
in one request, each comment "costs" 0.1 requests.

Useful for understanding:
- Which posts have efficient API usage (many comments per request)
- Which posts are expensive (few comments per request)
- Whether depth mode affects efficiency
- Whether pruning strategies would improve efficiency
"""

import json
from pathlib import Path
from collections import defaultdict
from typing import Dict, List, Tuple
import statistics


def analyze_file(filepath: Path) -> Dict:
    """Extract request efficiency metrics from a JSON file."""
    try:
        with open(filepath, 'r') as f:
            data = json.load(f)
        
        metadata = data.get('metadata', {})
        total_comments = metadata.get('total_comments', 0)
        api_requests = metadata.get('api_requests', 0)
        
        if api_requests == 0 or total_comments == 0:
            return None
        
        # Calculate efficiency metrics
        comments_per_request = total_comments / api_requests
        requests_per_comment = api_requests / total_comments
        
        return {
            'file': filepath.name,
            'total_comments': total_comments,
            'api_requests': api_requests,
            'comments_per_request': comments_per_request,
            'requests_per_comment': requests_per_comment,
            'coverage_percent': metadata.get('coverage_percent', 0),
        }
    except Exception as e:
        return None


def main():
    print("🔍 Analyzing Comments-Per-Request Efficiency\n")
    print("=" * 80)
    
    # Find all JSON files
    base_dir = Path(__file__).parent
    search_dirs = [
        base_dir / "fix16cdf_24h_endurance",
        base_dir / "fix16cdf_2h_test",
        base_dir / "fix16_12h_test",
        base_dir / "fix16_recovery_16h",
    ]
    
    results = []
    
    for search_dir in search_dirs:
        if not search_dir.exists():
            continue
        
        for json_file in search_dir.rglob("*.json"):
            result = analyze_file(json_file)
            if result:
                results.append(result)
    
    if not results:
        print("❌ No valid data found!")
        return
    
    print(f"✅ Analyzed {len(results)} scrapes\n")
    print("=" * 80)
    
    # Calculate statistics
    comments_per_req_values = [r['comments_per_request'] for r in results]
    requests_per_comment_values = [r['requests_per_comment'] for r in results]
    
    print("\n📊 OVERALL EFFICIENCY STATISTICS\n")
    print("Comments per Request:")
    print(f"  Mean:   {statistics.mean(comments_per_req_values):>8.2f} comments/request")
    print(f"  Median: {statistics.median(comments_per_req_values):>8.2f} comments/request")
    print(f"  Min:    {min(comments_per_req_values):>8.2f} comments/request")
    print(f"  Max:    {max(comments_per_req_values):>8.2f} comments/request")
    print(f"  Stdev:  {statistics.stdev(comments_per_req_values):>8.2f}")
    
    print("\nRequests per Comment (API cost per comment):")
    print(f"  Mean:   {statistics.mean(requests_per_comment_values):>8.4f} requests/comment")
    print(f"  Median: {statistics.median(requests_per_comment_values):>8.4f} requests/comment")
    print(f"  Min:    {min(requests_per_comment_values):>8.4f} requests/comment")
    print(f"  Max:    {max(requests_per_comment_values):>8.4f} requests/comment")
    print(f"  Stdev:  {statistics.stdev(requests_per_comment_values):>8.4f}")
    
    # Categorize by efficiency
    print("\n" + "=" * 80)
    print("\n📈 EFFICIENCY DISTRIBUTION\n")
    
    efficient = [r for r in results if r['comments_per_request'] >= 20]
    moderate = [r for r in results if 10 <= r['comments_per_request'] < 20]
    inefficient = [r for r in results if 5 <= r['comments_per_request'] < 10]
    very_inefficient = [r for r in results if r['comments_per_request'] < 5]
    
    print(f"Very Efficient (≥20 comments/req):   {len(efficient):>5} scrapes ({len(efficient)/len(results)*100:>5.1f}%)")
    print(f"Moderate (10-20 comments/req):       {len(moderate):>5} scrapes ({len(moderate)/len(results)*100:>5.1f}%)")
    print(f"Inefficient (5-10 comments/req):     {len(inefficient):>5} scrapes ({len(inefficient)/len(results)*100:>5.1f}%)")
    print(f"Very Inefficient (<5 comments/req):  {len(very_inefficient):>5} scrapes ({len(very_inefficient)/len(results)*100:>5.1f}%)")
    
    # Show examples
    print("\n" + "=" * 80)
    print("\n🏆 MOST EFFICIENT SCRAPES (Top 10)\n")
    
    top_efficient = sorted(results, key=lambda x: x['comments_per_request'], reverse=True)[:10]
    for i, r in enumerate(top_efficient, 1):
        print(f"{i:2}. {r['comments_per_request']:>6.1f} comments/req "
              f"({r['total_comments']:>4} comments, {r['api_requests']:>3} requests) "
              f"- {r['file'][:40]}")
    
    print("\n" + "=" * 80)
    print("\n❌ LEAST EFFICIENT SCRAPES (Bottom 10)\n")
    
    bottom_efficient = sorted(results, key=lambda x: x['comments_per_request'])[:10]
    for i, r in enumerate(bottom_efficient, 1):
        print(f"{i:2}. {r['comments_per_request']:>6.1f} comments/req "
              f"({r['total_comments']:>4} comments, {r['api_requests']:>3} requests) "
              f"- {r['file'][:40]}")
    
    # Calculate potential savings from avoiding inefficient scrapes
    print("\n" + "=" * 80)
    print("\n💡 EFFICIENCY INSIGHTS\n")
    
    total_comments = sum(r['total_comments'] for r in results)
    total_requests = sum(r['api_requests'] for r in results)
    
    print(f"Total comments fetched:  {total_comments:,}")
    print(f"Total requests made:     {total_requests:,}")
    print(f"Overall efficiency:      {total_comments/total_requests:.2f} comments/request")
    print()
    
    # What if we only scraped efficient posts?
    if efficient:
        efficient_comments = sum(r['total_comments'] for r in efficient)
        efficient_requests = sum(r['api_requests'] for r in efficient)
        print(f"If we ONLY scraped 'very efficient' posts (≥20 comments/req):")
        print(f"  We'd get:   {efficient_comments:,} comments ({efficient_comments/total_comments*100:.1f}% of total)")
        print(f"  Using:      {efficient_requests:,} requests ({efficient_requests/total_requests*100:.1f}% of total)")
        print(f"  Efficiency: {efficient_comments/efficient_requests:.2f} comments/request")
        print(f"  Savings:    {total_requests - efficient_requests:,} requests ({(1-efficient_requests/total_requests)*100:.1f}%)")
    
    # Save detailed results
    output_file = base_dir / "comments_per_request_analysis.json"
    with open(output_file, 'w') as f:
        json.dump({
            'summary': {
                'total_scrapes': len(results),
                'total_comments': total_comments,
                'total_requests': total_requests,
                'mean_comments_per_request': statistics.mean(comments_per_req_values),
                'median_comments_per_request': statistics.median(comments_per_req_values),
                'mean_requests_per_comment': statistics.mean(requests_per_comment_values),
                'median_requests_per_comment': statistics.median(requests_per_comment_values),
            },
            'distribution': {
                'very_efficient': len(efficient),
                'moderate': len(moderate),
                'inefficient': len(inefficient),
                'very_inefficient': len(very_inefficient),
            },
            'top_10_efficient': top_efficient,
            'bottom_10_inefficient': bottom_efficient,
        }, f, indent=2)
    
    print(f"\n💾 Detailed results saved to: {output_file}")
    print("\n" + "=" * 80)


if __name__ == "__main__":
    main()

