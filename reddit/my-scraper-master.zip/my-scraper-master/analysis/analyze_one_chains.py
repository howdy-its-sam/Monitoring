
#!/usr/bin/env python3

"""
Analyze "1->1" (parent.score==1 and child.score==1) pruning opportunities in Reddit comment trees.

Usage:
  python analyze_one_chains.py --root /path/to/dataset --out /path/to/output_dir [--deleted-as-one]

What it does:
  - Recursively traverses each post's merged tree (expects files named 'final_merged.json')
  - Detects the first depth along each branch where a 1->1 pair appears
  - Computes how many descendant comments could be skipped if pruning at the first 1->1
  - Builds histograms:
      * Depth of first 1->1 encounter
      * Chain length of consecutive 1's at that encounter
  - Runs in two modes:
      * Strict: score == 1 only
      * Deleted-as-one (optional flag): treat deleted/removed comments as score==1

Outputs:
  - summary.json: totals and high-level metrics
  - occurrences.csv: per-occurrence records
  - hist_depth.png: histogram of first 1->1 depth
  - hist_chain.png: histogram of consecutive 1 length
  - hist_pruned_by_depth.png: pruned comment count by depth bucket
"""

import argparse
import json
import os
from pathlib import Path
from collections import Counter, defaultdict
from typing import Any, Dict, List, Tuple

import matplotlib.pyplot as plt
import pandas as pd


def is_deleted(node: Dict[str, Any]) -> bool:
    author = str(node.get("author", "")).lower()
    body = str(node.get("body", "")).lower()
    return author in ("[deleted]",) or body in ("[deleted]", "[removed]")


def get_score(node: Dict[str, Any], deleted_as_one: bool = False) -> int:
    # Try common fields; default to 0
    score = None
    
    # Check for score_history first (our format)
    if "score_history" in node and isinstance(node["score_history"], list) and node["score_history"]:
        try:
            # score_history is [[score, timestamp], ...]
            # Get the most recent (last) score
            score = int(node["score_history"][-1][0])
        except Exception:
            pass
    
    # Fall back to standard fields
    if score is None:
        for key in ("score", "ups"):
            if key in node:
                try:
                    score = int(node[key])
                    break
                except Exception:
                    pass
    
    if score is None:
        score = 0

    if deleted_as_one and is_deleted(node):
        return 1
    return score


def get_replies(node: Dict[str, Any]) -> List[Dict[str, Any]]:
    # Common nested reply fields
    for key in ("replies", "children"):
        if key in node and isinstance(node[key], list):
            return node[key]
    return []


def count_comments(node: Dict[str, Any]) -> int:
    """Count this node and all descendants (comments only)."""
    cnt = 1
    for ch in get_replies(node):
        cnt += count_comments(ch)
    return cnt


def analyze_tree(
    root: Dict[str, Any],
    deleted_as_one: bool = False
) -> Tuple[List[Dict[str, Any]], Dict[str, int]]:
    """
    Traverse all branches. For each branch, when the first 1->1 occurs, record:
      - depth of encounter
      - consecutive-one chain length at that point (along that branch)
      - pruned_size: descendant comments under the child node (excluded child)

    Returns:
      occurrences: list of dicts with details
      totals: overall counters
    """
    occurrences: List[Dict[str, Any]] = []
    totals = defaultdict(int)

    # Some datasets store the post at root with its comments in 'replies'.
    # We'll traverse replies; the post itself can have a score, but we don't treat it as a comment.
    def dfs(node, parent_score, depth, current_streak, branch_active):
        nonlocal occurrences, totals

        score = get_score(node, deleted_as_one=deleted_as_one)
        # Update streak of consecutive 1s along the branch
        streak = current_streak + 1 if score == 1 else 0

        # Detect first 1->1 occurrence along this branch
        triggered = False
        if parent_score == 1 and score == 1 and branch_active:
            # First time on this branch that parent==1 and child==1
            # Measure chain length along this branch by extending as long as 1s continue
            chain_len = streak  # includes this node and previous 1
            # Pruning point: if we stop here, we skip this child's descendants
            pruned_size = sum(count_comments(ch) for ch in get_replies(node))

            occurrences.append({
                "depth": depth,
                "chain_len": chain_len,
                "pruned_descendants": pruned_size,
            })
            totals["occurrences"] += 1
            totals["pruned_descendants"] += pruned_size

            # Stop recursing this branch beyond the pruning point (policy behavior)
            branch_active = False
            triggered = True

        # Recurse if branch still active
        if branch_active:
            for ch in get_replies(node):
                dfs(ch, score, depth + 1, streak, branch_active)

        return triggered

    # Kick off traversal from each top-level comment under the post
    for top in get_replies(root):
        root_score = get_score(root, deleted_as_one=deleted_as_one)
        start_streak = 1 if root_score == 1 else 0
        dfs(top, parent_score=root_score, depth=1, current_streak=start_streak, branch_active=True)

    return occurrences, totals


def render_histograms(occ_df: pd.DataFrame, outdir: Path, label: str):
    # Depth of first 1->1
    plt.figure()
    if not occ_df.empty:
        bins = range(1, int(occ_df["depth"].max()) + 2)
        occ_df["depth"].plot(kind="hist", bins=bins)
    else:
        plt.hist([], bins=10)
    plt.title(f"Depth of first 1->1 ({label})")
    plt.xlabel("Depth")
    plt.ylabel("Count")
    plt.tight_layout()
    plt.savefig(outdir / f"hist_depth_{label}.png")
    plt.close()

    # Chain length distribution
    plt.figure()
    if not occ_df.empty:
        bins = range(2, int(occ_df["chain_len"].max()) + 2)
        occ_df["chain_len"].plot(kind="hist", bins=bins)
    else:
        plt.hist([], bins=10)
    plt.title(f"Consecutive 1's Chain Length ({label})")
    plt.xlabel("Chain Length (>=2)")
    plt.ylabel("Count")
    plt.tight_layout()
    plt.savefig(outdir / f"hist_chain_{label}.png")
    plt.close()

    # Pruned by depth (sum of pruned_descendants grouped by depth bucket)
    if not occ_df.empty:
        agg = occ_df.groupby("depth")["pruned_descendants"].sum().reset_index()
        plt.figure()
        plt.bar(agg["depth"], agg["pruned_descendants"])
        plt.title(f"Pruned Descendants by Depth ({label})")
        plt.xlabel("Depth")
        plt.ylabel("Comments Skipped (proxy for requests saved)")
        plt.tight_layout()
        plt.savefig(outdir / f"hist_pruned_by_depth_{label}.png")
        plt.close()


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True, help="Root directory containing post folders with final_merged.json")
    ap.add_argument("--out", required=True, help="Output directory for results")
    ap.add_argument("--deleted-as-one", action="store_true", help="Treat deleted/removed comments as score==1")
    args = ap.parse_args()

    root = Path(args.root)
    outdir = Path(args.out)
    outdir.mkdir(parents=True, exist_ok=True)

    # Find candidate scrape JSON files (latest scrape per post)
    files = []
    post_dirs = {}
    
    # Find all scrape_*.json files and keep only the latest per post
    for p, _, fs in os.walk(root):
        for f in fs:
            if f.startswith("scrape_") and f.endswith(".json"):
                post_id = Path(p).parent.name if "raw_scrapes" in p else Path(p).name
                if post_id not in post_dirs or f > post_dirs[post_id][1]:
                    post_dirs[post_id] = (Path(p) / f, f)
    
    files = [path for path, _ in post_dirs.values()]

    if not files:
        print("No final_merged.json files found under", root)
        return

    all_occurrences = []
    totals_overall = defaultdict(int)
    posts_with_occurrence = 0
    total_posts = 0

    for fp in files:
        try:
            data = json.loads(Path(fp).read_text())
        except Exception as e:
            print("Failed to parse", fp, e)
            continue

        total_posts += 1

        # Handle different data structures
        if isinstance(data, dict):
            if "comments" in data and isinstance(data["comments"], list):
                # Our format: {"post": {...}, "comments": [...], "metadata": {...}}
                # Create a pseudo-root with comments as replies
                root_node = {"replies": data["comments"]}
            elif "post" in data and isinstance(data["post"], dict):
                root_node = data["post"]
            else:
                root_node = data
        else:
            root_node = data

        occ, totals = analyze_tree(root_node, deleted_as_one=args.deleted_as_one)

        if occ:
            posts_with_occurrence += 1
            all_occurrences.extend(occ)

        for k, v in totals.items():
            totals_overall[k] += v

    # Convert to DataFrame and save
    occ_df = pd.DataFrame(all_occurrences)
    occ_csv = outdir / ("occurrences_deleted_as_one.csv" if args.deleted_as_one else "occurrences_strict.csv")
    occ_df.to_csv(occ_csv, index=False)

    # Render histograms
    mode_label = "deleted_as_one" if args.deleted_as_one else "strict"
    render_histograms(occ_df, outdir, mode_label)

    # Summary
    summary = {
        "mode": mode_label,
        "total_posts": total_posts,
        "posts_with_1to1": posts_with_occurrence,
        "occurrences": int(totals_overall.get("occurrences", 0)),
        "pruned_descendants_total": int(totals_overall.get("pruned_descendants", 0)),
        "pruned_descendants_mean_per_occurrence": float(occ_df["pruned_descendants"].mean()) if not occ_df.empty else 0.0,
        "median_first_depth": float(occ_df["depth"].median()) if not occ_df.empty else None,
        "median_chain_len": float(occ_df["chain_len"].median()) if not occ_df.empty else None,
    }

    (outdir / f"summary_{mode_label}.json").write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
