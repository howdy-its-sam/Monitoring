#!/usr/bin/env python3
"""
Comprehensive Analysis of 24-Hour Endurance Test Results

This script analyzes the complete 24-hour test run, including:
- Overall scraping statistics
- Budget management performance
- Discovery effectiveness
- Dormancy/retirement system behavior
- Depth distribution and efficiency
- API request usage patterns
"""

import json
import re
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Tuple
import sys


class EnduranceTestAnalyzer:
    def __init__(self, log_file: str, data_dir: str):
        self.log_file = log_file
        self.data_dir = Path(data_dir)
        self.results = {}
        
    def parse_log(self):
        """Parse the complete log file for all metrics"""
        print("📖 Parsing log file...")
        
        with open(self.log_file, 'r') as f:
            lines = f.readlines()
        
        # Extract key metrics
        self.results['total_lines'] = len(lines)
        self.results['start_time'] = None
        self.results['end_time'] = None
        
        # Counters
        scrapes = []
        deferrals = []
        discoveries = defaultdict(list)
        budget_readings = []
        retirements = []
        dormancy_detections = []
        depth_distributions = []
        recovery_mode_entries = []
        
        for i, line in enumerate(lines):
            # Start/end times
            if '🚀 Starting at' in line:
                match = re.search(r'(\d{2}:\d{2}:\d{2})', line)
                if match:
                    self.results['start_time'] = match.group(1)
            
            if '✅ UNIFIED SCRAPER COMPLETE' in line:
                # Look backward for timestamp
                for j in range(max(0, i-10), i):
                    if match := re.search(r'(\d{2}:\d{2}:\d{2})', lines[j]):
                        self.results['end_time'] = match.group(1)
                        break
            
            # Scrape events
            if '✅ Scraped' in line:
                match = re.search(r'✅ Scraped r/(\w+)/(\w+): (\d+) new, (\d+) total \| Δ([\d.]+)/req', line)
                if match:
                    scrapes.append({
                        'subreddit': match.group(1),
                        'post_id': match.group(2),
                        'new_comments': int(match.group(3)),
                        'total_comments': int(match.group(4)),
                        'efficiency': float(match.group(5)),
                        'line': i
                    })
            
            # Deferral events
            if '⏸️  Insufficient budget' in line or 'Deferred:' in line:
                deferrals.append(i)
            
            # Discovery events
            if '🔍 r/' in line and 'Found' in line:
                match = re.search(r'🔍 r/(\w+): Found (\d+) new posts', line)
                if match:
                    discoveries[match.group(1)].append(int(match.group(2)))
            
            # Budget readings
            if 'Budget:' in line:
                match = re.search(r'Budget: ([\d.]+)/540', line)
                if match:
                    budget_readings.append({
                        'value': float(match.group(1)),
                        'line': i
                    })
            
            # Retirement events
            if '🗑️  Retired' in line:
                match = re.search(r'🗑️  Retired (\d+) dormant posts', line)
                if match:
                    retirements.append(int(match.group(1)))
            
            # Dormancy detection
            if 'dormant' in line.lower() and 'detected' in line.lower():
                dormancy_detections.append(i)
            
            # Depth distribution
            if 'Depth Distribution:' in line:
                # Parse next few lines
                shallow = medium = deep = 0
                for j in range(i+1, min(i+5, len(lines))):
                    if 'Shallow:' in lines[j]:
                        match = re.search(r'Shallow: (\d+)', lines[j])
                        if match: shallow = int(match.group(1))
                    elif 'Medium:' in lines[j]:
                        match = re.search(r'Medium: (\d+)', lines[j])
                        if match: medium = int(match.group(1))
                    elif 'Deep:' in lines[j]:
                        match = re.search(r'Deep: (\d+)', lines[j])
                        if match: deep = int(match.group(1))
                
                depth_distributions.append({
                    'shallow': shallow,
                    'medium': medium,
                    'deep': deep,
                    'line': i
                })
            
            # Recovery mode
            if '🔄 RECOVERY MODE' in line:
                recovery_mode_entries.append(i)
        
        # Store parsed data
        self.results['scrapes'] = scrapes
        self.results['deferrals'] = deferrals
        self.results['discoveries'] = dict(discoveries)
        self.results['budget_readings'] = budget_readings
        self.results['retirements'] = retirements
        self.results['dormancy_detections'] = dormancy_detections
        self.results['depth_distributions'] = depth_distributions
        self.results['recovery_mode_entries'] = recovery_mode_entries
        
        print(f"✅ Parsed {len(lines):,} lines")
        print(f"   Found {len(scrapes)} scrapes, {len(deferrals)} deferrals, {sum(retirements)} retirements")
    
    def analyze_scraping_performance(self):
        """Analyze overall scraping statistics"""
        print("\n📊 Analyzing scraping performance...")
        
        scrapes = self.results['scrapes']
        
        # Overall stats
        total_scrapes = len(scrapes)
        total_new_comments = sum(s['new_comments'] for s in scrapes)
        total_comments = sum(s['total_comments'] for s in scrapes[-1:])  # Last scrape has cumulative
        avg_efficiency = sum(s['efficiency'] for s in scrapes) / len(scrapes) if scrapes else 0
        
        # Subreddit breakdown
        by_subreddit = defaultdict(list)
        for s in scrapes:
            by_subreddit[s['subreddit']].append(s)
        
        return {
            'total_scrapes': total_scrapes,
            'total_new_comments': total_new_comments,
            'avg_efficiency': avg_efficiency,
            'subreddits_scraped': len(by_subreddit),
            'top_subreddits': sorted(
                [(sub, len(scrapes)) for sub, scrapes in by_subreddit.items()],
                key=lambda x: x[1],
                reverse=True
            )[:10]
        }
    
    def analyze_budget_management(self):
        """Analyze budget usage and management"""
        print("💰 Analyzing budget management...")
        
        readings = self.results['budget_readings']
        if not readings:
            return {'error': 'No budget readings found'}
        
        values = [r['value'] for r in readings]
        
        # Calculate statistics
        min_budget = min(values)
        max_budget = max(values)
        avg_budget = sum(values) / len(values)
        
        # Count critical moments
        critical_count = sum(1 for v in values if v < 10)
        zero_count = sum(1 for v in values if v == 0)
        
        return {
            'min_budget': min_budget,
            'max_budget': max_budget,
            'avg_budget': avg_budget,
            'critical_events': critical_count,
            'zero_budget_events': zero_count,
            'total_readings': len(readings)
        }
    
    def analyze_discovery(self):
        """Analyze discovery effectiveness"""
        print("🔍 Analyzing discovery patterns...")
        
        discoveries = self.results['discoveries']
        
        stats = {}
        for sub, counts in discoveries.items():
            total_polls = len(counts)
            total_posts = sum(counts)
            avg_per_poll = total_posts / total_polls if total_polls > 0 else 0
            max_in_poll = max(counts) if counts else 0
            maxed_out_count = sum(1 for c in counts if c == 25)
            
            stats[sub] = {
                'polls': total_polls,
                'total_posts': total_posts,
                'avg_per_poll': avg_per_poll,
                'max_in_poll': max_in_poll,
                'maxed_out': maxed_out_count
            }
        
        return stats
    
    def analyze_dormancy_system(self):
        """Analyze dormancy and retirement system behavior"""
        print("😴 Analyzing dormancy/retirement system...")
        
        retirements = self.results['retirements']
        
        return {
            'retirement_events': len(retirements),
            'total_posts_retired': sum(retirements),
            'avg_per_retirement': sum(retirements) / len(retirements) if retirements else 0,
            'max_retirement': max(retirements) if retirements else 0
        }
    
    def analyze_depth_patterns(self):
        """Analyze depth distribution over time"""
        print("📏 Analyzing depth patterns...")
        
        distributions = self.results['depth_distributions']
        if not distributions:
            return {'error': 'No depth distributions found'}
        
        # Aggregate
        total_shallow = sum(d['shallow'] for d in distributions)
        total_medium = sum(d['medium'] for d in distributions)
        total_deep = sum(d['deep'] for d in distributions)
        total = total_shallow + total_medium + total_deep
        
        return {
            'shallow_pct': (total_shallow / total * 100) if total > 0 else 0,
            'medium_pct': (total_medium / total * 100) if total > 0 else 0,
            'deep_pct': (total_deep / total * 100) if total > 0 else 0,
            'total_scrapes': total
        }
    
    def analyze_data_files(self):
        """Analyze the scraped data files"""
        print("📂 Analyzing scraped data files...")
        
        if not self.data_dir.exists():
            return {'error': f'Data directory {self.data_dir} not found'}
        
        # Count posts and scrapes
        post_dirs = [d for d in self.data_dir.iterdir() if d.is_dir()]
        total_posts = len(post_dirs)
        
        scrape_files = []
        total_size = 0
        
        for post_dir in post_dirs:
            raw_scrapes_dir = post_dir / 'raw_scrapes'
            if raw_scrapes_dir.exists():
                scrapes = list(raw_scrapes_dir.glob('scrape_*.json'))
                scrape_files.extend(scrapes)
                total_size += sum(f.stat().st_size for f in scrapes)
        
        return {
            'total_posts': total_posts,
            'total_scrape_files': len(scrape_files),
            'total_size_mb': total_size / 1024 / 1024,
            'avg_scrapes_per_post': len(scrape_files) / total_posts if total_posts > 0 else 0
        }
    
    def generate_report(self):
        """Generate comprehensive report"""
        print("\n" + "="*80)
        print("📋 24-HOUR ENDURANCE TEST - FINAL REPORT")
        print("="*80)
        
        self.parse_log()
        
        # Run all analyses
        scraping = self.analyze_scraping_performance()
        budget = self.analyze_budget_management()
        discovery = self.analyze_discovery()
        dormancy = self.analyze_dormancy_system()
        depth = self.analyze_depth_patterns()
        data_files = self.analyze_data_files()
        
        # Print report
        print("\n🎯 OVERALL PERFORMANCE")
        print("-" * 80)
        print(f"Duration: {self.results.get('start_time', 'Unknown')} → {self.results.get('end_time', 'Unknown')}")
        print(f"Total scrapes: {scraping['total_scrapes']:,}")
        print(f"New comments collected: {scraping['total_new_comments']:,}")
        print(f"Average efficiency: {scraping['avg_efficiency']:.3f} ΔInfo/req")
        print(f"Subreddits scraped: {scraping['subreddits_scraped']}")
        
        print("\n💰 BUDGET MANAGEMENT")
        print("-" * 80)
        print(f"Average budget: {budget.get('avg_budget', 0):.1f}/540")
        print(f"Min budget: {budget.get('min_budget', 0):.1f}")
        print(f"Critical events (<10): {budget.get('critical_events', 0)}")
        print(f"Zero budget events: {budget.get('zero_budget_events', 0)}")
        print(f"Recovery mode activations: {len(self.results['recovery_mode_entries'])}")
        
        print("\n🔍 DISCOVERY EFFECTIVENESS")
        print("-" * 80)
        total_discovered = sum(s['total_posts'] for s in discovery.values())
        print(f"Total posts discovered: {total_discovered:,}")
        print(f"Subreddits monitored: {len(discovery)}")
        
        # Show top discoverers
        top_discoverers = sorted(
            [(sub, stats['total_posts']) for sub, stats in discovery.items()],
            key=lambda x: x[1],
            reverse=True
        )[:5]
        print(f"\nTop discoverers:")
        for sub, count in top_discoverers:
            avg = discovery[sub]['avg_per_poll']
            print(f"  r/{sub}: {count} posts ({avg:.1f} avg/poll)")
        
        print("\n😴 DORMANCY & RETIREMENT")
        print("-" * 80)
        print(f"Retirement events: {dormancy['retirement_events']}")
        print(f"Posts retired: {dormancy['total_posts_retired']}")
        print(f"Avg per retirement: {dormancy['avg_per_retirement']:.1f}")
        
        print("\n📏 DEPTH DISTRIBUTION")
        print("-" * 80)
        print(f"Shallow (depth 1-3): {depth.get('shallow_pct', 0):.1f}%")
        print(f"Medium (depth 4-6): {depth.get('medium_pct', 0):.1f}%")
        print(f"Deep (depth 7+): {depth.get('deep_pct', 0):.1f}%")
        
        print("\n📂 DATA FILES")
        print("-" * 80)
        print(f"Posts tracked: {data_files['total_posts']:,}")
        print(f"Scrape files: {data_files['total_scrape_files']:,}")
        print(f"Total data size: {data_files['total_size_mb']:.2f} MB")
        print(f"Avg scrapes/post: {data_files['avg_scrapes_per_post']:.1f}")
        
        print("\n" + "="*80)
        
        # Return full results for JSON export
        return {
            'overview': {
                'start_time': self.results.get('start_time'),
                'end_time': self.results.get('end_time'),
                'log_lines': self.results['total_lines']
            },
            'scraping': scraping,
            'budget': budget,
            'discovery': discovery,
            'dormancy': dormancy,
            'depth': depth,
            'data_files': data_files
        }


if __name__ == '__main__':
    if len(sys.argv) < 3:
        print("Usage: python analyze_24h_results.py <log_file> <data_directory>")
        print("Example: python analyze_24h_results.py test_1440min_20251018_112237.log fix16cdf_24h_endurance")
        sys.exit(1)
    
    analyzer = EnduranceTestAnalyzer(sys.argv[1], sys.argv[2])
    results = analyzer.generate_report()
    
    # Save results to JSON
    output_file = 'analysis_results.json'
    with open(output_file, 'w') as f:
        json.dump(results, f, indent=2)
    
    print(f"\n💾 Full results saved to: {output_file}")

