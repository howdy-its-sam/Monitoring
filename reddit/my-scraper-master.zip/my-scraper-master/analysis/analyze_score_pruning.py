#!/usr/bin/env python3
"""
Analyze historical scrape data to estimate savings from score-based pruning.

Tests two variants of Option A:
- Depth >= 4: Prune when 2 consecutive score=1 at depth 4+
- Depth >= 5: Prune when 2 consecutive score=1 at depth 5+
"""

import json
import os
from pathlib import Path
from collections import defaultdict

def analyze_comment_tree(comment, depth=0, parent_score=None):
    """
    Recursively analyze a comment tree for pruning opportunities.
    
    Returns dict with:
    - total_comments: Total comments in this subtree
    - pruned_d4: Comments that would be pruned at depth>=4
    - pruned_d5: Comments that would be pruned at depth>=5
    - saved_d4: Estimated request savings at depth>=4
    - saved_d5: Estimated request savings at depth>=5
    """
    score = comment.get('score', 1)
    
    stats = {
        'total_comments': 1,
        'pruned_d4': 0,
        'pruned_d5': 0,
        'saved_d4': 0,
        'saved_d5': 0,
        'max_depth': depth
    }
    
    # Check if this subtree would be pruned
    would_prune_d4 = (depth >= 4 and parent_score == 1 and score == 1)
    would_prune_d5 = (depth >= 5 and parent_score == 1 and score == 1)
    
    # Get replies
    replies = comment.get('replies', [])
    
    # If pruned at d4, count entire subtree as saved
    if would_prune_d4:
        # Count all descendants
        subtree_size = count_subtree(comment)
        stats['pruned_d4'] = subtree_size
        stats['saved_d4'] = estimate_requests_saved(subtree_size, depth)
        # Still analyze for d5 (might not be pruned there)
    
    # If pruned at d5, count subtree
    if would_prune_d5 and not would_prune_d4:  # Only if not already pruned at d4
        subtree_size = count_subtree(comment)
        stats['pruned_d5'] = subtree_size
        stats['saved_d5'] = estimate_requests_saved(subtree_size, depth)
    
    # Recurse into replies (unless pruned at d4)
    if not would_prune_d4:
        for reply in replies:
            child_stats = analyze_comment_tree(reply, depth + 1, score)
            stats['total_comments'] += child_stats['total_comments']
            stats['pruned_d4'] += child_stats['pruned_d4']
            stats['pruned_d5'] += child_stats['pruned_d5']
            stats['saved_d4'] += child_stats['saved_d4']
            stats['saved_d5'] += child_stats['saved_d5']
            stats['max_depth'] = max(stats['max_depth'], child_stats['max_depth'])
    
    return stats

def count_subtree(comment):
    """Count total comments in a subtree."""
    count = 1  # This comment
    for reply in comment.get('replies', []):
        count += count_subtree(reply)
    return count

def estimate_requests_saved(num_comments, depth):
    """
    Estimate API requests saved by not fetching these comments.
    
    Deep comments often require 'more' expansions.
    Rough estimate: 1 request per 20 deep comments.
    """
    if num_comments == 0:
        return 0
    
    # Conservative estimate: 1 request per 15 comments at depth 4+
    # (More children objects need expansion at deeper levels)
    if depth >= 6:
        return max(1, num_comments // 10)  # Very deep: 1 req per 10 comments
    else:
        return max(1, num_comments // 20)  # Medium deep: 1 req per 20

def analyze_post(post_data):
    """Analyze a single post's comment tree."""
    total_stats = {
        'total_comments': 0,
        'pruned_d4': 0,
        'pruned_d5': 0,
        'saved_d4': 0,
        'saved_d5': 0,
        'max_depth': 0
    }
    
    # Analyze each top-level comment
    for comment in post_data.get('comments', []):
        comment_stats = analyze_comment_tree(comment, depth=1)
        for key in total_stats:
            if key == 'max_depth':
                total_stats[key] = max(total_stats[key], comment_stats[key])
            else:
                total_stats[key] += comment_stats[key]
    
    return total_stats

def find_latest_scrapes(base_dir):
    """
    Find the most recent scrape for each unique post.
    
    Returns dict: {post_id: path_to_latest_scrape}
    """
    latest_scrapes = {}
    
    # Walk through all post directories
    for post_dir in Path(base_dir).glob('*/raw_scrapes'):
        post_id = post_dir.parent.name
        
        # Find all scrapes for this post
        scrape_files = sorted(post_dir.glob('scrape_*.json'))
        
        if scrape_files:
            # Use the latest one (highest number/timestamp)
            latest_scrapes[post_id] = scrape_files[-1]
    
    return latest_scrapes

def main():
    """Analyze all historical data."""
    
    # Find all test directories with scraped data
    test_dirs = [
        'fix16_recovery_test',
        'fix16_recovery_16h',  # Current test
        'fix16_validation',
        'fix16_validation_v2'
    ]
    
    all_posts = {}
    
    # Collect latest scrapes from each test
    for test_dir in test_dirs:
        if os.path.exists(test_dir):
            latest = find_latest_scrapes(test_dir)
            print(f"Found {len(latest)} posts in {test_dir}")
            all_posts.update(latest)  # Later scrapes overwrite earlier ones
    
    print(f"\nAnalyzing {len(all_posts)} unique posts...\n")
    
    # Aggregate statistics
    global_stats = defaultdict(int)
    post_stats_list = []
    
    for post_id, scrape_path in sorted(all_posts.items()):
        try:
            with open(scrape_path, 'r') as f:
                post_data = json.load(f)
            
            stats = analyze_post(post_data)
            stats['post_id'] = post_id
            stats['total_comments'] = post_data.get('metadata', {}).get('total_comments', 0)
            post_stats_list.append(stats)
            
            # Aggregate
            for key in ['total_comments', 'pruned_d4', 'pruned_d5', 'saved_d4', 'saved_d5']:
                global_stats[key] += stats[key]
            global_stats['max_depth'] = max(global_stats['max_depth'], stats['max_depth'])
        
        except Exception as e:
            print(f"Error processing {post_id}: {e}")
            continue
    
    # Print results
    print("=" * 80)
    print("GLOBAL STATISTICS")
    print("=" * 80)
    print(f"Total unique posts analyzed: {len(post_stats_list)}")
    print(f"Total comments across all posts: {global_stats['total_comments']:,}")
    print(f"Maximum depth observed: {global_stats['max_depth']}")
    print()
    
    print("=" * 80)
    print("PRUNING ANALYSIS: DEPTH >= 4")
    print("=" * 80)
    print(f"Comments that would be pruned: {global_stats['pruned_d4']:,}")
    print(f"Percentage of total: {100 * global_stats['pruned_d4'] / max(1, global_stats['total_comments']):.2f}%")
    print(f"Estimated API requests saved: {global_stats['saved_d4']:,}")
    print()
    
    print("=" * 80)
    print("PRUNING ANALYSIS: DEPTH >= 5")
    print("=" * 80)
    print(f"Comments that would be pruned: {global_stats['pruned_d5']:,}")
    print(f"Percentage of total: {100 * global_stats['pruned_d5'] / max(1, global_stats['total_comments']):.2f}%")
    print(f"Estimated API requests saved: {global_stats['saved_d5']:,}")
    print()
    
    # Show top posts that would benefit most
    print("=" * 80)
    print("TOP 10 POSTS WITH MOST SAVINGS (Depth >= 4)")
    print("=" * 80)
    top_d4 = sorted(post_stats_list, key=lambda x: x['saved_d4'], reverse=True)[:10]
    for i, stats in enumerate(top_d4, 1):
        print(f"{i:2}. {stats['post_id']}: {stats['saved_d4']} requests saved "
              f"({stats['pruned_d4']}/{stats['total_comments']} comments pruned, "
              f"max_depth={stats['max_depth']})")
    print()
    
    print("=" * 80)
    print("TOP 10 POSTS WITH MOST SAVINGS (Depth >= 5)")
    print("=" * 80)
    top_d5 = sorted(post_stats_list, key=lambda x: x['saved_d5'], reverse=True)[:10]
    for i, stats in enumerate(top_d5, 1):
        print(f"{i:2}. {stats['post_id']}: {stats['saved_d5']} requests saved "
              f"({stats['pruned_d5']}/{stats['total_comments']} comments pruned, "
              f"max_depth={stats['max_depth']})")
    print()
    
    # Calculate estimated throughput improvements
    print("=" * 80)
    print("ESTIMATED THROUGHPUT IMPACT")
    print("=" * 80)
    
    # From 15-min test: 186 scrapes, ~1100 requests
    baseline_scrapes = 186
    baseline_requests = 1100  # Estimated from test
    
    improvement_d4 = (global_stats['saved_d4'] / max(1, baseline_requests)) * baseline_scrapes
    improvement_d5 = (global_stats['saved_d5'] / max(1, baseline_requests)) * baseline_scrapes
    
    print(f"Baseline (15-min test): {baseline_scrapes} scrapes in 15 min")
    print(f"Estimated total requests: ~{baseline_requests}")
    print()
    print(f"With Depth >= 4 pruning:")
    print(f"  Requests saved: ~{global_stats['saved_d4']}")
    print(f"  Additional scrapes possible: ~{improvement_d4:.0f}")
    print(f"  New throughput: ~{(baseline_scrapes + improvement_d4) / 15:.1f} scrapes/min "
          f"(+{100 * improvement_d4 / baseline_scrapes:.1f}%)")
    print()
    print(f"With Depth >= 5 pruning:")
    print(f"  Requests saved: ~{global_stats['saved_d5']}")
    print(f"  Additional scrapes possible: ~{improvement_d5:.0f}")
    print(f"  New throughput: ~{(baseline_scrapes + improvement_d5) / 15:.1f} scrapes/min "
          f"(+{100 * improvement_d5 / baseline_scrapes:.1f}%)")
    
    # Save detailed results
    output_file = 'score_pruning_analysis.json'
    with open(output_file, 'w') as f:
        json.dump({
            'global_stats': dict(global_stats),
            'post_stats': post_stats_list,
            'analysis_params': {
                'depth_4_threshold': 4,
                'depth_5_threshold': 5,
                'prune_rule': 'parent_score==1 AND current_score==1'
            }
        }, f, indent=2)
    print(f"\n💾 Detailed results saved to: {output_file}")

if __name__ == '__main__':
    main()

