#!/usr/bin/env python3
"""
Analyze potential savings from consecutive low-score comment pruning.

Tests multiple pruning strategies:
- Stop after 2 consecutive comments with score == 1
- Stop after 2 consecutive comments with score <= 2
- Stop after 2 consecutive comments with score <= 3
- ... and so on for configurable thresholds

For each strategy, calculate:
- Total requests saved
- Total comments pruned
- Percentage of data lost
- Distribution of pruning events by depth
"""

import json
import sys
from pathlib import Path
from typing import Dict, List, Tuple, Any, Set
from collections import defaultdict, Counter


def is_deleted(node: Dict[str, Any]) -> bool:
    """Check if comment is deleted/removed."""
    author = node.get("author", "")
    body = node.get("body", "")
    return author in ("[deleted]", "[removed]") or body in ("[deleted]", "[removed]")


def get_score(node: Dict[str, Any], deleted_as_one: bool = False) -> int:
    """
    Extract score from a comment node.
    
    Tries score_history first (most recent), then score/ups fields.
    """
    score = None
    
    # Try score_history first (our format)
    if "score_history" in node and isinstance(node["score_history"], list) and node["score_history"]:
        try:
            score = int(node["score_history"][-1][0])
        except Exception:
            pass
    
    # Fall back to direct score/ups fields
    if score is None:
        for key in ("score", "ups"):
            if key in node:
                try:
                    score = int(node[key])
                    break
                except Exception:
                    pass
    
    # Default to 0 if no score found
    if score is None:
        score = 0
    
    # Optionally treat deleted as score=1
    if deleted_as_one and is_deleted(node):
        return 1
    
    return score


def count_descendants(node: Dict[str, Any]) -> int:
    """Count total descendants (children + their descendants) of a node."""
    replies = node.get("replies", [])
    if not replies:
        return 0
    
    count = len(replies)
    for child in replies:
        count += count_descendants(child)
    
    return count


def analyze_pruning_strategy(
    root_node: Dict[str, Any],
    max_score: int,
    consecutive_required: int = 2,
    min_depth: int = 0,
    deleted_as_one: bool = False
) -> Dict[str, Any]:
    """
    Simulate pruning strategy and calculate savings.
    
    Args:
        root_node: Root of comment tree
        max_score: Maximum score to consider for pruning (e.g., 1 = score==1, 2 = score<=2)
        consecutive_required: Number of consecutive low-score comments needed to trigger pruning
        min_depth: Minimum depth before pruning can occur (0 = any depth)
        deleted_as_one: Treat deleted comments as score=1
    
    Returns:
        Dict with pruning statistics
    """
    stats = {
        "requests_saved": 0,
        "comments_pruned": 0,
        "pruning_events": 0,
        "pruning_by_depth": Counter(),
        "score_history_at_prune": [],  # Track what scores triggered each prune
    }
    
    def traverse(node: Dict[str, Any], depth: int, parent_chain_scores: List[int]):
        """
        Recursively traverse tree, tracking DIRECT parent→child chain scores.
        
        Args:
            node: Current comment node
            depth: Current depth in tree
            parent_chain_scores: Scores of direct ancestors in the chain (not siblings!)
        """
        score = get_score(node, deleted_as_one)
        
        # Check if we should prune at this node
        # We need consecutive_required scores IN A ROW down the parent→child chain
        if depth >= min_depth and len(parent_chain_scores) >= consecutive_required - 1:
            # We have enough parent scores to check
            # Check: last (consecutive_required - 1) parents + current node
            check_scores = parent_chain_scores[-(consecutive_required - 1):] + [score]
            
            # Prune if all scores in this direct chain are <= max_score
            if all(s <= max_score for s in check_scores):
                # Calculate savings from pruning here
                descendants = count_descendants(node)
                stats["requests_saved"] += descendants  # 1 request per comment
                stats["comments_pruned"] += descendants
                stats["pruning_events"] += 1
                stats["pruning_by_depth"][depth] += 1
                stats["score_history_at_prune"].append(check_scores.copy())
                
                # Don't traverse children - they're pruned
                return
        
        # Continue traversing children
        # IMPORTANT: Pass the chain scores (parent path), NOT including siblings!
        replies = node.get("replies", [])
        new_chain = parent_chain_scores + [score]
        for child in replies:
            traverse(child, depth + 1, new_chain)
    
    # Start traversal from root's children
    replies = root_node.get("replies", [])
    if not replies and "comments" in root_node:
        # Handle flat comment structure
        replies = root_node["comments"]
    
    for child in replies:
        traverse(child, depth=0, parent_chain_scores=[])
    
    return stats


def load_json_file(filepath: Path) -> Any:
    """Load JSON file, handling errors gracefully."""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        print(f"⚠️  Error loading {filepath}: {e}", file=sys.stderr)
        return None


def find_all_json_files(base_dir: Path) -> List[Path]:
    """Find all JSON files in directory tree, excluding duplicates."""
    json_files = []
    seen_names = set()
    
    # Look in common directories
    search_dirs = [
        base_dir / "scraped_posts",
        base_dir / "fix16cdf_24h_endurance",
        base_dir / "fix16cdf_2h_test",
        base_dir / "fix16_12h_test",
        base_dir / "fix16_recovery_16h",
        base_dir / "fix16_validation",
        base_dir / "fix16_validation_v2",
    ]
    
    for search_dir in search_dirs:
        if not search_dir.exists():
            continue
        
        # Find all .json files recursively
        for json_file in search_dir.rglob("*.json"):
            # Skip if we've seen this post ID before (avoid duplicates)
            name = json_file.stem
            
            # Extract post ID if in filename
            if "_" in name:
                parts = name.split("_")
                for part in parts:
                    if len(part) == 7 and part[0] == "1":  # Reddit post ID format
                        if part in seen_names:
                            continue  # Skip duplicate
                        seen_names.add(part)
                        break
            
            json_files.append(json_file)
    
    return json_files


def parse_root_node(data: Any) -> Dict[str, Any]:
    """
    Parse various JSON formats to extract root node.
    
    Handles:
    - Direct comment tree with "replies"
    - Wrapped in "post" key
    - Flat "comments" list at root
    """
    if isinstance(data, dict):
        # Check for flat comments at root (our standard format)
        if "comments" in data and isinstance(data["comments"], list):
            # Wrap in pseudo-root with "replies" for consistent traversal
            return {"replies": data["comments"]}
        
        # Check for wrapped format
        if "post" in data and isinstance(data["post"], dict):
            post_data = data["post"]
            # Check if post has replies
            if "replies" in post_data:
                return post_data
            # Check if post has comments
            if "comments" in post_data:
                return {"replies": post_data["comments"]}
        
        # Already a valid root node with replies
        if "replies" in data:
            return data
    
    # Return empty dict if can't parse
    return {}


def main():
    print("🔍 Analyzing Consecutive Low-Score Comment Pruning Strategies\n")
    print("=" * 80)
    
    # Find all JSON files
    base_dir = Path(__file__).parent
    json_files = find_all_json_files(base_dir)
    
    print(f"\n📁 Found {len(json_files)} JSON files to analyze")
    
    # Define strategies to test
    strategies = [
        # (max_score, consecutive_required, min_depth, name)
        (1, 2, 0, "2 consecutive score=1 (any depth)"),
        (1, 2, 3, "2 consecutive score=1 (depth ≥3)"),
        (1, 2, 4, "2 consecutive score=1 (depth ≥4)"),
        (1, 2, 5, "2 consecutive score=1 (depth ≥5)"),
        (2, 2, 0, "2 consecutive score≤2 (any depth)"),
        (2, 2, 3, "2 consecutive score≤2 (depth ≥3)"),
        (2, 2, 4, "2 consecutive score≤2 (depth ≥4)"),
        (2, 2, 5, "2 consecutive score≤2 (depth ≥5)"),
        (3, 2, 0, "2 consecutive score≤3 (any depth)"),
        (3, 2, 4, "2 consecutive score≤3 (depth ≥4)"),
        (3, 2, 5, "2 consecutive score≤3 (depth ≥5)"),
        (1, 3, 4, "3 consecutive score=1 (depth ≥4)"),
        (1, 3, 5, "3 consecutive score=1 (depth ≥5)"),
        (2, 3, 4, "3 consecutive score≤2 (depth ≥4)"),
        (2, 3, 5, "3 consecutive score≤2 (depth ≥5)"),
    ]
    
    # Track results for each strategy
    results = {name: defaultdict(int) for _, _, _, name in strategies}
    files_processed = 0
    files_with_comments = 0
    total_comments_analyzed = 0
    
    # Process each file
    for filepath in json_files:
        data = load_json_file(filepath)
        if data is None:
            continue
        
        files_processed += 1
        
        # Parse root node
        root_node = parse_root_node(data)
        if not root_node:
            continue
        
        # Count comments in this file
        comment_count = count_descendants(root_node)
        if comment_count == 0:
            continue
        
        files_with_comments += 1
        total_comments_analyzed += comment_count
        
        # Test each strategy
        for max_score, consecutive, min_depth, name in strategies:
            stats = analyze_pruning_strategy(
                root_node,
                max_score=max_score,
                consecutive_required=consecutive,
                min_depth=min_depth,
                deleted_as_one=False
            )
            
            results[name]["requests_saved"] += stats["requests_saved"]
            results[name]["comments_pruned"] += stats["comments_pruned"]
            results[name]["pruning_events"] += stats["pruning_events"]
            
            # Merge depth counters
            for depth, count in stats["pruning_by_depth"].items():
                results[name][f"depth_{depth}"] += count
    
    print(f"✅ Processed {files_processed} files ({files_with_comments} with comments)")
    print(f"📊 Total comments analyzed: {total_comments_analyzed:,}\n")
    print("=" * 80)
    
    # Display results sorted by requests saved
    sorted_strategies = sorted(
        strategies,
        key=lambda x: results[x[3]]["requests_saved"],
        reverse=True
    )
    
    print("\n📈 RESULTS (sorted by requests saved):\n")
    
    for max_score, consecutive, min_depth, name in sorted_strategies:
        r = results[name]
        requests_saved = r["requests_saved"]
        comments_pruned = r["comments_pruned"]
        pruning_events = r["pruning_events"]
        
        # Calculate percentages
        pct_comments = (comments_pruned / max(1, total_comments_analyzed)) * 100
        pct_requests = (requests_saved / max(1, total_comments_analyzed)) * 100
        
        print(f"\n{'─' * 80}")
        print(f"Strategy: {name}")
        print(f"{'─' * 80}")
        print(f"  💾 Requests saved:     {requests_saved:>6,} ({pct_requests:>5.2f}% of total)")
        print(f"  🗑️  Comments pruned:    {comments_pruned:>6,} ({pct_comments:>5.2f}% of corpus)")
        print(f"  ✂️  Pruning events:     {pruning_events:>6,}")
        
        if pruning_events > 0:
            avg_pruned_per_event = comments_pruned / pruning_events
            print(f"  📊 Avg pruned/event:   {avg_pruned_per_event:>6.1f} comments")
            
            # Show depth distribution
            depth_counts = [(int(k.split("_")[1]), v) for k, v in r.items() if k.startswith("depth_")]
            if depth_counts:
                depth_counts.sort()
                print(f"  📏 Pruning by depth:")
                for depth, count in depth_counts[:10]:  # Show top 10 depths
                    pct = (count / pruning_events) * 100
                    print(f"      Depth {depth:>2}: {count:>4} events ({pct:>5.1f}%)")
    
    print("\n" + "=" * 80)
    print("\n💡 RECOMMENDATIONS:\n")
    
    # Find best strategy with <5% data loss
    best_conservative = None
    best_aggressive = None
    
    for max_score, consecutive, min_depth, name in sorted_strategies:
        r = results[name]
        pct_loss = (r["comments_pruned"] / max(1, total_comments_analyzed)) * 100
        
        if pct_loss < 5 and (best_conservative is None or r["requests_saved"] > results[best_conservative[3]]["requests_saved"]):
            best_conservative = (max_score, consecutive, min_depth, name)
        
        if pct_loss < 15 and (best_aggressive is None or r["requests_saved"] > results[best_aggressive[3]]["requests_saved"]):
            best_aggressive = (max_score, consecutive, min_depth, name)
    
    if best_conservative:
        name = best_conservative[3]
        r = results[name]
        pct = (r["comments_pruned"] / max(1, total_comments_analyzed)) * 100
        print(f"🎯 Best Conservative Strategy (<5% data loss):")
        print(f"   {name}")
        print(f"   Saves: {r['requests_saved']:,} requests ({pct:.2f}% data loss)")
    
    if best_aggressive and best_aggressive != best_conservative:
        name = best_aggressive[3]
        r = results[name]
        pct = (r["comments_pruned"] / max(1, total_comments_analyzed)) * 100
        print(f"\n⚡ Best Aggressive Strategy (<15% data loss):")
        print(f"   {name}")
        print(f"   Saves: {r['requests_saved']:,} requests ({pct:.2f}% data loss)")
    
    print("\n" + "=" * 80)
    
    # Save detailed results to file
    output_file = base_dir / "consecutive_score_pruning_analysis.json"
    output_data = {
        "metadata": {
            "files_processed": files_processed,
            "files_with_comments": files_with_comments,
            "total_comments": total_comments_analyzed,
        },
        "strategies": {}
    }
    
    for max_score, consecutive, min_depth, name in strategies:
        output_data["strategies"][name] = {
            "config": {
                "max_score": max_score,
                "consecutive_required": consecutive,
                "min_depth": min_depth,
            },
            "results": dict(results[name])
        }
    
    with open(output_file, 'w') as f:
        json.dump(output_data, f, indent=2)
    
    print(f"\n💾 Detailed results saved to: {output_file}")
    print()


if __name__ == "__main__":
    main()

