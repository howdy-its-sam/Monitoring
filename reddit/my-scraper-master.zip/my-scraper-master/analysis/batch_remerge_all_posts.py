#!/usr/bin/env python3
"""
Batch Re-merge All Posts with Fixed text_history Logic

Processes all posts in fix16cdf_24h_endurance/ and creates properly merged files.
"""

import json
from pathlib import Path
from fix_text_history_merge import merge_temporal_scrapes_fixed, count_edits_in_merged


def main():
    source_dir = Path('fix16cdf_24h_endurance')
    output_dir = Path('24h_final_report/scraped_data/merged_v2')
    
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Get all post directories
    post_dirs = sorted([d for d in source_dir.iterdir() if d.is_dir()])
    
    print("="*70)
    print("BATCH RE-MERGE WITH FIXED text_history LOGIC")
    print("="*70)
    print(f"Source: {source_dir}")
    print(f"Output: {output_dir}")
    print(f"Posts to process: {len(post_dirs)}")
    print()
    
    # Statistics
    total_posts = len(post_dirs)
    processed = 0
    failed = 0
    total_comments = 0
    total_edits = 0
    
    for i, post_dir in enumerate(post_dirs, 1):
        post_id = post_dir.name
        
        print(f"[{i}/{total_posts}] Processing {post_id}...")
        
        try:
            merged_data = merge_temporal_scrapes_fixed(post_dir)
            
            if not merged_data:
                print(f"  ⚠️  Skipped (no data)")
                continue
            
            # Save merged file
            output_file = output_dir / f'{post_id}_merged.json'
            with open(output_file, 'w') as f:
                json.dump(merged_data, f, indent=2)
            
            # Collect statistics
            edit_count = count_edits_in_merged(merged_data)
            comment_count = merged_data['metadata']['merge_info']['unique_comments']
            
            total_comments += comment_count
            total_edits += edit_count
            processed += 1
            
            if edit_count > 0:
                print(f"  ✅ {comment_count} comments, {edit_count} with edits")
            
            # Progress update every 50 posts
            if i % 50 == 0:
                print()
                print(f"Progress: {processed}/{total_posts} posts")
                print(f"  Total comments: {total_comments:,}")
                print(f"  Total edits captured: {total_edits}")
                print()
        
        except Exception as e:
            print(f"  ❌ Error: {e}")
            failed += 1
    
    # Final summary
    print()
    print("="*70)
    print("BATCH MERGE COMPLETE")
    print("="*70)
    print(f"Posts processed: {processed}/{total_posts}")
    print(f"Failed: {failed}")
    print(f"Total comments: {total_comments:,}")
    print(f"Comments with edits: {total_edits}")
    print(f"Edit rate: {total_edits/total_comments*100 if total_comments > 0 else 0:.3f}%")
    print()
    print(f"Output location: {output_dir}/")
    print("="*70)


if __name__ == '__main__':
    import sys
    
    response = input("This will re-merge all 687 posts (~10-15 minutes). Continue? (y/n): ")
    if response.lower() != 'y':
        print("Aborted.")
        sys.exit(0)
    
    main()

