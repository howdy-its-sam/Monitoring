#!/usr/bin/env python3
"""
Bootstrap Scheduler from Existing Merged Data
Initializes PostState objects from final_merged.json files.
"""

import os
import json
from datetime import datetime, timezone
from adaptive_scheduler import AdaptiveScheduler
from info_gain_analytics import compute_delta_info, estimate_lambda_from_curve
from temperature_scheduler import ScrapeDelta, hours_between


def bootstrap_from_merged_data(scheduler: AdaptiveScheduler, temporal_dir: str = "temporal_test"):
    """
    Initialize scheduler PostState from existing merged data.
    
    This allows the scheduler to "warm start" with historical information.
    
    Args:
        scheduler: AdaptiveScheduler instance
        temporal_dir: Directory containing merged post data
    """
    if not os.path.exists(temporal_dir):
        print(f"⚠️  Directory not found: {temporal_dir}")
        return
    
    posts_initialized = 0
    total_dirs = len([d for d in os.listdir(temporal_dir) if os.path.isdir(os.path.join(temporal_dir, d))])
    current = 0
    
    for post_id in sorted(os.listdir(temporal_dir)):
        post_dir = os.path.join(temporal_dir, post_id)
        if not os.path.isdir(post_dir):
            continue
        
        current += 1
        
        merged_file = os.path.join(post_dir, "final_merged.json")
        if not os.path.exists(merged_file):
            continue
        
        print(f"  [{current}/{total_dirs}] Loading {post_id}...", end=' ', flush=True)
        
        try:
            with open(merged_file, 'r') as f:
                data = json.load(f)
            
            # Extract post URL
            url = data.get('metadata', {}).get('source_url', f'https://reddit.com/r/news/comments/{post_id}/')
            
            # Compute ΔInfo timeline
            per_ts, timeline = compute_delta_info(data)
            
            if not timeline:
                continue
            
            # Create PostState
            post = scheduler.posts.get(post_id)
            if not post:
                # Post not in scheduler yet, add it
                subreddit = "news"  # Default, could parse from URL
                post = scheduler.add_post(post_id, url, subreddit)
            
            # Populate deltas from timeline
            post.deltas = []
            for ts in timeline:
                d = per_ts[ts]
                delta = ScrapeDelta(
                    ts=ts,
                    new_comments=d['new_comments'],
                    edited_comments=d['edited_comments'],
                    score_changed=d['score_changed'],
                    deleted_comments=d['deleted_comments']
                )
                post.deltas.append(delta)
            
            # Set timestamps
            post.last_scrape_ts = timeline[-1]
            
            # Find last non-zero delta
            for ts in reversed(timeline):
                if per_ts[ts]['delta_info'] > 0:
                    post.last_nonzero_ts = ts
                    break
            
            # Estimate lambda
            deltas_weighted = [per_ts[ts]['delta_info'] for ts in timeline]
            lambda_est = estimate_lambda_from_curve(timeline, deltas_weighted)
            if lambda_est is not None:
                post.lambda_hat = lambda_est
            
            posts_initialized += 1
            
            # Update scheduler total metrics
            scheduler.total_scrapes += len(timeline)
            scheduler.total_delta_info += sum(deltas_weighted)
            
            print(f"✓ ({len(timeline)} scrapes, λ={lambda_est:.3f})" if lambda_est else f"✓ ({len(timeline)} scrapes)")
            
        except Exception as e:
            print(f"✗ Error: {e}")
            continue
    
    print()
    print(f"✅ Initialized {posts_initialized} posts from merged data")
    print(f"   ├─ Total historical scrapes: {scheduler.total_scrapes}")
    print(f"   ├─ Total historical ΔInfo: {scheduler.total_delta_info:.1f}")
    print(f"   └─ Avg ΔInfo/scrape: {scheduler.total_delta_info/scheduler.total_scrapes if scheduler.total_scrapes > 0 else 0:.2f}")


if __name__ == '__main__':
    print("="*80)
    print("🔄 BOOTSTRAP SCHEDULER FROM MERGED DATA")
    print("="*80)
    print()
    
    scheduler = AdaptiveScheduler()
    bootstrap_from_merged_data(scheduler)
    
    print()
    
    # Display status
    status = scheduler.get_status()
    print("="*80)
    print("SCHEDULER STATUS")
    print("="*80)
    for key, val in status.items():
        if key != "controller":
            print(f"{key}: {val}")
    print()
    
    # Show top posts by temperature
    now = datetime.now(timezone.utc)
    queue = scheduler.control_tick(now)
    
    print("="*80)
    print("TOP 10 POSTS BY PRIORITY")
    print("="*80)
    print()
    
    for i, entry in enumerate(sorted(queue)[:10], 1):
        post = scheduler.posts[entry.post_id]
        hours_overdue = hours_between(now, entry.next_time)
        status_str = f"+{hours_overdue:.1f}h late" if hours_overdue > 0 else f"{-hours_overdue:.1f}h early"
        
        print(f"{i:2d}. {post.post_id}")
        print(f"    ├─ T={post.temperature:.3f}, λ={post.lambda_hat:.3f}, Δt={post.interval_hours:.1f}h")
        print(f"    ├─ Recent rate: {post.recent_rate:.1f} ΔInfo/h")
        print(f"    └─ Status: {status_str}")
        print()
    
    print("="*80)
    
    # Save state
    scheduler._save_state()
    print("💾 Scheduler state saved to temporal_test/*/scheduler_state.json")
    print()

