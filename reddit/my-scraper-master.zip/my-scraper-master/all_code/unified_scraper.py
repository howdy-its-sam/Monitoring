#!/usr/bin/env python3
"""
Unified Adaptive Reddit Scraper
Complete production system integrating all components.
Based on reference_books/architecture.md - Full Implementation
"""

import time
import os
import re
import json
from datetime import datetime, timezone, timedelta
from typing import Dict, Optional, Set
from collections import deque

from reddit_scraper_api import scrape_reddit_post_api, get_request_count
from reddit_auth import get_authenticated_session
from adaptive_scheduler import AdaptiveScheduler
from temperature_scheduler import ScrapeDelta
from info_gain_analytics import compute_delta_info, collect_nodes
from bootstrap_scheduler_from_merged import bootstrap_from_merged_data
from coverage_allocator import PriorityCoverageAllocator
from discovery_poller import DiscoveryPoller, DiscoveredPost
from depth_advisor import DepthAdvisor, SHALLOW, MEDIUM, DEEP
from telemetry import TelemetryCollector
from subreddit_priors import SubredditPriors


def extract_post_id(url: str) -> Optional[str]:
    """Extract Reddit post ID from URL"""
    match = re.search(r'/comments/([^/]+)/', url)
    return match.group(1) if match else None


def extract_subreddit(url: str) -> str:
    """Extract subreddit from URL"""
    match = re.search(r'/r/([^/]+)/', url)
    return match.group(1) if match else "news"


def compute_scrape_delta(post_id: str, current_data: dict, 
                        previous_data: Optional[dict] = None) -> ScrapeDelta:
    """
    Compute ΔInfo from a scrape by comparing with previous scrape.
    """
    now = datetime.now(timezone.utc)
    
    if previous_data is None:
        # First scrape - count all as new
        nodes = collect_nodes(current_data)
        comment_count = len([n for (kind, n) in nodes if kind == "comment"])
        
        return ScrapeDelta(
            ts=now,
            new_comments=comment_count,
            edited_comments=0,
            score_changed=0,
            deleted_comments=0
        )
    
    # Compute detailed ΔInfo
    prev_nodes = {n.get('id'): n for (_, n) in collect_nodes(previous_data) if n.get('id')}
    curr_nodes = {n.get('id'): n for (_, n) in collect_nodes(current_data) if n.get('id')}
    
    new_comments = len(set(curr_nodes.keys()) - set(prev_nodes.keys()))
    deleted_comments = len(set(prev_nodes.keys()) - set(curr_nodes.keys()))
    
    edited_comments = 0
    score_changed = 0
    
    for node_id in set(curr_nodes.keys()) & set(prev_nodes.keys()):
        curr = curr_nodes[node_id]
        prev = prev_nodes[node_id]
        
        if curr.get('score', 0) != prev.get('score', 0):
            score_changed += 1
        
        if curr.get('body', '') != prev.get('body', ''):
            edited_comments += 1
    
    return ScrapeDelta(
        ts=now,
        new_comments=new_comments,
        edited_comments=edited_comments,
        score_changed=score_changed,
        deleted_comments=deleted_comments
    )


class UnifiedScraper:
    """
    Complete adaptive scraping system.
    
    Integrates:
    - Multi-subreddit discovery with priority-based coverage
    - Continuous temperature scheduling
    - Adaptive depth selection
    - Rate-limit control with EMA feedback
    - Comprehensive telemetry and alerting
    """
    
    def __init__(self,
                 target_rps: float = 10.0,
                 priorities_file: str = 'subreddit_priorities.txt',
                 temporal_dir: str = 'temporal_test',
                 skip_bootstrap: bool = False):
        """
        Initialize unified scraper.
        
        Args:
            target_rps: Target API requests per second (default 10.0 = 600/min)
            priorities_file: Path to subreddit priorities file
            temporal_dir: Directory for storing scrape data
            skip_bootstrap: If True, skip loading historical data (faster startup)
        """
        self.target_rps = target_rps
        self.temporal_dir = temporal_dir
        self.skip_bootstrap = skip_bootstrap
        
        # Initialize components
        print("🚀 Initializing Unified Adaptive Scraper...")
        print()
        
        # 1. Coverage allocator
        print("📊 Loading subreddit priorities...")
        self.allocator = PriorityCoverageAllocator(budget_rps=target_rps)
        self.allocator.load_from_file(priorities_file)
        self.allocator.compute_coverage_fractions(global_gain=1.0)
        print()
        
        # 2. OAuth authentication
        print("🔐 Authenticating...")
        self.session = get_authenticated_session()
        if self.session:
            print("✅ OAuth authenticated")
        else:
            print("⚠️  Running without authentication")
        print()
        
        # 3. Scheduler
        print("🧠 Initializing scheduler...")
        self.scheduler = AdaptiveScheduler(
            target_rps=target_rps,
            lateness_setpoint=0.15,
            state_dir=temporal_dir
        )
        print()
        
        # 4. Discovery poller
        print("🔍 Initializing discovery poller...")
        self.poller = DiscoveryPoller(self.allocator, self.session)
        print()
        
        # 5. Depth advisor
        print("📏 Initializing depth advisor...")
        self.depth_advisor = DepthAdvisor()
        print()
        
        # 6. Telemetry
        print("📊 Initializing telemetry...")
        self.telemetry = TelemetryCollector()
        print()
        
        # 7. Subreddit priors (for new posts)
        self.priors = SubredditPriors()
        
        # Track previous scrape data
        self.previous_data: Dict[str, Optional[dict]] = {}
        
        # Track posts scraped in last 6h (for coverage metric)
        self.recent_scrapes: deque = deque(maxlen=500)
        
        # Track discovered posts not yet added
        self.pending_additions: Set[str] = set()
        
        print("✅ All components initialized")
        print()
    
    def run(self, duration_minutes: int = 60):
        """
        Main control loop.
        
        Args:
            duration_minutes: How long to run (default 60 minutes)
        """
        print("="*80)
        print("🌐 UNIFIED ADAPTIVE SCRAPER - STARTING")
        print("="*80)
        print(f"  ├─ Target: {self.target_rps} rps ({self.target_rps*60:.0f}/min)")
        print(f"  ├─ Duration: {duration_minutes} minutes")
        print(f"  ├─ Subreddits: {len(self.allocator.rank_order)}")
        print(f"  └─ Temporal dir: {self.temporal_dir}")
        print()
        
        # Bootstrap from existing data (unless skipped)
        if not self.skip_bootstrap:
            print("🔄 Bootstrapping from historical data...")
            bootstrap_from_merged_data(self.scheduler, self.temporal_dir)
            print()
        else:
            print("⏩ Skipping bootstrap (fresh start)")
            print()
        
        # Calculate end time
        start_time = time.time()
        end_time = start_time + (duration_minutes * 60)
        
        print(f"🚀 Starting at {datetime.now().strftime('%H:%M:%S')}")
        print(f"🏁 Will stop at {datetime.fromtimestamp(end_time).strftime('%H:%M:%S')}")
        print("="*80)
        print()
        
        # API request tracking
        prev_request_count = get_request_count()
        last_telemetry_time = time.time()
        telemetry_interval = 60  # Log every minute
        
        # Discovery tracking
        last_discovery_time = 0
        
        # Main loop
        while time.time() < end_time:
            now = datetime.now(timezone.utc)
            loop_start = time.time()
            
            # === DISCOVERY PHASE ===
            # Check if any subreddits are due for polling
            if time.time() - last_discovery_time > 60:  # Check every minute
                new_posts = self.poller.poll_all_due(global_gain=self.scheduler.controller.g)
                
                for discovered in new_posts:
                    # Apply coverage fraction filter (probabilistic sampling)
                    if self.allocator.should_scrape_post(discovered.subreddit):
                        # Add to scheduler
                        post = self.scheduler.add_post(
                            discovered.post_id,
                            discovered.url,
                            discovered.subreddit
                        )
                        
                        # Initialize with subreddit prior
                        post.lambda_hat = self.priors.get_lambda(discovered.subreddit)
                        
                        self.pending_additions.add(discovered.post_id)
                
                last_discovery_time = time.time()
            
            # === SCHEDULING PHASE ===
            # Measure actual API request rate
            current_request_count = get_request_count()
            tick_duration = time.time() - loop_start
            
            if tick_duration > 0:
                requests_this_tick = current_request_count - prev_request_count
                instantaneous_rps = requests_this_tick / tick_duration
            else:
                instantaneous_rps = 0.0
            
            # Update coverage fractions based on current gain
            self.allocator.compute_coverage_fractions(
                global_gain=self.scheduler.controller.g,
                current_rps=instantaneous_rps
            )
            
            # Run scheduler control tick
            queue = self.scheduler.control_tick(now, instantaneous_rps=instantaneous_rps)
            
            # Get next post to scrape
            ready_posts = self.scheduler.get_next_posts(limit=1)
            
            if not ready_posts:
                # Nothing ready, wait briefly
                time.sleep(0.5)
                prev_request_count = current_request_count
                continue
            
            post_id = ready_posts[0]
            post = self.scheduler.posts[post_id]
            
            # === SCRAPING PHASE ===
            # Get depth mode
            depth_mode = self.depth_advisor.get_depth_mode(post_id)
            
            # Display status
            elapsed_mins = (time.time() - start_time) / 60
            remaining_mins = (end_time - time.time()) / 60
            
            print(f"[{elapsed_mins:.0f}:{remaining_mins:.0f}] "
                  f"🎯 {post_id} r/{post.subreddit} "
                  f"(T={post.temperature:.2f}, depth={depth_mode.name})...")
            
            # Prepare output
            post_dir = f'{self.temporal_dir}/{post_id}/raw_scrapes'
            os.makedirs(post_dir, exist_ok=True)
            
            existing_scrapes = [f for f in os.listdir(post_dir) 
                              if f.startswith('scrape_') and f.endswith('.json')]
            scrape_num = len(existing_scrapes) + 1
            
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            output_file = f'{post_dir}/scrape_{scrape_num:03d}_{timestamp}.json'
            
            # Scrape with appropriate session
            try:
                result = scrape_reddit_post_api(
                    post.url, 
                    output_file,
                    session=self.session
                )
                
                if result and 'error' not in result:
                    # Get API request count for this scrape
                    new_request_count = get_request_count()
                    api_requests_used = new_request_count - current_request_count
                    
                    # Compute delta
                    delta = compute_scrape_delta(post_id, result, self.previous_data.get(post_id))
                    delta_info = delta.weighted()
                    
                    # Record in scheduler
                    self.scheduler.record_scrape(post_id, delta)
                    
                    # Record in depth advisor
                    self.depth_advisor.record_scrape(post_id, delta_info, api_requests_used)
                    
                    # Update previous data
                    self.previous_data[post_id] = result
                    
                    # Track for coverage metric
                    self.recent_scrapes.append((now, post_id))
                    
                    # Display result
                    meta = result.get('metadata', {})
                    comment_count = meta.get('total_comments', 0)
                    coverage = meta.get('coverage_percent', 0)
                    efficiency = delta_info / api_requests_used if api_requests_used > 0 else 0
                    
                    print(f"  ✅ {comment_count} comments ({coverage:.1f}%), "
                          f"ΔInfo={delta_info:.1f}, eff={efficiency:.3f}, "
                          f"reqs={api_requests_used}")
                    
                    # Update request counter for next iteration
                    prev_request_count = new_request_count
                
                else:
                    print(f"  ❌ Scrape failed")
                    prev_request_count = get_request_count()
            
            except KeyboardInterrupt:
                print("\n⚠️  Interrupted by user")
                break
            except Exception as e:
                print(f"  ❌ Error: {e}")
                prev_request_count = get_request_count()
            
            # === TELEMETRY PHASE ===
            if time.time() - last_telemetry_time >= telemetry_interval:
                # Compute coverage for top subreddits
                top_subs = self.allocator.rank_order[:10] if len(self.allocator.rank_order) >= 10 else self.allocator.rank_order
                
                # Count recent scrapes from last 6h
                six_hours_ago = now - timedelta(hours=6)
                posts_6h = set(pid for (ts, pid) in self.recent_scrapes if ts > six_hours_ago)
                
                # Compute waste rate from scheduler
                recent_deltas = []
                for post in self.scheduler.posts.values():
                    if post.deltas:
                        recent_deltas.extend([d.weighted() for d in post.deltas[-10:]])
                
                waste_rate = sum(1 for d in recent_deltas if d == 0) / len(recent_deltas) if recent_deltas else 0.0
                
                # Collect snapshot
                snapshot = self.telemetry.collect_snapshot(
                    instantaneous_rps=instantaneous_rps,
                    rate_ema=self.scheduler.controller.rate_ema,
                    global_gain=self.scheduler.controller.g,
                    avg_lateness=0.0,  # TODO: compute from scheduler
                    total_scrapes=self.scheduler.total_scrapes,
                    total_delta_info=self.scheduler.total_delta_info,
                    active_posts=len(self.scheduler.posts),
                    posts_scraped_6h=len(posts_6h),
                    waste_rate=waste_rate,
                    coverage_top_subs=1.0  # TODO: compute actual
                )
                
                # Log and print
                self.telemetry.log_snapshot(snapshot)
                self.telemetry.print_snapshot(snapshot, verbose=False)
                
                # Print alerts if any
                if snapshot.alerts:
                    for alert in snapshot.alerts:
                        print(f"  {alert}")
                
                last_telemetry_time = time.time()
            
            # === MAINTENANCE PHASE ===
            # Retire dormant posts periodically
            if self.scheduler.total_scrapes % 20 == 0:
                self.scheduler.retire_dormant_posts()
            
            # Save state periodically
            if self.scheduler.total_scrapes % 10 == 0:
                self.scheduler._save_state()
        
        # === FINAL SUMMARY ===
        self._print_final_summary(start_time)
    
    def _print_final_summary(self, start_time: float):
        """Print final summary statistics."""
        elapsed_total = (time.time() - start_time) / 60
        
        print()
        print("="*80)
        print("📊 FINAL SUMMARY")
        print("="*80)
        print()
        
        # Scheduler metrics
        status = self.scheduler.get_status()
        print(f"Scraping:")
        print(f"  ├─ Duration: {elapsed_total:.1f} minutes")
        print(f"  ├─ Total scrapes: {status['total_scrapes']}")
        print(f"  ├─ Total ΔInfo: {status['total_delta_info']:.1f}")
        print(f"  ├─ Avg ΔInfo/scrape: {status['avg_delta_info_per_scrape']:.2f}")
        print(f"  └─ Throughput: {status['total_scrapes']/elapsed_total:.2f} scrapes/min")
        print()
        
        # Controller metrics
        ctrl = status['controller']
        print(f"Rate Controller:")
        print(f"  ├─ Global Gain: {ctrl['global_gain']:.3f}")
        print(f"  ├─ Rate EMA: {ctrl['rate_ema']:.2f} rps")
        print(f"  └─ Utilization: {ctrl['utilization_pct']:.1f}%")
        print()
        
        # Discovery metrics
        disc_status = self.poller.get_status()
        print(f"Discovery:")
        print(f"  ├─ Total polls: {disc_status['total_polls']}")
        print(f"  ├─ Posts discovered: {disc_status['total_discovered']}")
        print(f"  └─ Avg per poll: {disc_status['avg_posts_per_poll']:.1f}")
        print()
        
        # Depth advisor metrics
        depth_status = self.depth_advisor.get_status()
        print(f"Depth Distribution:")
        print(f"  ├─ Shallow: {depth_status['shallow']}")
        print(f"  ├─ Medium: {depth_status['medium']}")
        print(f"  ├─ Deep: {depth_status['deep']}")
        print(f"  └─ Avg efficiency: {depth_status['avg_efficiency']:.3f} ΔInfo/req")
        print()
        
        # Telemetry metrics
        print(f"Telemetry:")
        print(f"  ├─ Snapshots: {len(self.telemetry.snapshots)}")
        print(f"  └─ Active alerts: {len(self.telemetry.active_alerts)}")
        print()
        
        # Save final state
        self.scheduler._save_state()
        print("💾 State saved")
        print()
        
        print("="*80)
        print("✅ UNIFIED SCRAPER COMPLETE")
        print("="*80)


if __name__ == '__main__':
    import sys
    
    # Parse arguments
    duration = int(sys.argv[1]) if len(sys.argv) > 1 else 60
    target_rps = float(sys.argv[2]) if len(sys.argv) > 2 else 10.0
    skip_bootstrap = '--no-bootstrap' in sys.argv
    
    # Check for custom temporal directory
    temporal_dir = 'temporal_test'
    for arg in sys.argv:
        if arg.startswith('--dir='):
            temporal_dir = arg.split('=')[1]
    
    # Create and run unified scraper
    scraper = UnifiedScraper(
        target_rps=target_rps, 
        skip_bootstrap=skip_bootstrap,
        temporal_dir=temporal_dir
    )
    scraper.run(duration_minutes=duration)

