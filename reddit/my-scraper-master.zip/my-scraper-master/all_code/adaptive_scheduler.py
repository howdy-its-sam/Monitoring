#!/usr/bin/env python3
"""
Adaptive Information-Weighted Scheduler
Main control loop integrating temperature, rate control, and subreddit priors.
Based on reference_books/adaptive_scheduler_reference.ipynb
"""

import os
import json
from datetime import datetime, timezone, timedelta
from typing import List, Dict, Optional, Tuple
import heapq

from temperature_scheduler import (
    PostState, ScrapeDelta, QueueEntry,
    compute_recent_stats, compute_temperature, 
    schedule_next, get_ready_posts, compute_avg_lateness,
    hours_between
)
from rate_controller import RateController
from subreddit_priors import SubredditPriors
from info_gain_analytics import compute_delta_info


class AdaptiveScheduler:
    """
    Main adaptive scheduler coordinating all components.
    
    Replaces the old 3-phase discrete priority system with continuous
    temperature-based scheduling with rate-limit feedback.
    """
    
    def __init__(self,
                 target_rps: float = 10.0,
                 lateness_setpoint: float = 0.15,
                 state_dir: str = "temporal_test"):
        """
        Initialize adaptive scheduler.
        
        Args:
            target_rps: Target requests per second (default 10.0 = 600/min)
            lateness_setpoint: Target average lateness fraction (default 0.15 = 15%)
            state_dir: Directory for storing scheduler state
        """
        self.target_rps = target_rps
        self.lateness_setpoint = lateness_setpoint
        self.state_dir = state_dir
        
        # Components
        self.controller = RateController(target_rps=target_rps)
        self.priors = SubredditPriors()
        
        # Post tracking
        self.posts: Dict[str, PostState] = {}  # post_id → PostState
        
        # Metrics
        self.total_scrapes = 0
        self.total_delta_info = 0.0
        self.last_tick_time = None
        
        # Load existing state if available
        self._load_state()
    
    def add_post(self, post_id: str, url: str, subreddit: str = "news") -> PostState:
        """
        Add a new post to tracking.
        
        Initializes with subreddit priors.
        
        Args:
            post_id: Reddit post ID
            url: Post URL
            subreddit: Subreddit name
        
        Returns:
            Created PostState
        """
        if post_id in self.posts:
            return self.posts[post_id]
        
        # Initialize with subreddit priors
        lambda_prior = self.priors.get_lambda(subreddit)
        
        post = PostState(
            post_id=post_id,
            url=url,
            subreddit=subreddit,
            lambda_hat=lambda_prior,
            last_scrape_ts=None,
            last_nonzero_ts=None,
        )
        
        self.posts[post_id] = post
        return post
    
    def record_scrape(self, post_id: str, delta: ScrapeDelta):
        """
        Record the result of a scrape.
        
        Updates post state with new delta information.
        
        Args:
            post_id: Reddit post ID
            delta: ScrapeDelta from this scrape
        """
        if post_id not in self.posts:
            return
        
        post = self.posts[post_id]
        post.deltas.append(delta)
        post.last_scrape_ts = delta.ts
        
        if delta.weighted() > 0:
            post.last_nonzero_ts = delta.ts
        
        # Update metrics
        self.total_scrapes += 1
        self.total_delta_info += delta.weighted()
    
    def control_tick(self, now: Optional[datetime] = None, 
                    instantaneous_rps: Optional[float] = None) -> List[QueueEntry]:
        """
        Main control loop tick.
        
        1. Update stats & temperature for all posts
        2. Build priority queue
        3. Update global gain (if rps provided)
        4. Return queue
        
        Args:
            now: Current time (default: now in UTC)
            instantaneous_rps: Optional actual measured RPS from API request counter
        
        Returns:
            Priority queue of posts ready to scrape
        """
        if now is None:
            now = datetime.now(timezone.utc)
        
        self.last_tick_time = now
        
        if not self.posts:
            return []
        
        posts_list = list(self.posts.values())
        
        # 1. Update stats & temperature
        for p in posts_list:
            compute_recent_stats(p, k=5)
        compute_temperature(posts_list, now)
        
        # 2. Build priority queue
        queue = schedule_next(
            posts_list, 
            now, 
            g=self.controller.g,
            lateness_setpoint=self.lateness_setpoint
        )
        
        # 3. Update global gain (if rps measurement provided)
        if instantaneous_rps is not None:
            avg_lateness = compute_avg_lateness(posts_list, now)
            self.controller.update(
                instantaneous_rps,
                avg_lateness,
                self.lateness_setpoint
            )
        
        return queue
    
    def get_next_posts(self, limit: int = 1) -> List[str]:
        """
        Get next post(s) to scrape.
        
        Args:
            limit: Maximum number of posts to return
        
        Returns:
            List of post_ids in priority order
        """
        now = datetime.now(timezone.utc)
        queue = self.control_tick(now)
        return get_ready_posts(queue, now, limit=limit)
    
    def retire_dormant_posts(self):
        """
        Check for dormant posts and record them in subreddit priors.
        
        A post is considered dormant if:
        - It has 3+ consecutive zero-Δ scrapes
        - OR it hasn't had activity in 48+ hours
        """
        from info_gain_analytics import (
            time_to_dormancy_hours,
            waste_rate,
            estimate_lambda_from_curve
        )
        
        now = datetime.now(timezone.utc)
        to_retire = []
        
        for post_id, post in self.posts.items():
            if len(post.deltas) < 5:
                continue  # Need minimum history
            
            # Check dormancy conditions
            deltas_weighted = [d.weighted() for d in post.deltas]
            
            # Check for 3 consecutive zeros
            consecutive_zeros = 0
            for val in reversed(deltas_weighted):
                if val == 0:
                    consecutive_zeros += 1
                    if consecutive_zeros >= 3:
                        to_retire.append(post_id)
                        break
                else:
                    break
            
            # Or check time since last activity
            if post.last_nonzero_ts:
                hours_since = hours_between(now, post.last_nonzero_ts)
                if hours_since > 48:
                    to_retire.append(post_id)
        
        # Record in priors and remove
        for post_id in set(to_retire):
            post = self.posts[post_id]
            
            # Compute final metrics
            timeline = [d.ts for d in post.deltas]
            deltas_weighted = [d.weighted() for d in post.deltas]
            
            lambda_est = estimate_lambda_from_curve(timeline, deltas_weighted) or post.lambda_hat
            dormancy_h = time_to_dormancy_hours(timeline, deltas_weighted)
            waste = waste_rate(deltas_weighted)
            
            # Record in priors
            self.priors.record_post(
                post.subreddit,
                lambda_est,
                half_life_h=dormancy_h,
                waste_rate=waste
            )
            
            # Remove from tracking
            del self.posts[post_id]
            
            print(f"🛌 Retired dormant post: {post_id} (λ={lambda_est:.3f})")
    
    def get_status(self) -> Dict:
        """
        Get current scheduler status for monitoring.
        
        Returns:
            Dict with metrics and state
        """
        now = datetime.now(timezone.utc)
        
        return {
            "total_posts": len(self.posts),
            "total_scrapes": self.total_scrapes,
            "total_delta_info": self.total_delta_info,
            "avg_delta_info_per_scrape": self.total_delta_info / self.total_scrapes if self.total_scrapes > 0 else 0,
            "controller": self.controller.get_status(),
            "last_tick": self.last_tick_time.isoformat() if self.last_tick_time else None,
        }
    
    def _save_state(self):
        """
        Persist scheduler state to disk.
        
        Saves post states to temporal_test/{post_id}/scheduler_state.json
        """
        for post_id, post in self.posts.items():
            post_dir = os.path.join(self.state_dir, post_id)
            os.makedirs(post_dir, exist_ok=True)
            
            state_file = os.path.join(post_dir, "scheduler_state.json")
            
            # Serialize post state
            state_data = {
                "post_id": post.post_id,
                "url": post.url,
                "subreddit": post.subreddit,
                "lambda_hat": post.lambda_hat,
                "temperature": post.temperature,
                "recent_rate": post.recent_rate,
                "volatility": post.volatility,
                "interval_hours": post.interval_hours,
                "last_scrape_ts": post.last_scrape_ts.isoformat() if post.last_scrape_ts else None,
                "last_nonzero_ts": post.last_nonzero_ts.isoformat() if post.last_nonzero_ts else None,
                "next_due": post.next_due.isoformat() if post.next_due else None,
                "delta_count": len(post.deltas),
                "total_delta_info": sum(d.weighted() for d in post.deltas),
            }
            
            with open(state_file, 'w') as f:
                json.dump(state_data, f, indent=2)
    
    def _load_state(self):
        """
        Load scheduler state from disk if available.
        """
        if not os.path.exists(self.state_dir):
            return
        
        for post_id in os.listdir(self.state_dir):
            post_dir = os.path.join(self.state_dir, post_id)
            if not os.path.isdir(post_dir):
                continue
            
            state_file = os.path.join(post_dir, "scheduler_state.json")
            if not os.path.exists(state_file):
                continue
            
            try:
                with open(state_file, 'r') as f:
                    state_data = json.load(f)
                
                # Reconstruct PostState (without full delta history)
                post = PostState(
                    post_id=state_data["post_id"],
                    url=state_data["url"],
                    subreddit=state_data.get("subreddit", "news"),
                    lambda_hat=state_data.get("lambda_hat", 0.15),
                )
                
                # Restore state
                post.temperature = state_data.get("temperature", 0.0)
                post.recent_rate = state_data.get("recent_rate", 0.0)
                post.volatility = state_data.get("volatility", 0.0)
                post.interval_hours = state_data.get("interval_hours", 1.0)
                
                if state_data.get("last_scrape_ts"):
                    post.last_scrape_ts = datetime.fromisoformat(state_data["last_scrape_ts"])
                if state_data.get("last_nonzero_ts"):
                    post.last_nonzero_ts = datetime.fromisoformat(state_data["last_nonzero_ts"])
                if state_data.get("next_due"):
                    post.next_due = datetime.fromisoformat(state_data["next_due"])
                
                self.posts[post_id] = post
                
            except Exception as e:
                print(f"⚠️  Failed to load state for {post_id}: {e}")


if __name__ == '__main__':
    print("="*80)
    print("🚀 ADAPTIVE SCHEDULER - Demo")
    print("="*80)
    print()
    
    # Create scheduler
    scheduler = AdaptiveScheduler(target_rps=10.0)
    
    # Add some sample posts
    print("Adding posts...")
    scheduler.add_post("post1", "https://reddit.com/r/news/1", "news")
    scheduler.add_post("post2", "https://reddit.com/r/news/2", "news")
    scheduler.add_post("post3", "https://reddit.com/r/worldnews/3", "worldnews")
    print(f"  ✓ Added {len(scheduler.posts)} posts")
    print()
    
    # Simulate some scrapes
    now = datetime.now(timezone.utc)
    
    print("Simulating scrapes...")
    scheduler.record_scrape("post1", ScrapeDelta(ts=now - timedelta(hours=1), new_comments=50, score_changed=100))
    scheduler.record_scrape("post1", ScrapeDelta(ts=now - timedelta(hours=0.5), new_comments=30, score_changed=80))
    scheduler.record_scrape("post2", ScrapeDelta(ts=now - timedelta(hours=2), new_comments=10, score_changed=20))
    scheduler.record_scrape("post3", ScrapeDelta(ts=now - timedelta(hours=4), new_comments=5, score_changed=10))
    print(f"  ✓ Recorded {scheduler.total_scrapes} scrapes")
    print()
    
    # Run control tick
    print("Running control tick...")
    queue = scheduler.control_tick(now)
    print(f"  ✓ Built queue with {len(queue)} posts")
    print()
    
    # Display status
    print("="*80)
    print("SCHEDULER STATUS")
    print("="*80)
    print()
    
    status = scheduler.get_status()
    for key, val in status.items():
        if key == "controller":
            print(f"{key}:")
            for k, v in val.items():
                print(f"  ├─ {k}: {v}")
        else:
            print(f"{key}: {val}")
    
    print()
    
    # Show queue
    print("="*80)
    print("PRIORITY QUEUE")
    print("="*80)
    print()
    
    for i, entry in enumerate(sorted(queue)[:5], 1):
        post = scheduler.posts[entry.post_id]
        print(f"{i}. {entry.post_id}")
        print(f"   ├─ T={post.temperature:.3f}, λ={post.lambda_hat:.3f}")
        print(f"   ├─ Δt={post.interval_hours:.2f}h")
        print(f"   └─ Due: {entry.next_time.strftime('%H:%M:%S')}")
        print()
    
    print("="*80)

