# Reddit Market Signal Analysis Notebook (Interactive)

# Section 1: Literature Overview (Markdown)
# This will be formatted in Markdown cells in the notebook, explaining:
# - Key findings from papers
# - Sentiment vs attention signal strength
# - Edit and structure dynamics

# Section 2: Imports and Setup
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import datetime
from sklearn.linear_model import LogisticRegressionCV
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.model_selection import TimeSeriesSplit
from sklearn.metrics import roc_auc_score, accuracy_score

# Section 3: Sample Data Generation (Simulating Reddit and Market Features)
np.random.seed(42)
timestamps = pd.date_range(start='2023-01-01 09:00', periods=100, freq='5min')

df = pd.DataFrame({
    'time': timestamps,
    'reddit_vol': np.random.poisson(lam=3, size=100),
    'reddit_sentiment': np.clip(np.random.normal(0, 0.5, size=100), -1, 1),
    'reddit_edit_count': np.random.binomial(n=2, p=0.1, size=100),
    'market_return_15m': np.clip(np.random.normal(0, 0.002, size=100), -0.01, 0.01),
})

# Binary classification target: 1 if return > 0, else 0
df['target_up'] = (df['market_return_15m'] > 0).astype(int)

# Lag features
for lag in [1, 2, 3]:
    df[f'reddit_vol_lag{lag}'] = df['reddit_vol'].shift(lag)
    df[f'reddit_sentiment_lag{lag}'] = df['reddit_sentiment'].shift(lag)
    df[f'reddit_edit_count_lag{lag}'] = df['reddit_edit_count'].shift(lag)

# Drop NA from lags
df_model = df.dropna().reset_index(drop=True)

# Section 4: Modeling (Logistic Regression)
X = df_model[[
    'reddit_vol_lag1', 'reddit_vol_lag2', 'reddit_vol_lag3',
    'reddit_sentiment_lag1', 'reddit_sentiment_lag2', 'reddit_sentiment_lag3',
    'reddit_edit_count_lag1', 'reddit_edit_count_lag2', 'reddit_edit_count_lag3']]
y = df_model['target_up']

tscv = TimeSeriesSplit(n_splits=5)
auc_scores = []
for train_idx, test_idx in tscv.split(X):
    X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
    y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]
    clf = LogisticRegressionCV(cv=3, scoring='roc_auc', max_iter=500).fit(X_train, y_train)
    preds = clf.predict_proba(X_test)[:, 1]
    auc = roc_auc_score(y_test, preds)
    auc_scores.append(auc)

print("Average AUC (LogReg):", np.mean(auc_scores))

# Section 5: Gradient Boosting Model
boost_model = GradientBoostingClassifier(n_estimators=100, max_depth=3)
boost_model.fit(X_train, y_train)
preds_boost = boost_model.predict_proba(X_test)[:, 1]
print("AUC (Boost):", roc_auc_score(y_test, preds_boost))

# Section 6: Lead-Lag Visualization
plt.figure(figsize=(10, 4))
sns.lineplot(data=df[['time', 'reddit_vol']], x='time', y='reddit_vol', label='Reddit Volume')
sns.lineplot(data=df[['time', 'market_return_15m']], x='time', y='market_return_15m', label='15-min Market Return')
plt.title("Reddit Volume vs Market Return Over Time")
plt.legend()
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# Section 7: Edit Impact Analysis (Simulated)
df['edit_effect'] = np.where(df['reddit_edit_count'] > 0, np.random.normal(0.0003, 0.001, size=100), 0)
df['market_return_with_edit'] = df['market_return_15m'] + df['edit_effect']

print("Mean return w/ edits:", df[df['reddit_edit_count'] > 0]['market_return_with_edit'].mean())
print("Mean return w/o edits:", df[df['reddit_edit_count'] == 0]['market_return_with_edit'].mean())

# This scaffold can be extended with more visuals, conformal prediction, or event study panes.
